/* EGAD: sequence_CHROMOSOME_stuff.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for sequence_CHROMOSOME_stuff.cpp
   
*/

#ifndef sequence_CHROMOSOME_stuff_header_flag
#define sequence_CHROMOSOME_stuff_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "GA_utilities.h"
#include "io.h"


/* generates amino acid sequence corresponding to the chromosome chr; this version includes only the positions
	with more than one residue choice.
	sequence must be allocated by the calling function
*/

void CHROMOSOME_to_variable_sequence(CHROMOSOME *chr, char *sequence);

/* Generates a chromosome with the appropriate pointers etc corresponding to a sequence of variable positions
*/
void variable_sequence_to_CHROMOSOME(CHROMOSOME *chr, char *sequence);


/* generates amino acid sequence corresponding to the chromosome chr; invar_pos used to include pro,gly in the sequence.	
	sequence must be allocated by the calling function
*/
void CHROMOSOME_to_sequence(CHROMOSOME *chr, INVARIABLE_POSITIONS *invar_pos, char *sequence);

/* Generates a chromosome with the appropriate pointers etc corresponding to a protein sequence 
  chr must be pre-intialized/allocated with a GENE linked list (using inoculate sidechains)  
  sequence must end with '\0' */
void sequence_to_CHROMOSOME(CHROMOSOME *chr, INVARIABLE_POSITIONS *invar_pos, char *sequence);


/* this function extracts the sequence composition for all 20 ACDEFGHIKLMNPQRSTVWY residuetypes in sequence, 
	and places the number of each residue into composition;
	for example sequence = "AAFGHLMN"	
		composition[1] = 2;	(A)
		composition[5] = 1;	(F)
		composition[6] = 1;	(G)
		composition[7] = 1;	(H)
		composition[11] = 1;	(M)
		composition[12] = 1;	(N)
*/
void extract_composition(int *composition, char *sequence);


#endif
