/* EGAD: energy_profile_table.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for energy_profile_table.cpp


	diagonal is internal and solvation energy for the residue of interest
	bkbn-X = interaction energy between bkbn and X
	res(X)-res(Y) = interaction energy between sidechains X and Y 

		 0	   1       2			n-1		  n	 	  n+1
		bkbn res(1)  res(2) ..... res(n-1)  res(n) 	totals
     0	bkbn												bkbn_total
     1	res(1)												res(1)_total
     2	res(2)												res(2)_total
	  .
   	  .
	  .
    n-1	res(n-1)											res(n-1)_total
     n 	res(n)												res(n)_total
    n+1	totals	bkbn  res(1) res(2) ..... res(n-1)  res(n)	total energy for the structure
		total total  total		  total		total

*/		



#ifndef energy_profile_table_header_flag
#define energy_profile_table_header_flag

#include "structure_types.h"
#include "pdbATOM_utilities.h"
#include "energy_functions.h"
#include "io.h"


void energy_profile_table_difference(int num_res, double **energy_table_diff, double **energy_table_A, double **energy_table_B);

/* output energy_table to file name.energy_profile_table; called by output_PROTEIN */
void output_energy_profile_table(double **energy_table, char *name, int num_res, 
							SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map, char *sequence);

/* place backbone atoms (not CB) from pdb into backbone array (allocated by calling function).
   for each sidechain i, place sidechain atoms (including CB) into sidechain[i] array.  
	(**sidechain allocated by calling function).
*/
void extract_sub_structures(mini_pdbATOM *mini_Template, mini_pdbATOM *backbone, mini_pdbATOM **sidechain);

/* given num_res residues in mini_pdbATOM pdb, generate the energy_profile_table input_energy_table.
	input_energy_table == NULL ---> memory will be allocated by this function.
*/
void generate_energy_profile_table(double ***energy_table, mini_pdbATOM *pdb, int num_res);

#endif
