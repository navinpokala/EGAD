/* EGAD: io.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for io.cpp

*/

#ifndef io_flag
#define io_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <glob.h>

#include "structure_types.h"

/* return 1 if it worked, return 0 if it already exists */
int make_directory(char *dir_name);

/* return 0 if file does not exist, 1 if it does */
int does_this_file_exist(const char *filename);

/* mv file name1 to file name2 */
void mv_file(char *name1, char *name2);

/* append file name1 to the end of file name2 */
void append_file(char *name1, char *target);

/* cp file name1 to file name2 */
void cp_file(char *name1, char *name2);

/* rm file name1 */
void rm_file(char *name1);

/* wrapper for fopen; usage exactly like fopen in <stdio.h> */
FILE * fopen_file(const char *filename, const char *mode);

/* returns the number of words (seperated by space or tab) in a string line (end w/ '\0') */
int word_count(char *line);

/* returns the number of words (seperated by space or tab) in a string line (end w/ '\0')
	places each word into string array **word; word[n] is the nth word in line.
	Memory for word must be allocated by the calling function
*/
int extract_words(char *line, char **word);

/* touches file filename, creating it or updating its nfs record */
void touch_file(char *filename);


/* creates directory directoryname inside of path */
int create_directory(char *directoryname, char *path);

/* converts lower-case characters in string keyword to uppercase; 
	useful for making input case-independent */
void convert_string_to_all_caps(char *keyword);

/* returns 1 if the files are identical; 0 if they are different */
int are_these_files_identical(char *file1, char *file2);

/* this function is a wrapper for ssh for sending commands to remote machines.
	especially useful for parallel processing.
	If sending jobs to a batch queue master node, define BATCH_QUEUE_PREFIX 
	in the inputfile or change the default in input_stuff.cpp and re-compile.
   returns value of ssh command (0= success). 
*/
int ssh_command(char *hostname, char *remote_command);

/* writes message to INPUTFILE_NAME.failure_log and stderr; exits or aborts as indicated */
void failure_report(const char *message, const char *exit_or_abort);

/* If AVAILABLE_PROCESSORS_FILE!=NULL, ssh and execute commands on listed hosts; else run command on this host */
void launch_command(char *remote_dir, char *command);

int grep_line_from_file(char *target, char *line, int sizeof_line, char *filename);

#endif
