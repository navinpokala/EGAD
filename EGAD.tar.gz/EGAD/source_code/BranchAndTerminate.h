// *****************************************************************************
// Name: BranchAndTerminate.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <BranchAndTerminate.h 2003-06-18 16:44:24 Mark Voorhies>
// Implimented in: BranchAndTerminate.cpp
// Description:
//   BranchAndTerminate impliments the Branch & Terminate algorithm described
//   in Gordon & Mayo Structure 7:1089-1098 (1999).
//   This can be called in two contexts:
//    1) At the clean-up step of a DEE run (where we currently use 
//       ExhaustiveSearch)
//    2) During a DEE cycle, to "terminate" rotamers and DEP's
//   Since the best interface is different for each context, we should at
//   least have two top-level wrapper functions (and it may be better to
//   set this up as member functions of a class).
// *****************************************************************************

#ifndef MSV_BRANCHANDTERMINATE_HEADER_FLAG
#define MSV_BRANCHANDTERMINATE_HEADER_FLAG

#include <stdio.h>
#include <vector>

#include "DeeSpace.h"
#include "ExhaustiveSearch.h" // for ExhaustiveSolution

// Eliminate resimers for which E_bound > E_ref
int BoundingSingles(const DeeEnergy& energy, DeeTable& eliminated, 
		    const DeeSpace& space, const double& E_ref,
		    FILE *message_stream = stdout);
int BoundingDoubles(const DeeEnergy& energy, DeeTable& eliminated, 
		    const DeeSpace& space, const double& E_ref,
		    FILE *message_stream = stdout);

int OptBoundingSingles(const DeeEnergy& energy, DeeTable& eliminated, 
		       const DeeSpace& space, const double& E_ref,
		       FILE *message_stream = stdout);

// Eliminate pairs for which E_bound > E_ref
int OptBoundingDoubles(const DeeEnergy& energy, DeeTable& eliminated, 
		       const DeeSpace& space, const double& E_ref,
		       FILE *message_stream = stdout);
/*
Exhaustivesolution *BranchAndTerminate(const DeeEnergy& energy,
				       const DeeTable& eliminated,
				       const DeeSpace& space,
				       const int max_nodes = -1,
				       FILE *message_stream = stdout);
*/
#endif
