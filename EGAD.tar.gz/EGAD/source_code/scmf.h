/* EGAD: scmf.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for scmf.cpp
   
*/


#ifndef scmf_header_flag
#define scmf_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "HQM_rotamers.h"
#include "moremath.h"
#include "MC.h"
#include "GENES_pdb.h"

/* convert probabs in lookupEnergy.P entries (from scmf optimization) to residue and rotamer probabilities */
void convert_scmf_probabs_to_rotamer_probabs(VARIABLE_POSITION *var_pos);

/* calculates the difference in rotamer probabilties between the current and 
    previous SCMF cycle; used for determining scmf convergence */
double conf_matrix_diff(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos);


/* self consistent mean field optimization. 
	assumes that protein has been through input_stuff and generate_lookup_table 
*/
void scmf(PROTEIN *protein);


#endif
