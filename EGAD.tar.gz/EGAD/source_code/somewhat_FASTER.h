/* EGAD: somewhat_FASTER.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for somewhat_FASTER.cpp

*/


#ifndef somewhat_FASTER_header_flag
#define somewhat_FASTER_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "GA_utilities.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "io.h"
#include "moremath.h"
#include "MC.h" 
#include "HQM_rotamers.h"

void FASTER_rotamers(PARAMETERS *parameters, CHROMOSOME *chr, VARIABLE_POSITION *var_pos, LOOKUP_ENERGY *lookupEnergy);


void FASTER_rotamer_control(PROTEIN *protein);

#endif
