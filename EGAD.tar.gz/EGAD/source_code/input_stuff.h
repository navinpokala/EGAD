/* EGAD: input_stuff.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for input_stuff.cpp

*/



#ifndef input_stuff_header_flag
#define input_stuff_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "readpdbfile.h"
#include "read_forcefield.h"
#include "VARIABLE_POSITION.h"
#include "energy_functions.h"
#include "pairwise_energy_calc.h"
#include "io.h"
#include "lookup_table_disk_stuff.h"
#include "GA_utilities.h"
#include "lookup_table.h"
#include "pdbATOM_utilities.h"

/* moves the file_ptr past comments and empty lines to the start of the next command block in the
	inputfile. Upon return, line and file_ptr are at the line just past the comments.
	if an empty line or end of file (EOF) is reached, returns 0; else returns 1.
	line must be allocated by the calling function
*/
int move_past_comments_and_empty_lines(char *line, FILE *file_ptr);


/* parses "true" or "false" text from inputfiles for flag variables; FLAG= 1 or 0 respectively */
#define sscanf_flag(line,dummystring,FLAG)	\
{	\
	if(strstr(line,"true")!=NULL || strstr(line,"True")!=NULL || strstr(line,"TRUE")!=NULL)	\
		 FLAG=1;	\
	else	\
		if(strstr(line,"false")!=NULL || strstr(line,"False")!=NULL || strstr(line,"FALSE")!=NULL)	\
			FLAG=0;	\
		else	\
	      		sscanf(line, "%s %d", dummystring, &FLAG);	\
}

/* reads an input file, parses variable positions, reads Template, forcefield files.
	Initializes and sets lots of variables. See manual for file formats.
	This is akin to a "constructor" for PROTEIN structures  */
void input_stuff(char *inputfilename, PROTEIN *protein);

/* parses file pointer *input set at the line following the "VARIABLE_POSITIONS" line in an input file.
	Assumes that protein has gone through input_stuff (or has variables from input_stuff set)
	This function is called by input_stuff, sequence_to_var_pos_file, and rotamer_calc_foreman.
	if modify_varpos_flag=0, then VARIABLE_POSITIONS:modify_VARIABLE_POSITION is not called */
void input_VARIABLE_POSITION(FILE *input, PROTEIN *protein, int modify_varpos_flag);		 

/* parses file pointer *input set at the line following the "SEQUENCE" line in an input file.
	Assumes that protein has gone through input_stuff (or has variables from input_stuff set)
	This function is called by input_stuff and by rotamer_calc_foreman 
	if modify_varpos_flag=0, then VARIABLE_POSITIONS:modify_VARIABLE_POSITION is not called */
void sequence_to_var_pos_file(FILE *input, PROTEIN *protein, int modify_varpos_flag);

/* this function sets up total sequence design, using hp patterning.
	called by input_VARIABLE_POSITION when it sees "HP_pattern" following the "VARIABLE_POSITIONS" line
	in the input file */
void hp_pattern_design(FILE *original_input_ptr, PROTEIN *protein);

/* this function frees memory from PROTEIN structures, including the lookup table */
void free_PROTEIN(PROTEIN  *protein);

#endif
