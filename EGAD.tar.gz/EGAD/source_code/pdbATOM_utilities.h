/* EGAD: pdbATOM_utilities.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for pdbATOM_utilities.cpp
   
*/


#ifndef pdbATOM_utilities_header_flag
#define pdbATOM_utilities_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "dihedral_cartesian.h"
#include "search_and_sort.h"

/* concatanates (cat) pdb1 and pdb2 into target */
void cat_mini_pdbATOM(mini_pdbATOM pdb1[], mini_pdbATOM pdb2[], mini_pdbATOM target[]);

/* concatanates (cat) pdb1 and pdb2 into target */
void cat_pdbATOM(pdbATOM pdb1[], pdbATOM pdb2[], pdbATOM target[]);

/* 
   This function attached atom_ptrs to all the atoms in pdb = array of pdbATOM.
   resparam = main resparam array; 
*/
void attach_ptr_pdbATOM(pdbATOM *pdb, RESPARAM *resparam);

/* Given template pdbATOM and VARIABLE_POSITION array varPos, this function fills the pdbATOM fixed_atm array with
  fixed atoms whose structure does not change during the course of an optimization */
void make_fixed_pdbATOM(pdbATOM *Template, VARIABLE_POSITION *varPos, pdbATOM *fixed_atm);

/* for an allocated mini_pdbATOM array, generate coords, etc, from BACKBONE bkbn */ 
void make_bkbn_mini_pdbATOM(mini_pdbATOM *pdb, BACKBONE *bkbn);

/* generates the mini_pdbATOM array var_atm (allocated by calling function) for a SIDECHAIN */
void make_side_mini_pdbATOM(mini_pdbATOM *var_atm, SIDECHAIN *side);

/* generates the pdbATOM array var_atm (allocated by calling function) for a SIDECHAIN */
void make_side_pdbATOM(pdbATOM *var_atm, SIDECHAIN *side);

/* append pdb to the end of pre-loaded array target */
void append_mini_pdbATOM(mini_pdbATOM pdb[], mini_pdbATOM target[]);

/* append pdb to the end of pre-loaded array target */
void append_pdbATOM(pdbATOM pdb[], pdbATOM target[]);

/* parses a seqpos string into an internal sequence position (returned value) */
int parse_seqpos_string(char *seqpos_string, SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map);

/* for a sequence position, return the seqpos_text_map index */
int seqpos_to_inputted_string(int seq_pos, SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map);

/* generates sequence (allocated by calling function) for a pdbATOM array.
	resparam = main resparam array;  */
void pdbATOM_to_sequence(pdbATOM *pdb, char *sequence, RESPARAM *resparam);

#define transform_pdb(transformed_pdb, transform_matrix)	\
{	\
	int i;	\
		\
	if(transform_matrix!=NULL)		\
	{							\
		i=1;	\
		while(transformed_pdb[i].seq_position!=ENDFLAG)	\
		{	\
			transformed_pdb[i].coord = tranform_coordinates(transformed_pdb[i].coord, transform_matrix);	\
			++i;	\
		}	\
	}  \
}


char find_one_letter_code_pdbATOM_seq_position(pdbATOM *pdb, int seq_position, RESPARAM *resparam);

#endif
