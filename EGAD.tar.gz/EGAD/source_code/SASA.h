/* EGAD: SASA.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for SASA.cpp

*/


#ifndef SASA_header_flag
#define SASA_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include "io.h"
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
#include <sys/time.h>

#include "structure_types.h"
#include "moremath.h"

extern double HBOND_PROBE_SASA_CUTOFF;
extern double SASA_DISTANCE_CUTOFF, **SASA_RADII_SQRD_MATRIX;

/* free some memory */
void freeCARTESIAN_VECTOR(CARTESIAN_VECTOR *vector);

/* free some memory */
void free_CARTESIAN_VECTOR_ptr(CARTESIAN_VECTOR ***vector_ptr, int sizeof_array);

/* reads the points file containing the SASA lookup table */
void SASA_readfiles(char *SASA_points_file, ATOMPARAM *atomparam);

/* sets the components of sasa_sum to 0 */
#define SASA_SUM_0(sasa_sum)   {sasa_sum.E_transfer = 0; sasa_sum.sp2 = 0; sasa_sum.sp3_S=0; sasa_sum.N=0; sasa_sum.O=0; sasa_sum.H=0; sasa_sum.sasa_total = 0; }


/* subtracts sasa components c from b */
inline SASA_SUM SASA_SUM_SUBTRACT(SASA_SUM b, SASA_SUM c)
{
	SASA_SUM a;
		
  a.sasa_total = b.sasa_total - c.sasa_total;    
  a.sp2 = b.sp2 - c.sp2; 
  a.sp3_S = b.sp3_S - c.sp3_S; 
  a.O = b.O - c.O; 
  a.N = b.N - c.N; 
  a.H = b.H - c.H; 
	
	return(a);
}

/* adds sasa components from b and c  */
inline SASA_SUM SASA_SUM_ADD(SASA_SUM b, SASA_SUM c)
{
	SASA_SUM a;
		
  a.sasa_total = b.sasa_total + c.sasa_total;    
  a.sp2 = b.sp2 + c.sp2; 
  a.sp3_S = b.sp3_S + c.sp3_S; 
  a.O = b.O + c.O; 
  a.N = b.N + c.N; 
  a.H = b.H + c.H; 
	
	return(a);
}

/* scales components in SASA_SUM by scale factor c */
SASA_SUM sasa_sum_scale(double c, SASA_SUM b);


/* calculates SASA_SUM for mini_pdbATOM array pdb; also calculates SASA for each atom --> pdb[i].sasa */
SASA_SUM SASAcalc(mini_pdbATOM *pdb);

/* calculates SASA_SUM for mini_pdbATOM array pdb_ptr[]; also calculates SASA for each atom.  
  uses a precalculated CARTESIAN_VECTOR structure (must be calculated a priori for pdb_ptr[] )   */
SASA_SUM precalcSASAcalc(mini_pdbATOM *pdb_ptr[]);

/* calculates CARTESIAN_VECTOR for a pair of mini_pdbATOM arrays 
	use for pairwise area calcs (presently not implemented) */
void pairwise_minipdbATOM_to_CARTESIAN_VECTOR(mini_pdbATOM *pdb, mini_pdbATOM *pdb2, CARTESIAN_VECTOR *vector);

void sort_box(int lower,int upper); /* sorts box for SASA calculations */
int cmp_box(SASA_ATOM *a1, SASA_ATOM *a2);
int find_box(int box_id,int *boxstart,int *boxend, int box_atoms);


/* calculates CARTESIAN_VECTOR for atompairs from a mini_pdbATOM array 
	use for the self part of pairwise area calcs (presently not implemented) */
void minipdbATOM_to_CARTESIAN_VECTOR(mini_pdbATOM *pdb, CARTESIAN_VECTOR *vector);

/* for a mini_pdbATOM array that already has sasa's calculated for each atom, return SASA_SUM */
SASA_SUM get_SASA_SUM(mini_pdbATOM *pdb);

void generate_SASA_points(char *SASA_points_file);

#endif
