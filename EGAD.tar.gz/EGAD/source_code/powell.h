/* EGAD: powell.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for powell.cpp
   
*/



#ifndef powell_header_flag
#define powell_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "moremath.h"


typedef struct
{
	GENE gene;
	mini_pdbATOM *fixed_atoms;
	mini_pdbATOM *CB_atom;
} MINIMIZE_ROTAMER_DATATYPE;

typedef struct
{
	double *translate_rotate_array;
	CARTESIAN *initial_coord;
	CARTESIAN *target_coord;
	int num_points;
	double rmsd;
} RMSD_OVERLAY_DATATYPE;


typedef struct
{
	double *translate_rotate_array;
	double *lower_bound;
	double *upper_bound;
	double energy;
	mini_pdbATOM *starting_pdb;
	mini_pdbATOM *docking_target_pdb;
} RIGID_DOCKING_DATATYPE;


/* datatype for passing data to powell minimizer */
typedef struct
{
	PROTEIN *protein;
	MINIMIZE_ROTAMER_DATATYPE *minimize_rotamer_datatype;
	RMSD_OVERLAY_DATATYPE *rmsd_overlay_data;
	RIGID_DOCKING_DATATYPE *rigid_docking_data;
} POWELL;


/*
	powell minimization with objective function (func *) that takes a POWELL arguement.
	Adapted from Numerical Recipies in C. 
	p = solution array of size n.
	fret = objective function score of p.
	(func *) = objective function (with arguments double [] and POWELL *).
	Completes at least one full iteration.
		returns prematurely if NUM_FUNCTION_CALLS > powell->protein->parameters.max_function_calls or 
		if elapsed time > MAX_OPTIMIZATION_TIME
*/

void powell_minimization(double p[], int n, int max_iterations, double *fret, double (*func)(double [], POWELL *), POWELL *powell, time_t start_time);


#endif
