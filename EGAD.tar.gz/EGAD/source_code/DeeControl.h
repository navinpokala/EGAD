/* EGAD: DeeControl.h
   
Mark Voorhies, Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California

Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for DeeControl.cpp
   
*/

#ifndef NP_MSV_DeeControl_HEADER_FLAG
#define NP_MSV_DeeControl_HEADER_FLAG

struct PROTEIN;

/* this function controls DEE for rotamer optimization
	If DEE does not converge, or does not converge within RUNTIME, 
	simulated annealling is performed. Final_chr, energies, structures 
	are stored in protein, and is ready to send to output_PROTEIN */
int DeeControl(PROTEIN *protein);


#endif

