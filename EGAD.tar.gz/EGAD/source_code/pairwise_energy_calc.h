/* EGAD: pairwise_energy_calc.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for pairwise_energy_calc.cpp

*/



#ifndef pairwise_energy_calc_header_flag
#define pairwise_energy_calc_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "energy_functions.h"
#include "powell.h"
#include "GENES_pdb.h"

/* These functions calculate energies between two mini_pdbATOM arrays, as well as other tasks 
    required for precalculated lookup tables */ 

/* This function returns energy for the fixed atoms. Called by input_VARIABLE_POSITIONS   */
ENERGY fixedatoms_energy(mini_pdbATOM *input_fixed_atoms, VARIABLE_POSITION *varpos, RESPARAM *resparam);

/* returns var_var_ENERGY between sidechain rotamers i and j; 
	the arrays atom_ptr_i and atom_ptr_j are defined in read_residuedata. 
	The array indexing should be such that coordinates in i_atoms[i] and the ATOMRESPARAM in atom_ptr_i[i] 
	correspond to the same atom.  
*/
var_var_ENERGY var_var_energy_calc(milli_pdbATOM *i_atoms, milli_pdbATOM *j_atoms, ATOMRESPARAM **atom_ptr_i, ATOMRESPARAM **atom_ptr_j, bool *do_these_hbond_flag, bool *i_hbond_status, bool *j_hbond_status);


/* returns var_fix_ENERGY between sidechain atoms var_atoms and fixed_atoms, as well as born radii for var_atoms 
	gb_flag 1 means calculate born radii and energies; 0 means do not  */
var_fix_ENERGY var_fixed_energy_calc(mini_pdbATOM *fixed_atoms, mini_pdbATOM *var_atoms, int gb_flag);

/* minimalist version of var_fixed_energy_calc for rotamerlet local minimization; returns var_fix_vdw_ENERGY */
var_fix_vdw_ENERGY var_fixed_vdw_screen(mini_pdbATOM *fixed_atoms, CARTESIAN *var_atoms, ATOMRESPARAM **var_atom_ptr, int seq_position);


/* version of var_var_energy_calc for rotamerlet local minimization; returns E_vdw */
double var_var_vdw_screen(milli_pdbATOM *i_atoms, milli_pdbATOM *j_atoms, ATOMRESPARAM **atom_ptr_i, ATOMRESPARAM **atom_ptr_j);

/* version of var_var_vdw_screen for methyl local minimization; returns E_vdw */
double var_var_vdw_screen_micro(CARTESIAN *i_atoms, CARTESIAN *j_atoms, ATOMRESPARAM **atom_ptr_i, ATOMRESPARAM **atom_ptr_j);


/* returns 1 if i and j have at least one atom for all rotamers within FORCEFIELD_DISTANCE_CUTOFF of each other */
int do_these_interact(milli_pdbATOM **i_atoms, milli_pdbATOM **j_atoms, int num_i, int num_j);


/* returns the energy between two sidechain rotamers represented by i_gene and j_gene, 
    using structures precalculated and stored in the lookup table and linked appropriately 
*/
    
double rotamer_pair_energy(GENE i_gene, GENE j_gene, LOOKUP_ROTAMER_X_HBOND **lookupRotX_hbond);

ENERGY sidechain_internal_energy(mini_pdbATOM *side_pdb, COULOMBIC *first_coulombic, COULOMBIC *coulombic);

double rotamer_bkbn_powell_objective_function(double *chi, POWELL *powell);

void minimize_rotamer_on_backbone(PROTEIN *protein, GENE gene, mini_pdbATOM *fixed_atoms, mini_pdbATOM *CB_atom);


void trim_LOOKUP_ROTAMER_X_HBOND(LOOKUP_ROTAMER_X_HBOND **lookupRotX_hbond);

#endif
