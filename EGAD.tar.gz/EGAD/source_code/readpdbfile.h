/* EGAD: readpdbfile.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for readpdbfile.cpp
   
*/


#ifndef readpdbfile_header_flag
#define readpdbfile_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "pdbATOM_utilities.h"
#include "GENES_pdb.h"
#include "VARIABLE_POSITION.h"
#include "dihedral_cartesian.h"
#include "GA_utilities.h"
#include "io.h"
#include "output_stuff.h"

/* reads a pdb file; rearrange_flag=1 means rebuild with extracted dihedral angles.
	If MAX_ATOMS or MAX_RESIDUES is too small, it resets them, and returns 0.
	If 0 is returned, read again (now with adjusted MAX_ATOMS and MAX_RESIDUES
*/
int readpdbfile(char *pdbfilename, PROTEIN *protein, int rearrange_flag);


void rotamer_build(PROTEIN *protein, char *custom_rotamer_file);

#endif
