/* EGAD: rotamer_calc_master.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for rotamer_calc_master.cpp
   
*/


#ifndef rotamer_calc_master_header_flag
#define rotamer_calc_master_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "energy_functions.h"

/* returns the number of slave files listed in the slavefilelist file that have yet to be launched */
int number_of_slaves_left(char slavefilelist[]);

void wait_for_slaves_to_finish(char slavefilelist[]);

/* given an EGAD output pdb file pdbfilename, return an ENERGY struct with the energy components */
void get_ENERGY_and_SASA_SUM_from_egad_pdb_file(char *pdbfilename,ENERGY *energy, SASA_SUM *sasa_sum,
										double *fraction_sasa_hphob, double *transfer_free_energy_density);

void pdbfile_to_CHROMOSOME(char *filename, CHROMOSOME *chr);

#endif

