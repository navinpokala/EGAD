/* EGAD: search_and_sort.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for search_and_sort.cpp
   
*/

#ifndef search_and_sort_header_flag
#define search_and_sort_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"


/* use these for bsearch/qsort */
/* return int that is <,=,> 0 depending on how the two arguments are related (<, =, >) */
/* nomenclature: xxx_yyy */
/* xxx = element being compared; yyy  = structure-type */

/* RESPARAM residuetype comparision function for bsearch/qsort */
int restypecompare_resparam(const void *node1, const void *node2);

/* ROTAMERLIB residuetype comparision function for bsearch/qsort */
int restypecompare_rotamerlib(const void *node1, const void *node2);

/* ATOMRESPARAM atomname comparision function for bsearch/qsort */
int atomnamecompare_atomresparam(const void *node1, const void *node2);


/* Binary search for a specific atomname in an sorted array of ATOMRESPARAM 
   Returns the index of the array position */
int search_atomname_ATOMRESPARAM(const char *atomname, ATOMRESPARAM atomresparam[]);

/* Binary search for a specific residuetype in an array of RESPARAM; 
   Returns the index of the array position 	*/ 
int search_residuetype_RESPARAM(const char *residuetype, RESPARAM resparam[]);

/* sorts an array of CHROMOSOMEs by energy (lowest energy-->highest), using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_CHROMOSOME(int *first, int *last, CHROMOSOME chr[]);


/* sorts an array of ROTAMER by freq (highest->lowest), using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_ROTAMER(int *first, int *last, ROTAMER rotamer[]);

/* sorts an array of int by value (lowest->highest), using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_int(int *first, int *last, int arrayint[]);

/* sorts an array of CHOICE by resparam_ptr->one_letter_code, using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_CHOICE(int *first, int *last, CHOICE arrayint[]);

/* sorts an array of double by value (lowest->highest), using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_double(int *first, int *last, double arraydouble[]);

/* sorts an array of double by value (highest->lowest); ie: by rank;
	opposite order of sort_double. 
  	first=1; last = size of array. 
*/ 
void rank_sort_double(int *first, int *last, double arraydouble[]);

/* sorts an array of VARIABLE_POSITION by seq_position (lowest->highest), using the quicksort algorithm  
  first=1; last = size of array 
*/ 
void sort_VARIABLE_POSITION(int *first, int *last, VARIABLE_POSITION varpos[]);

#endif
