/* EGAD: rotamer_calc_foreman.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for rotamer_calc_foreman.cpp
   
*/


#ifndef rotamer_calc_foreman_header_flag
#define rotamer_calc_foreman_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "GA.h"
#include "output_stuff.h"
#include "MC.h"
#include "scmf.h"
#include "lookup_table.h"
#include "output_stuff.h"
#include "input_stuff.h"
#include "somewhat_FASTER.h"

/* get the var_pos in input_protein to hook up w/ the lookup table in original_protein  
  define in use flags, etc  
  working_protein can be used as input for optimization functions, etc */
void share_lookup_table(PROTEIN *original_protein, PROTEIN *input_protein, PROTEIN *working_protein);

/* opens original_protein->parameters.slave_file_list_filename, goes through the list of files, 
	launches slave optimization jobs 
*/
void rotamer_calc_foreman(char *inputfilename, PROTEIN *original_protein);


#endif
