// ****************************************************************************
// Name: BoundingEnergy.cpp
// By: Mark Voorhies
// On: 6/10/2003
// Time-stamp: <BoundingEnergy.cpp 2003-07-16 18:45:40 Mark Voorhies>
// Impliments: BoundingEnergy.h
// ****************************************************************************

#include "BoundingEnergy.h"
#include "FixedSequence.h"
#include "DeeSpace.h"

#include <algorithm> // for min
#include <iostream>

using namespace std;

// Internal functions for calculating pieces of the bounding energy

// Energy for the fixed positions
InfDouble fixed_bound_energy(const DeeSpace& energy,
			     const FixedSequence& f);
// Best case energy for the remaining positions
InfDouble var_bound_energy(const DeeSpace& energy,
			   const FixedSequence& f);
// Energy for variable resimer r interacting with the fixed positions
InfDouble single_bound_energy(const DeeSpace& energy,
			      const FixedSequence& f,
			      const FixedSequence::resimer_iterator& r);
// Best case energy for variable resimer r interacting with the variable
// positions (There is a look-up table based implimentation for this
// if BoundingEnergy is to be called multiple times for similar values of f)
InfDouble double_bound_energy(const DeeSpace& energy,
			      const FixedSequence& f,
			      const FixedSequence::resimer_iterator& r);

InfDouble BoundingEnergy(const DeeSpace& energy,
			 const FixedSequence& f)
{
  return fixed_bound_energy(energy, f) + var_bound_energy(energy, f);
}

InfDouble fixed_bound_energy(const DeeSpace& energy,
			     const FixedSequence& f)
{
  InfDouble e(0.0);
  
  for(FixedSequence::fixed_iterator i = f.fixed_begin();
      i != f.fixed_end(); ++i)
    {
      for(FixedSequence::fixed_iterator j = f.fixed_begin();
	  j != f.fixed_end(); ++j)
	{ 
	  if(j != i)
	    {
	      e += energy.pair_energy((*i).pos, (*i).res, (*j).pos, (*j).res);
	    }
	}
    }
  return e;
}

InfDouble var_bound_energy(const DeeSpace& energy,
			   const FixedSequence& f)
{
  InfDouble e(0.0);
  
  // Loop over variable positions
  for(FixedSequence::variable_iterator i = f.var_begin();
      i != f.var_end(); ++i)
    {
      InfDouble cur_min(1.0, true); // init cur_min to +infinity
      
      // Loop over resimers at i
      for(FixedSequence::resimer_iterator r = i.resimers_begin();
	  r != i.resimers_end(); ++r)
	{
	  InfDouble e_temp = 
	    single_bound_energy(energy, f, r) * 2.0 +
	    double_bound_energy(energy, f, r);
	  cur_min = min(e_temp, cur_min);
	}
      //cout << "min_r(" << *i << ") = " << cur_min.String() << endl;
      e += cur_min;
    }
  return e;
}

InfDouble single_bound_energy(const DeeSpace& energy,
			      const FixedSequence& f,
			      const FixedSequence::resimer_iterator& r)
{
  InfDouble e(0.0);
  
  for(FixedSequence::fixed_iterator j = f.fixed_begin();
      j != f.fixed_end(); ++j)
    {
      // Assuming r_i is never DEP with j_s (true if the r_i iterator is
      // implimented correctly in the outer loop)
      e += energy.pair_energy((*r).pos,(*r).res,(*j).pos,(*j).res);
    }
  return e;
}

InfDouble double_bound_energy(const DeeSpace& energy,
			      const FixedSequence& f,
			      const FixedSequence::resimer_iterator& r)
{
  InfDouble e(0.0);
  
  for(FixedSequence::variable_iterator j = f.var_begin();
      j != f.var_end(); ++j)
    {
      if(*j == (*r).pos)
	{
	  continue;
	}
      InfDouble cur_min(1.0, true); // init cur_min to +infinity
      for(FixedSequence::resimer_iterator s = j.resimers_begin();
	  s != j.resimers_end(); ++s)
	{
	  cur_min = min(cur_min,
			InfDouble(energy.pair_energy((*r).pos,(*r).res,
						     (*s).pos,(*s).res))); 
	}
      e += cur_min;
    }
  return e;
}
