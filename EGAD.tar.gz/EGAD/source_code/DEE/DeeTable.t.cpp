// ****************************************************************************
// Name: DeeTable.t.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <DeeTable.t.cpp 2003-07-10 13:31:36 Mark Voorhies>
// Tests: DeeTable.h
// ****************************************************************************

#include "DeeTable.h"
#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

using namespace std;

int main(int argc, char *argv[])
{

  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2)
    {
      cerr << "Usage: DeeTable.t input_file" << endl;
      cerr << "   where input_file is a valid EGAD input file" << endl;
      return EXIT_FAILURE;
    }
  string input_file = argv[1];

  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================
  
  PROTEIN *protein;
  if(!(protein = DeeInit(input_file)))
    {
      cerr << "Error initializing energy table!" << endl;
      return EXIT_FAILURE;
    }

  // ============================================================
  //  Construct DeeTable linked to ProteinDeeSpace
  // ============================================================

  // Construction, assignment, destruction

  ProteinDeeSpace space(protein);
  DeeTable eliminated(&space);

  // ============================================================
  //  Test accessor functions
  // ============================================================

  cout << "Dumping elimination table" << endl;

  eliminated.Dump();

  cout << "Eliminating resimer (0,1)" << endl;
  eliminated.Eliminate(0,1);
  cout << "Eliminating pair (0,0,1,1)" << endl;
  eliminated.Eliminate(0,0,1,1);

  eliminated.Dump();

  unsigned int count = 0, max_count = 100000;

  cout << "Accessing up to " << max_count 
       << " elimination flags: " << endl;

  for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i)
    {
      cout << "i = " << i << endl;
      cout << eliminated.AvailableResimers(i) << " resimers available" << endl;
      for(unsigned int j = i; (j < space.NumPos())&&(count < max_count); ++j)
	{
	  cout << "j = " << j << endl;
	  for(unsigned int r = 0; 
	      (r < space.NumResimers(i))&&(count < max_count); ++r)
	    {
	      for(unsigned int s = 0; 
		  (s < space.NumResimers(j))&&(count < max_count); ++s)
		{
		  cout << " " << eliminated.Get(i,r,j,s);
		  ++count;
		}
	      cout << endl;
	    }
	  cout << endl << endl;
	}
      cout << endl << endl;
    }

  // Unification
  
  if(space.NumPos() < 6)
    {
      cout << "Not enough positions for unification test!" << endl;
    }
  else
    {
      // Perform unification
      
      cout << "Unification test..." << endl;
      // combine positions 3 and 5 (DeeTable first, then DeeSpace)
      eliminated.Unify(3,5);
      space.Unify(3,5); 
      // Note: indices >= 5 have changed
      // combine position 2 with combined position 3/5 (call order reversed)
      space.Unify(2,3); 
      eliminated.Unify(2,3);
      // Note: indices >= 3 have changed
      // combine positions 0 and 1 (argument order permuted)
      eliminated.Unify(1,0);
      space.Unify(0,1); 
      // Note: indices >= 1 have changed
      
      // Re-check accessor functions
      
      eliminated.Dump();
      
      count = 0;
      cout << "Accessing up to " << max_count 
	   << " elimination flags: " << endl;
      
      for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i)
	{
	  cout << "i = " << i << endl;
	  cout << eliminated.AvailableResimers(i) 
	       << " resimers available" << endl;
	  for(unsigned int j = i; 
	      (j < space.NumPos())&&(count < max_count); ++j)
	    {
	      cout << "j = " << j << endl;
	      for(unsigned int r = 0; 
		  (r < space.NumResimers(i))&&(count < max_count); ++r)
		{
	      for(unsigned int s = 0; 
		  (s < space.NumResimers(j))&&(count < max_count); ++s)
		{
		  cout << " " << eliminated.Get(i,r,j,s);
		  ++count;
		}
	      cout << endl;
		}
	      cout << endl << endl;
	    }
	  cout << endl << endl;
	}

      cout << "Pruning test..." << endl;

      space = ProteinDeeSpace(protein);
      eliminated = DeeTable(&space);

      // Note: Argument and call orders are mixed up in the following code
      //       to provide a more rigorous test.  In practice, it is best
      //       to modify the elimination table first, then the space (since
      //       the space is independent of the table) and to call Unify
      //       with the first argument less than the second argument.

      space.FixPos(5,1); // Fix position 5 at choice 1
      eliminated.FixPos(5);
      // Note: indices >= 5 have changed
      eliminated.RemoveRes(3,2); // Remove resimer 2 at position 3
      space.RemoveRes(3,2); 
      space.Unify(2,3); // combine position 2 with combined position 3
      eliminated.Unify(3,2);
      space.RemoveRes(0,3,5); // Remove resimers 3 to 5 at position 0
      eliminated.RemoveRes(0,3,5);

      // Re-check accessor functions
      
      eliminated.Dump();
      
      count = 0;
      cout << "Accessing up to " << max_count 
	   << " elimination flags: " << endl;
      
      for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i)
	{
	  cout << "i = " << i << endl;
	  cout << eliminated.AvailableResimers(i) 
	       << " resimers available" << endl;
	  for(unsigned int j = i; 
	      (j < space.NumPos())&&(count < max_count); ++j)
	    {
	      cout << "j = " << j << endl;
	      for(unsigned int r = 0; 
		  (r < space.NumResimers(i))&&(count < max_count); ++r)
		{
	      for(unsigned int s = 0; 
		  (s < space.NumResimers(j))&&(count < max_count); ++s)
		{
		  cout << " " << eliminated.Get(i,r,j,s);
		  ++count;
		}
	      cout << endl;
		}
	      cout << endl << endl;
	    }
	  cout << endl << endl;
	}
    }

  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);
  
  return EXIT_SUCCESS;
}

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}
