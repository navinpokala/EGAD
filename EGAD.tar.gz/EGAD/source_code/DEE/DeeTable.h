// ****************************************************************************
// Name: DeeTable.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <DeeTable.h 2004-06-28 19:12:34 Mark Voorhies>
// Implimented in: DeeTable.cpp
// Description:
//   A DeeTable represents the elimination table for a dead-end elimination
// problem.  Diagonals of the table are true for uneliminated resimers and
// false for eliminated resimers (e.g. get(0,1) is false if position 0
// resimer 1 has been eliminated).  Off-diagonals of the table are true for
// uneliminated pairs and false for dead ending pairs (DEP's) (e.g.
// get(1,2,3,4) is false if position 1 resimer 2 is a DEP with position 3
// resimer 4).
// ****************************************************************************

#ifndef MSV_DEETABLE_HEADER_FLAG
#define MSV_DEETABLE_HEADER_FLAG

class DeeSpace;

#include <algorithm>
#include <iostream>
#include <vector>

class DeeTable
{
private:
  //  Off diagonal elements of the table, i.e. dead-end pair status
  std::vector<std::vector<std::vector<std::vector<bool> > > > vecDoubles;
  //  Diagonal elements of the table, i.e. resimer elimination status
  std::vector<std::vector<bool> > vecSingles;
  const DeeSpace *space;
public:

  // ============================================================
  //   Construction / Destruction
  // ============================================================

  DeeTable(const DeeSpace *space);
  ~DeeTable(){}

  // ============================================================
  //   Accessor Functions
  // ============================================================

  //  Return table value for position i resimer r, position j resimer s
  bool Get(unsigned int i, unsigned int r, 
	   unsigned int j, unsigned int s) const
  {
    if(i == j)
      {
	if(r == s)
	  {
	    return Get(i, r);
	  }
	else
	  {
	    return false; // eliminated by definition
	  }
      }
    if(i > j)
      {
	std::swap(i, j);
	std::swap(r, s);
      }
    return vecDoubles[i][j - i - 1][r][s];
  }

  //  Return diagonal table value for position i resimer r
  bool Get(unsigned int i, unsigned int r) const
  {
    return vecSingles[i][r];
  }

  // Return the physical design space for the elimination table
  const DeeSpace *Space() const{return space;}

  // Number of uneliminated resimers at position i
  unsigned int AvailableResimers(unsigned int i) const
  {
    unsigned int iRetval = 0;
    // Calculate the bitsum of singles[ipos]. Note: There are faster
    // implimentations than this for bitsums, c.f. Reingold
    for(std::vector<bool>::const_iterator r = vecSingles[i].begin();
	r != vecSingles[i].end(); ++r){
      if(*r){++iRetval;}
    }
    return iRetval;
  }

  // Returns ln(c) where c is an upper limit on the number of uneliminated
  // sequences.
  double LogCombinations() const;

  // Diagnostic dump of elimination table
  void Dump(std::ostream &out = std::cout) const;

  // ============================================================
  //   Modifying Functions
  // ============================================================

  //  Flag position i resimer r, position j resimer s as a dead-end pair.
  //  i == j will result in a core dump
  void Eliminate(unsigned int i, unsigned int r, 
		 unsigned int j, unsigned int s)
  {
    if(i == j)
      {
	if(r == s)
	  {
	    // is this good behavior?
	    std::cerr << "Error: Unexpected elimination on diagonal!" << std::endl;
	    abort();
	    //eliminate(i, r);
	  }
	else
	  {
	    // else = error as we aren't storing that part of the table
	    std::cerr << "Error: Off-diagonal write to DEP table!" << std::endl;
	    abort();
	  }
      }
    if(i > j)
      {
	std::swap(i, j);
	std::swap(r, s);
      }
    vecDoubles[i][j - i - 1][r][s] = false;    
  }

  //  Flag position i resimer r as an eliminated resimer.  Flag all pairs
  //  with i,r as dead-ending pairs.
  void Eliminate(unsigned int i, unsigned int r);

  // Fuse positions i and j into a single "super-rotamer" position.
  // If an equivalent unification is not performed on space, then
  // future behavior is undefined!
  void Unify(unsigned int i, unsigned int j);

  // Remove position i from the space
  void FixPos(unsigned int i);

  // Remove positions i to j from the space
  void FixPos(unsigned int i, unsigned int j);

  // Remove resimer choice r at i from the space.  All indices greater than
  // r at i will be shifted down by 1.
  void RemoveRes(unsigned int i, unsigned int r);

  // Remove resimer choices r through s at i.  All indices greater than s
  // at i will be shifted down by (r - s + 1)
  void RemoveRes(unsigned int i, unsigned int r, unsigned int s);

};

#endif
