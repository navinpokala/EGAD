// ****************************************************************************
// Name: ExhaustiveSearch.cpp
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <ExhaustiveSearch.cpp 2003-07-17 17:14:33 Mark Voorhies>
// Impliments: ExhaustiveSearch.h
// ****************************************************************************

#include "ExhaustiveSearch.h"

#include "DeeSpace.h"
#include "DeeTable.h"

#include <iostream>

using namespace std;

ExhaustiveSolution *ExhaustiveSearch(const DeeTable& eliminated,
				     const int max_nodes)
{
  double cur_energy = 0.0, best_energy = 0.0;
  bool init_flag = false;

  const DeeSpace *space = eliminated.Space();

  // ==================================================
  //   Backtrack Algorithm
  //   Variable names chosen to match Reingold et al.
  //   pg 109
  //   Indexing starts at 0, not at 1
  // ==================================================

  vector<unsigned int> a(space->NumPos()), best_solution(space->NumPos());
  vector<vector<unsigned int> > S(space->NumPos());

  // Initialize first position
  
  //printf("Initializing first position\n");

  for(unsigned int i = 0; i < space->NumResimers(0); ++i)
    {
    //printf("Getting %d, %d\n", 0, i);
    if(eliminated.Get(0, i))
      {
	S[0].push_back(i);
      }
    }

  // Initialize counter (number of nodes visited)

  int count = 0, leaves = 0;

  // Initialize depth

  int k = 0, k_max = int(space->NumPos());

  // Begin backtrack search

 // cout << "Starting backtrack search" << endl;

  while(k > -1){
    while((k < k_max) &&     // S[k >= k_max].size() = 0
	  (S[k].size() > 0)){
      // advance
      a[k] = S[k].back();
      S[k].pop_back();
      ++count;

      if((max_nodes > 0)&&(count > max_nodes)){
	cerr << "max_nodes (" << max_nodes << ") exceeded!" << endl;
	if(init_flag){
	  return new ExhaustiveSolution(best_energy + space->FixedEnergy(), 
					best_solution, space,
					count, leaves, false);
	}
	else{
	  cerr << "No solution found before exit!" << endl;
	  return 0;
	}
      }

      // check for solution
      if(k == k_max - 1){
	++leaves;

	// Calculate current energy (replace this with a more efficient
	// implementation that tracks the accumulated energy at each node)

	cur_energy = 0.0;
	for(unsigned int i = 0; i < space->NumPos(); ++i)
	  {
	    for(unsigned int j = i; j < space->NumPos(); ++j)
	      {
		cur_energy += space->Get(i, a[i], j, a[j]);
	      }
	  }

	if((!init_flag)||(cur_energy < best_energy)){
	  best_energy = cur_energy;
	  // record solution
	  best_solution = a;
	  //copy(a.begin(), a.end(), best_solution.begin());
	  init_flag = true;
	}
      }

      // descend

      ++k;

      if(k < k_max){
	// generate S[k]
	//printf("Generating S[%d]\n", k);
	for(unsigned int i = 0; i < space->NumResimers(k); ++i){
	  if(eliminated.Get(k, i)){
	    bool e_flag = false;
	    for(int k2 = 0; k2 < k; ++k2){
	      if(!eliminated.Get(k2, a[k2], k, i)){
		e_flag = true;
		break;
	      }
	    }
	    if(!e_flag){
	      S[k].push_back(i);
	    }
	  }
	}
      }
    }
    --k; // backtrack
  }

  if(!init_flag){
    cerr << "All possible solutions eliminated!" << endl;
    return 0;
  }

  return new ExhaustiveSolution(best_energy + space->FixedEnergy(), 
				best_solution, space,
				count, leaves, true);
}
