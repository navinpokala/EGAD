// ****************************************************************************
// Name: ExhaustiveSearch.t.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <ExhaustiveSearch.t.cpp 2003-07-17 17:16:07 Mark Voorhies>
// Tests: ExhaustiveSearch.h
// ****************************************************************************

#include "DeeTable.h"
#include "ExhaustiveSearch.h"
#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

using namespace std;

int main(int argc, char *argv[])
{
  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2)
    {
      cerr << "Usage: ExhaustiveSearch.t input_file [maxnodes]" << endl;
      cerr << "   where input_file is a valid EGAD input file" << endl;
      cerr << "     and max_nodes is the maximum number of nodes to explore"
	   << endl;
      return EXIT_FAILURE;
    }
  string input_file = argv[1];

  int iMaxNodes = -1;
  if(argc > 2)
    {
      if(sscanf(argv[2], "%d", &iMaxNodes) != 1)
	{
     	  cerr << "Bad max_nodes value (" << argv[2] 
	       << ")" << endl;
	  return EXIT_FAILURE;
	}
    }
  
  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================
  
  PROTEIN *protein;
  if(!(protein = DeeInit(input_file)))
    {
      cerr << "Error initializing energy table!" << endl;
      return EXIT_FAILURE;
    }

  // ============================================================
  //  Construct DeeTable linked to ProteinDeeSpace
  // ============================================================

  ProteinDeeSpace space(protein);
  DeeTable eliminated(&space);

  // ============================================================
  //  Run ExhaustiveSearch on the DeeTable
  // ============================================================

  cout << "Starting Exhaustive Search" << endl;
  ExhaustiveSolution *sol;
  if(!(sol = ExhaustiveSearch(eliminated, iMaxNodes)))
    {
      cout << "Exhaustive search didn't find any solutions!" << endl;
    }
  else
    {
      cout << "Exhaustive search found E = " << sol->energy;
      if(sol->success)
	{
	  cout << ", which is the global minimum =)" << endl;
	}
      else
	{
	  cout << ", which may not be the global minimum =(" << endl;
	}

      delete sol;
    }

  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);
  
  return EXIT_SUCCESS;
}

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}
