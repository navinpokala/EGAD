// ****************************************************************************
// Name: SplitSingles.h
// By: Mark Sales and Mark Voorhies
// On: 6/3/2003
// Time-stamp: <SplitSingles.h 2003-07-16 10:43:28 Mark Voorhies>
// Implimented in: SplitSingles.cpp
// Description:
//   Impliments the Conformational Split Singles dead-end elimination criterion
//   with split flags.
// ****************************************************************************

#ifndef MSV_SPLIT_SINGLES_HEADER_FLAG
#define MSV_SPLIT_SINGLES_HEADER_FLAG

#include <stdio.h>

class DeeTable;

// Perform one round of Split Singles elimination, returning
// the number of eliminated resimers.  DEP's are flagged using
// the split flags criteria
int SplitSingles(DeeTable& eliminated);

#endif
