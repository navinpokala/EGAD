// ****************************************************************************
// Name: GeneralTest.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <GeneralTest.cpp 2003-07-18 19:00:11 Mark Voorhies>
// Tests: This is a sandbox for trying out different DEE master cycles.
//        Its intended use is solving real problems with the current
//        bleeding edge code.
// ****************************************************************************

#include "DeeTable.h"
#include "BoundingSingles.h"
#include "ExhaustiveSearch.h"
#include "GoldsteinSingles.h"
#include "SplitSingles.h"
#include "LogicalSingles.h"
#include "MagicBulletDoubles.h"
#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <math.h>              // For log
#include <stdio.h>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

int Unify(DeeTable& eliminated, DeeSpace& space);
int CleanUp(DeeTable& eliminated, DeeSpace& space, 
	    const int iMaxNodes = -1,
	    const double& dLogBailout = 11.55);

using namespace std;

int main(int argc, char *argv[])
{

  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2)
    {
      cerr << "Usage: GeneralTest input_file [bounding_energy]" << endl;
      cerr << "   where input_file is a valid EGAD input file" << endl;
      cerr << "     and bounding_energy is a reference energy" << endl;
      cerr << "         greater than or equal to the GMEC energy" << endl;
      return EXIT_FAILURE;
    }
  string input_file = argv[1];

  double dRefEnergy = 0.0;
  bool bUseRefEnergy = false;
  if(argc > 2)
    {
      if(sscanf(argv[2], "%lf", &dRefEnergy) == 1)
	{
	  bUseRefEnergy = true;
	}
      else
	{
	  cerr << "Bad reference energy (" << argv[2] 
	       << ") -> ignoring" << endl;
	}
    }

  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================
  
  PROTEIN *protein;
  if(!(protein = DeeInit(input_file)))
    {
      cerr << "Error initializing energy table!" << endl;
      return EXIT_FAILURE;
    }

  // ============================================================
  //  Construct DeeTable linked to ProteinDeeSpace
  // ============================================================

  ProteinDeeSpace space(protein);
  DeeTable eliminated(&space);

  // ============================================================
  //  DEE Master Cycle
  // ============================================================

  // The following two variables should be command line parameters
  int iMaxNodes = 1000000;
  double dLogBailout = 11.55;

  unsigned int iElimCount = 0;

  int iMode = 0; // iMode chooses which type of costly algorithm to apply at the end of each
  //                pass

  while(space.NumPos() > 0)
    {
      cout << "Starting Goldstein Singles" << endl;
  
      while((iElimCount = GoldsteinSingles(eliminated)) > 0)
	{
	  cout <<"Goldstein Singles eliminated " << iElimCount << " resimers, <= 10^" 
	       << eliminated.LogCombinations()/log(10.0) << " solutions remaining" 
	       << endl;
	}
      if(CleanUp(eliminated, space, iMaxNodes, dLogBailout) == 0)
	{
	  break;
	}

      cout << "Starting Split Singles" << endl;
  
      while((iElimCount = SplitSingles(eliminated)) > 0)
	{
	  cout <<"Split Singles eliminated " << iElimCount << " resimers, <= 10^" 
	       << eliminated.LogCombinations()/log(10.0) << " solutions remaining" 
	       << endl;
	}
      if(CleanUp(eliminated, space, iMaxNodes, dLogBailout) == 0)
	{
	  break;
	}

      if(bUseRefEnergy)
	{
	  
	  cout << "Starting Bounding Singles (ref = " << dRefEnergy
	       << ")" << endl;
	  
	  while((iElimCount = BoundingSingles(eliminated, dRefEnergy)) > 0)
	    {
	      cout <<"Bounding Singles eliminated " << iElimCount << " resimers, <= 10^" 
	       << eliminated.LogCombinations()/log(10.0) << " solutions remaining" 
	       << endl;
	    }
	  if(CleanUp(eliminated, space, iMaxNodes, dLogBailout) == 0)
	    {
	      break;
	    }
	}
      switch(iMode)
	{
	case 0:
	  cout << "Starting Magic Bullet Doubles" << endl;
	  iElimCount = MagicBulletDoubles(eliminated);
	  if(iElimCount > 0)
	    {
	      cout << "MagicBulletDoubles eliminated " << iElimCount << " resimer pairs" << endl;
	    }
	  break;
	default: 
	  Unify(eliminated, space);
	  break;
	};
      iMode = (iMode + 1) % 2;
      if(CleanUp(eliminated, space, iMaxNodes, dLogBailout) == 0)
	{
	  break;
	}
    }

  space.DumpFixedPositions();

  cout << "Final energy for converged positions: " << space.FixedEnergy()
       << endl;
  printf("(Final energy = %f)\n", space.FixedEnergy());

  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);
  
  return EXIT_SUCCESS;
}

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}

int Unify(DeeTable& eliminated, DeeSpace& space)
{
  if(space.NumPos() < 2)
    {
      cout << "Can't unify, only " << space.NumPos() << " positions remaining!" << endl;
      return 0;
    }

  // Find the pair of unifiable positions that require the least
  // memory allocation

  unsigned int iPos1 = 0, iPos2 = 0; 
  //unsigned int iCurMem = 0, iMemRequired = 0;
  double dBestDEP = 0.0, dCurDEP = 0.0;
  bool bInitFlag = false;

  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(eliminated.AvailableResimers(i) < 2)
	{
	  continue;
	}
      for(unsigned int j = i + 1; j < space.NumPos(); ++j)
	{
	  if(eliminated.AvailableResimers(j) < 2)
	    {
	      continue;
	    }

	  // The following block chooses positions to unify based
	  // on minimizing required memory

	  //iCurMem = space.NumResimers(i) * space.NumResimers(j);
	  //if((!bInitFlag) || (iCurMem < iMemRequired))
	  //  {
	  //    bInitFlag = true;
	  //    iPos1 = i;
	  //    iPos2 = j;
	  //    iMemRequired = iCurMem;
	  //  }

	  // The following block chooses positions to unify based
	  // on maximizing DEP's

	  dCurDEP = 0.0;
	  for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	    {
	      for(unsigned int s = 0; s < space.NumResimers(j); ++s)
	  	{
	  	  if(!eliminated.Get(i,r,j,s))
	  	    {
	  	      dCurDEP += 1.0;
	  	    }
	  	}
	   }
	  // Set dCurDEP to fraction of DEP's for i and j
	  dCurDEP /= double(space.NumResimers(i)*space.NumResimers(j));
	  if((!bInitFlag) || (dCurDEP > dBestDEP))
	    {
	      bInitFlag = true;
	      iPos1 = i;
	      iPos2 = j;
	      dBestDEP = dCurDEP;
	    }
	}
    }
  if(!bInitFlag)
    {
      cout << "Unexpectedly ununifiable space!" << endl;
      return 0;
    }

  // Unify the chosen positions

  cout << "Unifying " << iPos1 << " with " << iPos2 << endl;

  eliminated.Unify(iPos1, iPos2);
  space.Unify(iPos1, iPos2);
  
  return 1;
}

int CleanUp(DeeTable& eliminated, DeeSpace& space, 
	    const int iMaxNodes,
	    const double& dLogBailout)
{
  // Make sure the table is logically self consistent

  int iElimCount = 0;
  while((iElimCount = LogicalSingles(eliminated)) > 0)
    {
      cout <<"Logical Singles eliminated " << iElimCount << " resimers, <= 10^" 
	   << eliminated.LogCombinations()/log(10.0) << " solutions remaining" 
	   << endl;
    }

  // Prune solved parts of the table

  cout << "Pruning table..." << endl;

  list<unsigned int> fix_list;
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(eliminated.AvailableResimers(i) < 2)
	{   
	  fix_list.push_front(i);
	}
      else
	{
	  list<unsigned int> rem_list;
	  for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	    {
	      if(!eliminated.Get(i,r))
		{
		  rem_list.push_front(r);
		}
	    }
	  for(list<unsigned int>::iterator r = rem_list.begin();
	      r != rem_list.end(); ++r)
	    {
	      eliminated.RemoveRes(i,*r);
	      space.RemoveRes(i,*r);
	    }
	}
    }
  for(list<unsigned int>::iterator i = fix_list.begin();
      i != fix_list.end(); ++i)
    {
      unsigned int best = 0;
      for(unsigned int r = 0; r < space.NumResimers(*i); ++r)
	{
	  if(eliminated.Get(*i,r))
	    {
	      best = r;
	    }
	}
      cout << "Fixing " << *i << " to " << best << endl;
      cout << "(" << space.PosID(*i) << ", "
	   << space.ResType(*i, best) << ", "
	   << space.ResimerID(*i, best) << ")" << endl;
      space.FixPos(*i,best);
      eliminated.FixPos(*i);
    }

  // Check for a unique solution

  double dUpperLimit = eliminated.LogCombinations();

  if(dUpperLimit == 0)
    {
      cout << "Only one possible sequence remaining" << endl;
      return 0;
    }

  // Check for complete unification

  if(space.NumPos() == 1)
    {
      cout << "Only one remaining position, solving by trivial minimization..." << endl;
      double dBestEnergy = space.Get(0,0);
      unsigned int iBestResimer = 0;
      for(unsigned int r = 1; r < space.NumResimers(0); ++r)
	{
	  double dTemp;
	  if((dTemp = space.Get(0, r)) < dBestEnergy)
	    {
	      dBestEnergy = dTemp;
	      iBestResimer = r;
	    }
	}
      cout << "Fixing " << space.PosID(0) << " to " 
	   << space.ResimerID(0, iBestResimer) << endl;
      space.FixPos(0, iBestResimer);
      return 0;
    }

  // Check if the problem is now small enough to solve by brute force

  if(dUpperLimit < dLogBailout)
    {
      cout << "Starting exhaustive search..." << endl;
      ExhaustiveSolution *sol = 0;
      if(!(sol = ExhaustiveSearch(eliminated, iMaxNodes)))
	{
	  cout << "Exhaustive search couldn't find a solution!" << endl;
	  // Note: at this point, we should default to MC
	  return 0;
	}
      if(sol->success)
	{
	  cout << "Exhaustive search found a global minimum!" << endl;
	}
      else
	{
	  cout << "Exhaustive search terminated before exploring the entire space!" << endl;
	}
 
      // Use exhaustive search solution to fix remaining design space
      for(vector<unsigned int>::const_iterator i = sol->resimers.begin();
	  i != sol->resimers.end(); ++i)
	{
	  space.FixPos(0, *i);
	}
      delete sol;
      return 0;
    }

  // Done cleaning up, proceed to more elimination

  return 1;
}
