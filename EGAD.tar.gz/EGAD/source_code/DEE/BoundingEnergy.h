// ****************************************************************************
// Name: BoundingEnergy.h
// By: Mark Voorhies
// On: 6/10/2003
// Time-stamp: <BoundingEnergy.h 2003-07-16 18:43:43 Mark Voorhies>
// Implimented in: BoundingEnergy.cpp
// Description:
//   Impliments bounding energies for use in Branch and Terminate algorithm
//  as described in Gordon & Mayo Structure 7: 1089-1098 (1999)
// ****************************************************************************

#ifndef MSV_BOUNDINGENERGY_HEADER_FLAG
#define MSV_BOUNDINGENERGY_HEADER_FLAG

#include "InfDouble.h"

class DeeSpace;
class FixedSequence;

// Calculate the bounding (best case) energy for sequences containing
// the subsequence f

InfDouble BoundingEnergy(const DeeSpace& energy,
			 const FixedSequence& f);

#endif
