// *****************************************************************************
// Name: MagicBulletDoubles.cpp
// By: Mehagan Hopkins, adapted by Mark Voorhies
// On: 6/3/2003
// Time-stamp: <MagicBulletDoubles.cpp 2003-07-18 18:34:23 Mark Voorhies>
// Impliments: MagicBulletDoubles.h
// *****************************************************************************

#include "MagicBulletDoubles.h"
#include "DeeSpace.h"
#include "DeeTable.h"

#include <iostream>
#include <vector>

struct doubles_info{
  unsigned int r, s;
  double minE, maxE;
  
  doubles_info(){}
  doubles_info(const int ri, const int si, 
	       const double& mini, const double& maxi) :
    r(ri), s(si), minE(mini), maxE(maxi){}
};

// Test doubles equivalent of simple DEE criterion
bool doubles_simple(const unsigned int i_pos, const unsigned int j_pos, 
		    const doubles_info& best_pair,
		    const doubles_info& m,
		    const DeeTable& eliminated);

bool doubles_goldstein(const unsigned int i_pos, const unsigned int j_pos, 
		       const doubles_info& best_pair,
		       const doubles_info& m,
		       const DeeTable& eliminated,
		       const DeeSpace& space);

// Return a list of non-DEP's for i_pos, j_pos with best/worst case energies
std::vector<doubles_info> 
*doubles_max_min(const unsigned int i_pos, const unsigned int j_pos, 
		 int& elim_count, const DeeSpace& space,
		 DeeTable& eliminated);

int add_max_min(std::vector<doubles_info> *max_min_list,
		const unsigned int i_pos, const unsigned int j_pos, 
		const unsigned int r, const unsigned int s,
		const DeeSpace& space,
		DeeTable& eliminated);

using namespace std;

int MagicBulletDoubles(DeeTable& eliminated)
{
  const DeeSpace *space = eliminated.Space();
  
  // Loop over every pair of positions i and j

  vector<doubles_info> *max_min_list = 0;
  int elim_count = 0; // number of DEP's eliminated

  for(unsigned int i_pos = 0; i_pos < space->NumPos(); ++i_pos){
    for(unsigned int j_pos = i_pos + 1; j_pos < space->NumPos(); ++j_pos){

      // Generate a list of best/worst case energies for each non-DEP
      // (i,r),(j,s) [also excludes logically eliminated pairs]
      // Logically eliminated pairs will be eliminated during list generation
      // and elim_count will be updated accordingly

       max_min_list = 
	 doubles_max_min(i_pos, j_pos, elim_count,
			 *space, eliminated);
       if(!max_min_list){
	 cerr << "Error generating max_min_list in MagicBulletDoubles" << endl;
       }
       if(max_min_list->size() <= 1){
	 // Only one valid pair -> can't do doubles elimination
	 continue;
       }

       // First pass: Find the lowest maximum energy among the pairs
       //             and save this magic bullet pair
       // min_{r,s} [E(i_r) + E(j_s) + 
       // \sum_{k!=i, k!=j} max_{t} [E(i_r,k_t)+E(j_s,k_t)]]
       // where (k_t,i_r) and (k_t,j_s) DEP's are ignored

       vector<doubles_info>::const_iterator best_pair = max_min_list->begin();
       double lowest_max = max_min_list->front().maxE;
       
       for(vector<doubles_info>::const_iterator m = max_min_list->begin();
	   m != max_min_list->end(); ++m){
	  if((*m).maxE < lowest_max){
	    // reset lowest_max to the lowest maximum energy
	    lowest_max = (*m).maxE;
	    best_pair = m;
	  }
       }

       // Second pass: Apply elimination criteria using the magic bullet

       for(vector<doubles_info>::const_iterator m = max_min_list->begin();
	   m != max_min_list->end(); ++m){
	 // loop over pairs other than the magic bullet pair
	 if(m != best_pair){
	    
	   // Apply doubles equivalent of simple DEE criterion

	   if((doubles_simple(i_pos, j_pos, (*best_pair),
			      (*m), eliminated))||
	      // Apply doubles equivalent of Goldstein criterion

	      (doubles_goldstein(i_pos, j_pos, (*best_pair),
				 (*m), eliminated, *space))){
	     eliminated.Eliminate(i_pos, (*m).r, j_pos, (*m).s);
	     ++elim_count;
	   }
	 }
       }
       delete max_min_list;
    } // next j
  } // next i
  return elim_count;
}

bool doubles_goldstein(const unsigned int i_pos, const unsigned int j_pos, 
		       const doubles_info& best_pair,
		       const doubles_info& m,
		       const DeeTable& eliminated,
		       const DeeSpace& space){

  // Calculate difference between the self energies

  double total_diff = 
    (space.Get(i_pos, m.r) + 
     space.Get(j_pos, m.s) + 
     space.Get(i_pos, m.r, j_pos, m.s)) -
 
    (space.Get(i_pos, best_pair.r) + 
     space.Get(j_pos, best_pair.s) + 
     space.Get(i_pos, best_pair.r, j_pos, best_pair.s));

  // Loop over not i/j positions  
  for(unsigned int k_pos = 0; k_pos < space.NumPos(); ++k_pos){
    if((k_pos != i_pos)&&(k_pos != j_pos)){
      bool flag = false;  // No t at k has been calculated yet
      double min_diff = 0.0, diffE = 0.0;
      for(unsigned int t = 0; t < space.NumResimers(k_pos); ++t){
	if((eliminated.Get(k_pos,t))&&
	   // If this resimer is not DEP with the target pair
	   (eliminated.Get(i_pos, m.r, k_pos, t))&&
	   (eliminated.Get(j_pos, m.s, k_pos, t))){
	  // If the magic bullet is DEP with this resimer (and the target isn't)
	  // then we can't use the magic bullet to eliminate the target
	  if((eliminated.Get(i_pos, best_pair.r, k_pos, t))||
	     (eliminated.Get(j_pos, best_pair.s, k_pos, t))){
	    return false;
	  }
	  // Update the best-case scenario at this position
	  diffE = 
	    (space.Get(i_pos, m.r, k_pos, t) +
	     space.Get(j_pos, m.s, k_pos, t)) -
	    (space.Get(i_pos, best_pair.r, k_pos, t) +
	     space.Get(j_pos, best_pair.s, k_pos, t));
	  if((flag)||(diffE < min_diff)){
	    flag = true;
	    min_diff = diffE;
	  }
	}
      }
      if(!flag){
	// All t's at k are DEP with the target; therefore, the target
	// can be logically eliminated
	return true;
      }
      // Update the energy difference to include this position
      total_diff += min_diff;
    }
  }
  if(total_diff > 0.0){
    // The target pair can be eliminated by the magic bullet pair based
    // on the Goldstein doubles criterion
    return true;
  }
  // The target position can not be eliminated
  return false;
}

// Apply doubles equivalent of simple singles criterion
bool doubles_simple(const unsigned int i_pos, const unsigned int j_pos, 
		    const doubles_info& best_pair,
		    const doubles_info& m,
		    const DeeTable& eliminated){

  const DeeSpace *space = eliminated.Space();

  // First, check simple DEE criterion	
		   
  if(m.minE <= best_pair.maxE){
    return false;
  }

  // Next, make sure the eliminating pair is not DEP with the background
  // used to find minE for the eliminated pair

  for(unsigned int k_pos = 0; k_pos < space->NumPos(); ++k_pos){
    if((k_pos != i_pos) && (k_pos != j_pos)){
      for(unsigned int t = 0; t < space->NumResimers(k_pos); ++t){
	// if k_t has not been eliminated
	if((eliminated.Get(k_pos, t))&&
	   // and the current pair can exist in a k_t background
	   (eliminated.Get(k_pos, t, i_pos, m.r))&&
	   (eliminated.Get(k_pos, t, j_pos, m.s))&&
	     // and the magic bullet can't exist in a k_t background
	   (
	    (!eliminated.Get(k_pos, t, i_pos, best_pair.r))||
	    (!eliminated.Get(k_pos, t, j_pos, best_pair.s))
	    )
	   ){
	  // then the magic bullet can't eliminate this pair
	  return false;
	}
      }
    }
  }
  return true;
}

// Return a list of non-DEP's for i_pos, j_pos with best/worst case energies
std::vector<doubles_info> 
*doubles_max_min(const unsigned int i_pos, const unsigned int j_pos, 
		 int& elim_count, const DeeSpace& space,
		 DeeTable& eliminated){
  vector<doubles_info> *max_min_list = new(vector<doubles_info>);

  // for each uneliminated pair ir,js

  for(unsigned int r = 0; r < space.NumResimers(i_pos); ++r){
    if(eliminated.Get(i_pos, r)){
      for(unsigned int s = 0; s < space.NumResimers(j_pos); ++s){
	if(eliminated.Get(j_pos, s) &&
	   eliminated.Get(i_pos, r, j_pos, s)){

	  // Try adding i_r, j_s to the list.  If (i_r,j_s) can be
	  // logically eliminated, (i_r,j_s) will be eliminated instead
	  // of being added to the list and a value of 1 (instead of 0)
	  // will be returned.

	  elim_count += add_max_min(max_min_list, i_pos, j_pos, r, s, 
				    space, eliminated);
	}
      } // end s loop
    }
  }
  return max_min_list;
}

int add_max_min(vector<doubles_info> *max_min_list,
		const unsigned int i_pos, const unsigned int j_pos, 
		const unsigned int r, const unsigned int s,
		const DeeSpace& space,
		DeeTable& eliminated){

  double self_energy = 
    space.Get(i_pos, r) + space.Get(i_pos, r, j_pos, s) +
    space.Get(j_pos, s);
  
  doubles_info cur_info(r, s, self_energy, self_energy);
  
  // Loop over the background of all other positions
  for(unsigned int k_pos = 0; k_pos < space.NumPos(); ++k_pos){
    if((k_pos != i_pos) && (k_pos != j_pos)){
      bool flag = false;
      double min = 0.0, max = 0.0;
      for(unsigned int t = 0; t < space.NumResimers(k_pos); ++t){
	if(eliminated.Get(k_pos, t) &&
	   eliminated.Get(k_pos, t, i_pos, r) &&
	   eliminated.Get(k_pos, t, j_pos, s)){
	  double tempE = space.Get(i_pos, r, k_pos, t) +
	    space.Get(j_pos, s, k_pos, t);
	  if((!flag) || (min > tempE)){
	    min = tempE;
	  }
	  if((!flag) || (max < tempE)){
	    max = tempE;
	    flag = true;
	  }
	}
      }

      if(!flag){ // r,s is a dead-end with every choice at k_pos
	// It is possible that this should result in an elimination.
	// Need to check!!!
	return 0;
      }
      else{
	// sum of all max's with self energy (worst case)
	cur_info.maxE += max;
	// sum of all min's with self energy (best case)
	cur_info.minE += min;
      }
    }
  } // end k loop

  // Save the current rotamer pair
  max_min_list->push_back(cur_info);

  return 0; // no eliminations performed
}
