#include "DeeTable.h"
#include "DeeSpace.h"

#include <iostream>
#include <math.h> // for log
#include "../moremath.h"

using namespace std;

DeeTable::DeeTable(const DeeSpace *space_i) : space(space_i)
{
  // cout << "Initializing DeeTable for " << space->NumPos() << " positions"   << endl;

  // cout << "  Initializing singles..." << endl;
  vecSingles = vector<vector<bool> > (space->NumPos());

  for(unsigned int i = 0; i < space->NumPos(); ++i)
    {
      vecSingles[i] = vector<bool>(space->NumResimers(i), true);
    }

 // cout << "  Initializing doubles..." << endl;

  vecDoubles = vector<vector<vector<vector<bool> > > > (space->NumPos() - 1);

  for(unsigned int i = 0; i < space->NumPos() - 1; ++i)
    {
      vecDoubles[i] = 
	vector<vector<vector<bool> > >(space->NumPos() - i - 1);
      for(unsigned int j = i + 1; j < space->NumPos(); ++j)
	{
	  vecDoubles[i][j - i - 1] = vector<vector<bool> >
	    (space->NumResimers(i), 
	     vector<bool>(space->NumResimers(j), true));
	}
    }
}

void DeeTable::Eliminate(unsigned int i, unsigned int r)
{
  for(unsigned int j = 0; j < space->NumPos(); ++j)
    {
      if(j != i)
	{
	  for(unsigned int s = 0; s < space->NumResimers(j); ++s)
	    {
	      Eliminate(i, r, j, s);
	    }
	}
    }
  vecSingles[i][r] = false;
}

double DeeTable::LogCombinations() const
{
  double dLogSum = 0.0;
  unsigned int iCount = 0;
  for(unsigned int i = 0; i < space->NumPos(); ++i)
    {
      iCount = 0;
      for(unsigned int r = 0; r < space->NumResimers(i); ++r)
	{
	  if(Get(i,r))
	    {
	      ++iCount;
	    }
	}
      if(iCount == 0)
	{
	  // If any position is completely eliminated, then there
	  // is no solution
	  return 0.0;
	}
      dLogSum += log(float(iCount));
    }
  return dLogSum;
}

void DeeTable::Dump(std::ostream &out) const
{
  double dLogSum = 0.0;
  for(unsigned int i = 0; i < space->NumPos(); ++i)
    {
      out << "Position " << space->PosID(i) <<" (" << i << "): ";
      int iCount = 0;
      unsigned int iSelected = 0;
      for(unsigned int r = 0; r < space->NumResimers(i); ++r)
	{
	  if(vecSingles[i][r])
	    {
	      iSelected = r;
	      ++iCount;
	    }
	}
      switch(iCount)
	{
	case 0:
	  out << "ALL RESIMERS ELIMINATED!!!" << endl;
	  break;
	case 1:
	  out << "Resimer selected: " << space->ResType(i, iSelected)
	    // DeeSpace::ChiAngles not currently implemented
	    //<< " " << space->ChiAngles(i, selected) << 
	      << " (" << space->ResimerID(i,iSelected) << ")" << endl;
	  break;
	default:
	  out << iCount << " of " << space->NumResimers(i) 
	      << " resimers remaining" << endl;
	  break;
	}
      dLogSum += log(float(iCount));
    }
  out << "At most 10^" << dLogSum/log(10.0)
      << " sequences remaining in the search space." << endl;
}

void DeeTable::Unify(unsigned int i, unsigned int j){
  // Note on implementation: Unification must be coupled for the DeeTable
  //  and the DeeSpace (i.e. if we unify on one and not on the other, their
  //  position and resimer indices will no longer agree).  Because this
  //  coupling is currently implemented at the client level, we can not assume
  //  that the space will be unified after the table.  Therefore, we avoid
  //  using DeeSpace member functions inside of the DeeTable::Unify function.

  // Assert i < j
  if(i > j)
    {
      swap(i,j);
    }

  // ========================================
  //   Merge cells: j information is merged
  //    into cells containing i information
  // ========================================

  //   1) Merge (i,i) with (j,j)

  //   Save elimination information for un-unified position
  vector<bool> vecOldI = vecSingles[i];

  //   Expand position i to include all resimer combinations of i and j
  vecSingles[i].clear();
  vecSingles[i].resize(vecOldI.size()*vecSingles[j].size(), true);

  for(unsigned int r = 0; r < vecOldI.size(); ++r)
    {
      for(unsigned int s = 0; s < vecSingles[j].size(); ++s)
	{
	  //  Any super-resimer pair containing an eliminated position 
	  //  is eliminated
	  if((!vecOldI[r]) || (!vecSingles[j][s]) ||
	     // Any super-resimer pair that is dead-ending is eliminated
	     (!Get(i,r,j,s)))
	    {

	      // Note: This debugging dump assumes space has not been unified
	      //cout << "(" << space->PosID(i) << ", " 
	      //	   << space->ResimerID(i,r) << ", " 
	      //	   << space->PosID(j) << ", "
	      //	   << space->ResimerID(j,s) << ")"
	      //         << " eliminated due to previous elimination or DEP: ";
	      //if(!vecOldI[r])
	      //	{
	      //	  cout << "(" << space->PosID(i) << ", "
	      //	       << space->ResimerID(i,r) << ")";
	      //	}
	      //if(!vecSingles[j][s])
	      //	{
	      //	  cout << "(" << space->PosID(j) << ", "
	      //	       << space->ResimerID(j,s) << ")";
	      //	}
	      //if(!Get(i,r,j,s))
	      //	{
	      //	  cout << "(DEP)";
	      //	}
	      //cout << endl;
	      // Note: We should be able to avoid this multiply step by
	      //       using an additional counter!
	      //vecSingles[i][s*vecOldI.size() + r] = false;

	      vecSingles[i][r*vecSingles[j].size() + s] = false;
	    }
	}
    }

  //   At this point, (i,i) -> (i+j, i+j).  The rest of the matrix
  //   has not been disturbed

  //   2) Merge (i,k) with (j,k) for all k != i,j

  // Pointer to (i,k) cell
  vector<vector<bool> > *ik = 0;

  for(unsigned int k = 0; k < vecSingles.size(); ++k)
    {
      if((k == i)||(k == j))
	{
	  continue;
	}
      // Locate the (i,k) cell
      if(i < k)
	{
	  ik = &(vecDoubles[i][k - i - 1]);
	}
      else
	{
	  ik = &(vecDoubles[k][i - k - 1]);
	}
      // Expand cell (i,k) to include all (i+j,k) pairs, saving
      // the old value
      vector<vector<bool> >vecOldIK(ik->begin(), ik->end());
      if(i < k)
	{
	  ik->clear();
	  ik->resize(vecSingles[i].size(),
		     vector<bool>(vecSingles[k].size(), true));
	}
      else
	{
	  ik->clear();
	  ik->resize(vecSingles[k].size(),
		     vector<bool>(vecSingles[i].size(), true));
	}
      // Merge dead-ending pair information

      unsigned int rs = 0;  // super-resimer index

      for(unsigned int v = 0; v < vecSingles[k].size(); ++v)
	{
	  for(unsigned int r = 0; r < vecOldI.size(); ++r)
	    {
	      for(unsigned int s = 0; s < vecSingles[j].size(); ++s)
		{
		  //rs = s*vecOldI.size() + r;
		  rs = r*vecSingles[j].size() + s;

		  // (v, r+s) is dead-ending if:
		  //    v has been eliminated or
		  if((!Get(k,v))||
		     // r+s has been eliminated or
		     (!Get(i,rs))||
		     // v,s is dead-ending or
		     (!Get(k,v,j,s))||
		     // v,r is dead-ending
		     ((i < k)&&(!vecOldIK[r][v]))||
		     ((i > k)&&(!vecOldIK[v][r])))
		    {
		      if(i < k)
			{
			  (*ik)[rs][v] = false;
			}
		      else
			{
			  (*ik)[v][rs] = false;
			}

		      // Note: This debugging dump assumes space has not 
		      //       been unified
		      //   cout << "([" << space->PosID(i) << ", "
		      //  	       	   << space->PosID(j) << "], ["
		      //  		   << space->ResimerID(i,r) << ", " 
		      //  		     << space->ResimerID(j,s) << "], "
		      //  			   << space->PosID(k) << ", "
		      //  		   << space->ResimerID(k,v) << ")"
		      //  	     << " eliminated during merge" << endl;

		    }
		  //else
		  //  {
		  //    cout << "Keeping (" << i << ", " << rs << ", "
		  //	   << k << ", " << v << ") during merge" << endl;
		  //  }
		}
	    }
	}
    }

  // At this point, there are only three sets of obsolete cells:
  //  obsolete off-diagonal (j, k != i) cells
  //  obsolete (i,j) off-diagonal cell
  //  obsolete (j,j) diagonal cell
  // The state of these cells has not changed from the begining of this 
  // function

  // ========================================
  //   Delete cells: obsolete j information
  //    is removed, shrinking the matrix
  //    (note that this requires a number
  //     of vector copy operations)
  // ========================================


  //   Remove all (j,k) off-diagonal cells

  //     Remove (j,k) cells for k > j
  if(vecDoubles.size() > j)
    {
      vecDoubles.erase(vecDoubles.begin() + j);
    }
  //     Remove (j,k) cells for j > k (this includes (j,i))

  for(unsigned int k = 0; k < min(j, vecDoubles.size()); ++k)
    {
      vecDoubles[k].erase(vecDoubles[k].begin() + j - k - 1);
    }

  //   Remove cell (j,j) from the diagonal
  if(vecSingles.size() > j)
    {
      vecSingles.erase(vecSingles.begin() + j);
    }
}

// Remove position i from the space
void DeeTable::FixPos(unsigned int i)
{
  for(unsigned int k = 0; k < i; ++k)
    {
      vecDoubles[k].erase(vecDoubles[k].begin() + (i - k - 1));
    }
  if(vecDoubles.size() > i)
    {
      vecDoubles.erase(vecDoubles.begin() + i);
    }
  if(vecSingles.size() > i)
    {
      vecSingles.erase(vecSingles.begin() + i);
    }
}

// Remove positions i to j from the space, fixing them to the resimer
void DeeTable::FixPos(unsigned int i, unsigned int j)
{
  // There is a more efficient implementation for this.  For the
  // moment, however, we will code for simplicity =)

  for(; i <= j; ++i) 
    {
      FixPos(i);
    }
}

// Remove resimer choice r at i from the space.  All indices greater than
// r at i will be shifted down by 1.
void DeeTable::RemoveRes(unsigned int i, unsigned int r)
{
  //cout << "Table erasing (" << i << ", " << r << ")" << endl;
  // j < i
  for(unsigned int j = 0; j < i; ++j)
    {
      for(unsigned int v = 0; v < vecSingles[j].size(); ++v)
	{
	  //cout << "Removing (" << j << ", " << i << ", " << v << ", "
	  //     << r << ") size from " << vecDoubles[j][i-j-1][v].size();
	  // This may not compile for certain implementations of vector<bool>
	  // Need to check
	  vecDoubles[j][i-j-1][v].erase(vecDoubles[j][i-j-1][v].begin() + r);
	  //cout << " to " << vecDoubles[j][i-j-1][v].size() << endl;
	}
    }
  // j > i
  for(unsigned int j = i + 1; j < vecSingles.size(); ++j)
    {
      //cout << "Removing (" << i << ", " << j << ", " << r 
      //	   << ", *) size from " << vecDoubles[i][j-i-1].size();
	   
      vecDoubles[i][j-i-1].erase(vecDoubles[i][j-i-1].begin() + r);
      //cout << " to " << vecDoubles[i][j-i-1].size() << endl;
    }
  // j == i
  //cout << "Removing (" << i << ", " << r << ") size from " 
  //     << vecSingles[i].size();
  vecSingles[i].erase(vecSingles[i].begin() + r);
  //cout << " to " << vecSingles[i].size() << endl;
}

// Remove resimer choices r through s at i.  All indices greater than s
// at i will be shifted down by (r - s + 1)
void DeeTable::RemoveRes(unsigned int i, unsigned int r, unsigned int s)
{
  // There is a more efficient implementation for this.  For the
  // moment, however, we will code for simplicity =)

  for(; r <= s; ++r)
    {
      RemoveRes(i,r);
    }
}
