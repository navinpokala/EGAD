// ****************************************************************************
// Name: BoundingSingles.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <BoundingSingles.h 2003-07-17 11:19:07 Mark Voorhies>
// Implimented in: BoundingSingles.cpp
// Description: (out of date)
//   BranchAndTerminate impliments the Branch & Terminate algorithm described
//   in Gordon & Mayo Structure 7:1089-1098 (1999).
//   This can be called in two contexts:
//    1) At the clean-up step of a DEE run (where we currently use 
//       ExhaustiveSearch)
//    2) During a DEE cycle, to "terminate" rotamers and DEP's
//   Since the best interface is different for each context, we should at
//   least have two top-level wrapper functions (and it may be better to
//   set this up as member functions of a class).
// ****************************************************************************

#ifndef MSV_BOUNDINGSINGLES_HEADER_FLAG
#define MSV_BOUNDINGSINGLES_HEADER_FLAG

class DeeTable;

// Eliminate resimers for which E_bound > E_ref
int BoundingSingles(DeeTable& eliminated, double dRefEnergy);

#endif
