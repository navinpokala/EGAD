// ****************************************************************************
// Name: DeeSpace.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <DeeSpace.h 2003-07-15 14:07:18 Mark Voorhies>
// Implimented in: DeeSpace.cpp
// Description:
//   A DeeSpace describes the conformation/sequence space for a DEE run.
// It provides functions for describing the space (NumPos, NumResimers),
// mapping the space to an external format (PosID, ResimerID, and ResType),
// and unifying positions in the space (Unify).
//   The DeeSpace also embeds the interface to the energy table.  The reason
// for this is that the design space and the energy table are inherently
// coupled in their implementation, so it is convenient to fuse the two
// classes.  This may not be the best solution.  The condensed class can be
// thought of as the physical description of the system.
// ****************************************************************************

#ifndef MSV_DEESPACE_HEADER_FLAG
#define MSV_DEESPACE_HEADER_FLAG

#include <string>
#include <vector>

class DeeSpace{
public:
  // ==================================================
  //  Construction/Destruction
  // ==================================================

  virtual ~DeeSpace();

  // ==================================================
  //  Functions definining the design space
  // ==================================================

  // Number of variable positions in the design space
  virtual unsigned int NumPos() const = 0;
  // Number of resimer choices at pos
  virtual unsigned int NumResimers(unsigned int pos) const = 0;

  // ==================================================
  //  Functions describing the design space in terms
  //  of the real world
  // ==================================================

  // Name of position pos (e.g. "28A")
  virtual std::string PosID(unsigned int pos) const = 0;
  // Name of resimer at pos (e.g. "14")
  virtual std::string ResimerID(unsigned int pos, 
				unsigned int resimer) const= 0;
  // Name of residue for resimer at pos (e.g. "GLU")
  virtual std::string ResType(unsigned int pos, 
			      unsigned int resimer) const = 0;
  /*
  // String representation of chi angles for resimer at pos
  virtual std::string ChiAngles(unsigned int pos, 
                                unsigned int resimer) const= 0;
  */

  // Dump resimer values of fixed positions
  virtual void DumpFixedPositions() const = 0;

  // ==================================================
  //   Accessor Functions for the Energy Table
  // ==================================================

  //  Get true sidechain-sidechain energy between two positions
  virtual double Get(unsigned int ipos, unsigned int ires, 
		     unsigned int jpos, unsigned int jres) const = 0;
  //  Get true sidechain-template energy for a single position
  virtual double Get(unsigned int ipos, unsigned int ires) const = 0;

  // pair_energy folds the self energies into the pairwise energy terms
  // (useful for bounding calculations)

  // The diagonal is 0 by definition for pair_energy
  double pair_energy(unsigned int ipos, unsigned int ires) const{
    return 0.0;
  }

  virtual double pair_energy(unsigned int ipos, unsigned int ires, 
			     unsigned int jpos, unsigned int jres) const = 0;

  // Get the component of the energy that is independent of the variable
  // positions.  This value should change when variable positions are
  // removed from the design space.
  virtual double FixedEnergy() const
  {
    return 0.0;
  }

  // ==================================================
  //  Functions modifying the description of the Space
  // ==================================================

  // Fuse positions i and j into a single "super-rotamer" position
  virtual void Unify(unsigned int i, unsigned int j) = 0;

  // Remove position i from the space, fixing it at resimer r
  virtual void FixPos(unsigned int i, unsigned int r) = 0;

  // Remove positions i to j from the space, fixing them to the resimer
  // values in vecR
  virtual void FixPos(unsigned int i, unsigned int j,
		      const std::vector<unsigned int>& vecR) = 0;

  // Remove resimer choice r at i from the space.  All indices greater than
  // r at i will be shifted down by 1.
  virtual void RemoveRes(unsigned int i, unsigned int r) = 0;

  // Remove resimer choices r through s at i.  All indices greater than s
  // at i will be shifted down by (r - s + 1)
  virtual void RemoveRes(unsigned int i, unsigned int r, unsigned int s) = 0;
};

#endif
