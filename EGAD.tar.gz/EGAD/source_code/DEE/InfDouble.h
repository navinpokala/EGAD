// ****************************************************************************
// Name: InfDouble.h
// By: Mark Voorhies
// On: 6/10/2003
// Time-stamp: <InfDouble.h 2004-06-28 19:14:33 Mark Voorhies>
// Implimented in: NA
// Description:
//   Defines the InfDouble class.  An InfDouble is a double that can represent
//   any normal double value as well as infinity, negative infinity, and
//   undefined.  Comparisons to undefined values will create a core dump
//   (this should be replaced by throwing an exception).
// ****************************************************************************

#ifndef MSV_INFDOUBLE_HEADER_FLAG
#define MSV_INFDOUBLE_HEADER_FLAG

#include <string>
#include <stdio.h> // For sprintf.  Replace with iostream version
#include <iostream>

// An InfDouble is a double with an infinity flag
struct InfDouble
{
  double dVal;
  bool bInf;

  InfDouble(const double& vi = 0, const bool& ii = false) 
    : dVal(vi), bInf(ii)
  {
    // empty constructor
  }

  InfDouble(const InfDouble& init) 
    : dVal(init.dVal), bInf(init.bInf)
  {
    // empty constructor
  }

  InfDouble& operator=(const double& rhs)
  {
    dVal = rhs; 
    bInf = false; 
    return *this;
  }

  InfDouble operator+(const InfDouble& rhs) const
  {
    if(!bInf)
      {
	// Addition of non infinite numbers -> regular addition
	if(!(rhs.bInf))
	  {
	    return InfDouble(dVal + rhs.dVal);
	  }
	// Only rhs is infinite -> rhs
	else
	  {
	    return rhs;
	  }
      }
    else
      {
	// Only lhs is infinite -> lhs
	if(!(rhs.bInf))
	  {
	    return *this;
	  }
	// if rhs or lhs is undefined, the result is undefined
	else if((dVal == 0.0)||(rhs.dVal == 0.0))
	  {
	    return InfDouble(0.0, true);
	  }
	// Addition of infinities with the same sign -> no change
	else if(((dVal > 0.0)&&(rhs.dVal > 0.0))||
		((dVal < 0.0)&&(rhs.dVal < 0.0)))
	  {
	    return *this;
	  }
	// Addition of infinities with opposite signs -> undefined
	else
	  {
	    return InfDouble(0.0, true);
	  }
      }
  }

  InfDouble operator+(const double& rhs) const
  {
    if(!bInf){return InfDouble(dVal + rhs);}
    return *this;
  }

  InfDouble operator+=(const InfDouble& rhs)
  {
    if(!bInf)
      {
	// Addition of non infinite numbers -> regular addition
	if(!(rhs.bInf))
	  {
	    dVal += rhs.dVal;
	  }
	// Only rhs is infinite -> rhs
	else
	  {
	    dVal = rhs.dVal; bInf = rhs.bInf;
	  }
      }
    else
      {
	// If rhs or lhs is undefined, the result is undefined
	if((dVal == 0.0)||(rhs.dVal == 0.0))
	  {
	    dVal = 0.0; bInf = true;
	  }
	// The following cases are dealt with implicitly:
	// 1) Only lhs is infinite -> lhs
	// 2) Addition of infinities with the same sign -> no change
	else if((rhs.bInf)&&
		!(((dVal > 0.0)&&(rhs.dVal > 0.0))||
		  ((dVal < 0.0)&&(rhs.dVal < 0.0))))
	  {
	    // Addition of infinities with opposite signs -> undefined
	    dVal = 0.0; bInf = true;
	  }
      }
    return *this;
  }

  InfDouble& operator+=(const double& rhs)
  {
    if(!bInf){dVal += rhs;} return *this;
  }

  InfDouble operator-(const InfDouble& rhs) const
  {
    if(!bInf)
      {
	// Subtraction of non infinite numbers -> regular subtraction
	if(!(rhs.bInf))
	  {
	    return InfDouble(dVal - rhs.dVal);
	  }
	// Only rhs is infinite -> rhs
	else
	  {
	    return rhs;
	  }
      }
    else
      {
	// Only lhs is infinite -> lhs
	if(!(rhs.bInf))
	  {
	    return *this;
	  }
	// Subtraction of infinities with the same sign -> undefined
	// Subtraction where lhs or rhs is undefined -> undefined
	else if((dVal == 0.0)||
		(rhs.dVal == 0.0)||
		((dVal > 0.0)&&(rhs.dVal > 0.0))||
		((dVal < 0.0)&&(rhs.dVal < 0.0)))
	  {
	    return InfDouble(0.0, true);
	  }
	// Subtraction of infinities with opposite signs -> lhs
	else
	  {
	    return *this;
	  }
      }
  }
  
  InfDouble operator-(const double& rhs) const
  {
    if(!bInf){return InfDouble(dVal - rhs);}
    return *this;
  }

  InfDouble operator-=(const InfDouble& rhs)
  {
    if(!bInf)
      {
	// Subtraction of non infinite numbers -> regular subtraction
	if(!(rhs.bInf))
	  {
	    dVal -= rhs.dVal;
	  }
	// Only rhs is infinite -> rhs
	else
	  {
	    dVal = rhs.dVal; bInf = rhs.bInf;
	  }
      }
    else
      {
	// The following cases are dealt with implicitly:
	// 1) Only lhs is infinite -> lhs
	// 2) Subtraction of infinities with opposite signs -> no change
	if((rhs.bInf)&&
	   ((dVal == 0.0)||
	    (rhs.dVal == 0.0)||
	    ((dVal > 0.0)&&(rhs.dVal > 0.0))||
	    ((dVal < 0.0)&&(rhs.dVal < 0.0))))
	  {
	    // Subtraction of infinities with same signs -> undefined
	    dVal = 0.0; bInf = true;
	  }
      }
    return *this;
  }

  InfDouble& operator-=(const double& rhs)
  {
    if(!bInf){dVal -= rhs;} return *this;
  }

  InfDouble operator*(const double& rhs) const
  {
    if(rhs == 0.0)
      {
	return InfDouble(0.0, false);
      }
    else if(!bInf)
      {
	return InfDouble(dVal*rhs, false);
      }
    else
      {
	return *this;
      }
  }

  InfDouble& operator*=(const double& rhs)
  {
    if(rhs == 0.0)
      {
	dVal = 0.0; bInf = false;
      }
    else if(!bInf)
      {
	dVal *= rhs;
      } 
    return *this;
  }

  bool operator<(const InfDouble& rhs) const
  {
    if(!bInf)
      {
	// Non-infinite comparison -> treat as doubles
	if(!rhs.bInf)
	  {
	    return dVal < rhs.dVal;
	  }
	// only rhs is infinite
	else
	  {
	    if(rhs.dVal == 0)
	      {
		std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
		abort();
	      }
	    // lhs < rhs as long as rhs isn't -inf
	    return !(rhs.dVal < 0);
	  }
      }
    // only lhs is infinite
    else if(!rhs.bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	else
	  {
	    // lhs < rhs if lhs == -inf
	    return (dVal < 0);
	  }
      }
    // lhs & rhs infinite
    else
      {
	if((dVal == 0.0)||(rhs.dVal == 0.0))
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	else
	  {
	    // infinities with the same sign are equal.  Therefore,
	// lhs < rhs if and only if lhs < 0 and rhs > 0
	    return ((dVal < 0.0)&&(rhs.dVal > 0.0));
	  }
      }
  }

  bool operator<(const double& rhs) const
  {
    if(bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	return (dVal < 0.0);
      }
    return (dVal < rhs);
  }

  bool operator>(const InfDouble& rhs) const
  {
    if(!bInf)
      {
	// Non-infinite comparison -> treat as doubles
	if(!rhs.bInf)
	  {
	    return dVal > rhs.dVal;
	  }
	// only rhs is infinite
	else
	  {
	    if(rhs.dVal == 0)
	      {
		std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
		abort();
	      }
	    // lhs > rhs as long as rhs isn't +inf
	    return !(rhs.dVal > 0);
	  }
      }
    // only lhs is infinite
    else if(!rhs.bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	else
	  {
	    // lhs > rhs if lhs == +inf
	    return (dVal > 0);
	  }
      }
    // lhs & rhs infinite
    else
      {
	if((dVal == 0.0)||(rhs.dVal == 0.0)){
	  std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	  abort();
	}
	else
	  {
	    // infinities with the same sign are equal.  Therefore,
	    // lhs > rhs if and only if lhs > 0 and rhs < 0
	    return ((dVal > 0.0)&&(rhs.dVal < 0.0));
	  }
      }
  }

  bool operator>(const double& rhs) const
  {
    if(bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	return (dVal > 0.0);
      }
    return (dVal > rhs);
  }

  bool operator==(const InfDouble& rhs) const
  {
    if(!bInf)
      {
	// Non-infinite comparison -> treat as doubles
	if(!rhs.bInf)
	  {
	    return (dVal == rhs.dVal);
	  }
	// only rhs is infinite
	else
	  {
	    if(rhs.dVal == 0)
	      {
		std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
		abort();
	      }
	    // non-infinite != infinite
	    return false;
	  }
      }
    // only lhs is infinite
    else if(!rhs.bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	else
	  {
	    // non-infinite != infiniteTherefore,
	    // lhs > rhs if and only if lhs > 0 and rhs < 0
	    return false;
	  }
      }
    // lhs & rhs infinite
    else
      {
	if((dVal == 0.0)||(rhs.dVal == 0.0))
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	else
	  {
	    // infinities with the same sign are equal.  
	    return (((dVal > 0.0)&&(rhs.dVal > 0.0))||
		    ((dVal < 0.0)&&(rhs.dVal < 0.0)));
	  }
      }
  }
  
  bool operator==(const double& rhs) const
  {
    if(bInf)
      {
	if(dVal == 0.0)
	  {
	    std::cerr << "InfDouble error: comparison to undefined!" << std::endl;
	    abort();
	  }
	return false;
      }
    return (dVal == rhs);
  }
  
  std::string String() const
  {
    if(bInf)
      {
	if(dVal == 0.0)
	  {
	    return "undefined";
	  }
	else if(dVal > 0.0)
	  {
	    return "+infinity";
	  }
	else
	  {
	    return "-infinity";
	  }
      }
    char buffer[80];
    sprintf(buffer, "%f", dVal);
    return std::string(buffer);
  }
};

#endif
