// ****************************************************************************
// Name: LogicalSingles.cpp
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <LogicalSingles.cpp 2003-07-16 19:06:15 Mark Voorhies>
// Impliments: LogicalSingles.h
// ****************************************************************************

#include "LogicalSingles.h"
#include "DeeSpace.h"
#include "DeeTable.h"
#include <iostream>
#include <vector>

using namespace std;

int LogicalSingles(DeeTable& eliminated)
{
  const DeeSpace *pSpace = eliminated.Space();
  unsigned int iElimCount = 0;  // iElimCount is the number of eliminations 
  //                               that have been performed this round

  // Loop over all pairs of positions (i,j)

  for(unsigned int i = 0; i < pSpace->NumPos(); ++i)
    {
      for(unsigned int j = i + 1; j < pSpace->NumPos(); ++j)
	{
	  //cout << "At i = " << i << " j = " << j << endl;

	  // vecSflag[s] is true if j_s can't be eliminated by i
	  vector<bool> vecSflag(pSpace->NumResimers(j), false);
	  for(unsigned int r = 0; r < pSpace->NumResimers(i); ++r)
	    {
	      if(!eliminated.Get(i,r))
		{
		  continue;
		}
	      // bRflag is true if i_r can't be eliminated by j
	      bool bRflag = false;
	      for(unsigned int s = 0; s < pSpace->NumResimers(j); ++s)
		{
		  if(eliminated.Get(j,s))
		    { 
		      if(eliminated.Get(i,r,j,s))
			{
			  //cout << "r = " << r 
			  //     << " is compatible with s = " << s << endl;
			  bRflag = true;      // j can't eliminate i_r
			  vecSflag[s] = true; // i can't eliminate j_s
			}
		      //else
		      //	{
		      //	  cout << "(i,r) = " << i << ", " << r 
		      //	       << " is not compatible with (j,s) = " 
		      //	       << j << ", " << s << endl;
		      //	}
		    }
		}
	      if(!bRflag)
		{
		 // cout << "Eliminating (1) " << r << " at " << i << endl;
		  // r is DEP with all s at j
		  eliminated.Eliminate(i,r);
		  ++iElimCount;
		}
	    }
	  for(unsigned int s = 0; s < pSpace->NumResimers(j); ++s)
	    {
	      if(eliminated.Get(j,s) &&
		 (!vecSflag[s]))
		{
		//  cout << "Eliminating (2) " << s << " at " << j << endl;
		  // s is DEP with all r at i
		  eliminated.Eliminate(j,s);
		  ++iElimCount;
		}
	    }
	}
    }
  return iElimCount;
}

