// ****************************************************************************
// Name: FixedSequence.h
// By: Mark Voorhies
// On: 6/10/2003
// Time-stamp: <FixedSequence.h 2003-07-16 18:44:41 Mark Voorhies>
// Implimented in: NA
// Description:
//   A FixedSequence represents a set of resimer choices at a set of positions
// (assumed to be a subset of the full design space).  It provides iterators
// both for this set (fixed_begin()/fixed_end()) and the inverse of this set
// (var_begin()/var_end()).  For the variable (inverse) set, iterators are
// provided for resimers that are not dead-end pairs with the fixed set.
// Position/resimer pairs are represented by the SeqPos class.
// ****************************************************************************

#ifndef MSV_FIXEDSEQUENCE_HEADER_FLAG
#define MSV_FIXEDSEQUENCE_HEADER_FLAG

#include <set>
#include <vector>

#include "DeeSpace.h"
#include "DeeTable.h"

struct SeqPos{
  unsigned int pos;
  unsigned int res;
  SeqPos(unsigned int pos_i = 0, unsigned int res_i = 0) 
    : pos(pos_i), res(res_i){}
  
  bool operator==(const SeqPos& rhs) const
  {return (pos == rhs.pos)&&(res == rhs.res);}
  bool operator!=(const SeqPos& rhs) const
  {return !(operator==(rhs));}
};

class FixedSequence{
private:
  std::vector<SeqPos> fixed_positions;
  std::set<unsigned int> variable_positions;
  const DeeTable *eliminated;
public:
  FixedSequence(const std::vector<SeqPos>& fi,
		const DeeTable *ei) : fixed_positions(fi), eliminated(ei){
    for(unsigned int i = 0; i < eliminated->Space()->NumPos(); ++i){
      variable_positions.insert(i);
    }
    for(std::vector<SeqPos>::const_iterator i = fixed_positions.begin();
	i != fixed_positions.end(); ++i){
      variable_positions.erase((*i).pos);
    }
  }

  typedef std::vector<SeqPos>::const_iterator fixed_iterator;

  fixed_iterator fixed_begin() const {return fixed_positions.begin();}
  fixed_iterator fixed_end() const {return fixed_positions.end();}

  class resimer_iterator{
  private:
    const FixedSequence *fixed;
    SeqPos i;
    unsigned int num_resimers;
  public:
    resimer_iterator(const resimer_iterator& init)
      : fixed(init.fixed), i(init.i), num_resimers(init.num_resimers){}
    resimer_iterator(const FixedSequence *fi, const unsigned int pos_i,
		     const unsigned int res_i = 0)
      : fixed(fi), i(pos_i, res_i),
      num_resimers(fi->eliminated->Space()->NumResimers(pos_i)){advance();}
    
    resimer_iterator& operator=(const resimer_iterator& rhs){
      if(this != &rhs){
	fixed = rhs.fixed; i = rhs.i;
	num_resimers = rhs.num_resimers;
      }
      return *this;
    }

    resimer_iterator& operator++(){
      ++(i.res); advance(); return *this;
    }

    const resimer_iterator operator++(int)
    {resimer_iterator temp = *this; ++(*this); return temp;}

    bool operator==(const resimer_iterator& rhs) const{
      return ((i == rhs.i)&&(fixed == rhs.fixed));
    }
    bool operator!=(const resimer_iterator& rhs) const{
      return !(operator==(rhs));
    }

    const SeqPos& operator*() const{
      return i;
    }

  private:
    // while i.res is not a valid resimer (due to forming DEP's) increment
    // i.res
    void advance(){
      bool flag = true;
      while((flag)&&(i.res < num_resimers)){
	// Skip eliminated resimers
	if(!fixed->eliminated->Get(i.pos, i.res)){
	  ++(i.res);
	  flag = true;
	  continue;
	}
	flag = false; 
	for(FixedSequence::fixed_iterator j = fixed->fixed_begin();
	    j != fixed->fixed_end(); ++j){
	  if(!fixed->eliminated->Get(i.pos, i.res, (*j).pos, (*j).res)){
	    ++(i.res);
	    flag = true;
	    break;
	  }
	}
      }
      if(i.res > num_resimers){
	i.res = num_resimers;
      }
    }
  };

  class variable_iterator{
  private:
    const FixedSequence *fixed;
    std::set<unsigned int>::const_iterator i;
  public:
    variable_iterator(const variable_iterator& init)
      : fixed(init.fixed), i(init.i) {}
    variable_iterator(const FixedSequence *fi)
      : fixed(fi), i(fi->variable_positions.begin()){}
    variable_iterator(const FixedSequence *fi, bool end_flag)
      : fixed(fi), i(fi->variable_positions.end()){}

    variable_iterator& operator=(const variable_iterator& rhs){
      if(this != &rhs){fixed = rhs.fixed; i = rhs.i;} 
      return *this;
    }
    
    variable_iterator& operator++(){
      ++i; return *this;
    }

    const variable_iterator operator++(int)
    {variable_iterator temp = *this; ++(*this); return temp;}

    bool operator==(const variable_iterator& rhs) const
    {return ((fixed == rhs.fixed)&&(i == rhs.i));}

    bool operator!=(const variable_iterator& rhs) const
    {return ((fixed != rhs.fixed)||(i != rhs.i));}

    const unsigned int& operator*() const{
      return *i;
    }

    resimer_iterator resimers_begin() const
    {return resimer_iterator(fixed, *i);}
    resimer_iterator resimers_end() const
    {return resimer_iterator(fixed, *i, 
			     fixed->eliminated->Space()->NumResimers(*i));} 
  };

  variable_iterator var_begin() const {return variable_iterator(this);}
  variable_iterator var_end() const {return variable_iterator(this, true);}

};

#endif
