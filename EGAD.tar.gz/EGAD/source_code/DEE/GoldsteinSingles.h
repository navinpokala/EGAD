// ****************************************************************************
// Name: GoldsteinSingles.h
// By: Mehagan Hopkins and Mark Voorhies
// On: 6/3/2003
// Time-stamp: <GoldsteinSingles.h 2003-07-16 10:39:03 Mark Voorhies>
// Implimented in: GoldsteinSingles.cpp
// Description:
//   Impliments the Goldstein Singles dead-end elimination criterion
// ****************************************************************************

#ifndef MSV_GOLDSTEIN_SINGLES_HEADER_FLAG
#define MSV_GOLDSTEIN_SINGLES_HEADER_FLAG

#include <stdio.h>

class DeeTable;

// Perform one round of Goldstein Singles elimination, returning
// the number of eliminated resimers
int GoldsteinSingles(DeeTable& eliminated);

#endif

