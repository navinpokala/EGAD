// ****************************************************************************
// Name: BoundingSingles.cpp
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <BoundingSingles.cpp 2003-07-21 12:06:11 Mark Voorhies>
// Impliments: BoundingSingles.h
// ****************************************************************************

#include "BoundingSingles.h"
#include "BoundingEnergy.h"
#include "DeeTable.h"
#include "InfDouble.h"
#include "FixedSequence.h"

#include <iostream>
#include <vector>

using namespace std;

int BoundingSingles(DeeTable& eliminated, double dRefEnergy)
{
  int iElimCount = 0;
  vector<SeqPos> vecFixed(1);
  const DeeSpace *space = eliminated.Space();

  if(space->NumPos() < 2)
    {
      // BoundingEnergy is broken for spaces with a single position
      return 0;
    }

  // Correct reference energy for the fixed positions
  dRefEnergy -= space->FixedEnergy();
  // cout << "Reference energy adjusted to " << dRefEnergy << endl;
  
  // Loop over positions

  for(unsigned int i = 0; i < space->NumPos(); ++i)
    {
      int num_valid = 0;
      
      //cout << "Beginning bounding elimination for position " << i << endl;

      // Loop over available resimers

      for(unsigned int r = 0; r < space->NumResimers(i); ++r)
	{
	  if(eliminated.Get(i, r))
	    {
	      
	      //printf("At resimer %d\n", r);	
	      
	      vecFixed[0] = SeqPos(i, r);
	      // Eliminate resimers for which E_bound > dRefEnergy
	      InfDouble e_temp(dRefEnergy);
	    
	      if((e_temp = 
		  BoundingEnergy
		  (*space, FixedSequence(vecFixed, &eliminated))) > dRefEnergy)
		{
		/*  cout << "Eliminating " << space->PosID(i) << ", "
		       << space->ResimerID(i, r) << " (" << e_temp.String() 
		       << " > " << dRefEnergy << ")" << endl;
		*/
		  eliminated.Eliminate(i, r);
		  ++iElimCount;
		}
	      else
		{
		  //fprintf(message_stream, "Valid energy %f <= %f\n",
		  //	  e_temp, dRefEnergy);
		  ++num_valid;
		}
	  }
	}
      if(num_valid < 1){
	cerr << "Error! No resimers remaining at " << i << endl;    
      }
    }
  return iElimCount;
}
