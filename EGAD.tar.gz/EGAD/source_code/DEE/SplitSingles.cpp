// ****************************************************************************
// Name: SplitSingles.cpp
// By: Mark Sales and Mark Voorhies
// Time-stamp: <SplitSingles.cpp 2003-07-16 11:50:36 Mark Voorhies>
// Impliments: SplitSingles.h
// ****************************************************************************

#include "SplitSingles.h"
#include "DeeSpace.h"
#include "DeeTable.h"
#include <vector>

using namespace std;

int SplitSingles(DeeTable& eliminated)
{    
  unsigned int iElimCount = 0;  // Number of eliminations that have been 
  //                               performed this round
  const DeeSpace *space = eliminated.Space();
		
  //for each position i in the protein
  for(unsigned int i = 0; i < space->NumPos(); ++i)
    {
      //for each resimer r at i
      for(unsigned int r = 0; r < space->NumResimers(i) ; ++r)
	{
	  //if r hasn't been eliminated yet
	  if(!eliminated.Get(i, r))
	    {
	      continue;
	    }

	  // ============================================================
	  // Step 1: find the minimum background energy for each j,t pair
	  // ============================================================

	  vector<vector<double> > Y(space->NumPos(),
				    vector<double>(space->NumResimers(i)));

	  for(unsigned int t = 0; t < space->NumResimers(i); ++t)
	    {
	      if((t==r) ||
		 (!eliminated.Get(i, t)))
		{
		  continue;
		}
	      for(unsigned int j = 0; j < space->NumPos(); ++j)
		{
		  //for each position j!=i
		  if(j == i)
		    {
		      continue;
		    }
		  //Make a note to initialize min_diff from diffE
		  bool s_flag = false;
		  double min_diff = 0.0, diffE = 0.0;
		  //for each resimer s at j
		  for(unsigned int s = 0; s < space->NumResimers(j); ++s)
		    {
		      //if r and s are not a dead end pair
		      if((eliminated.Get(i, r, j, s))&& 
			 //and s has not been eliminated
			 (eliminated.Get(j, s)))
			{  
			  diffE = space->Get(i, r, j, s) - 
			    space->Get(i, t, j, s);
			  if((min_diff > diffE)||(!s_flag))
			    {
			      // keep track of the minimum energy 
			      // difference between r and t
			      min_diff = diffE;  
			      s_flag = true;
			    }
			}
		    }
		  // add the minimimum energy difference for each j != i
		  // for the t,s DEP we would like to exclude a value
		  Y[j][t] = min_diff;
		} // closes loop over j
	    } // closes loop over t

	  // ============================================================
	  // Step 2: Partition at every non i position
	  // ============================================================

	  for(unsigned int k = 0; k < space->NumPos(); ++k)
	    {
	      //for each position k!=i
	      if(k == i)
		{
		  continue;
		}
	      // Mark all partitions undominated
	      vector<bool> elim(space->NumResimers(k), true);
	      for(unsigned int t = 0; t < space->NumResimers(i); ++t)
		{
		  if((t==r) ||
		     (!eliminated.Get(i, t)))
		    {
		      continue;
		    }
		  double X = space->Get(i, r) - space->Get(i, t);
		  for(unsigned int j = 0; j < space->NumPos(); ++j)
		    {
		      //for each position j!=(i or k)
		      if((j != i) &&
			 (j != k))
			{
			  X += Y[j][t];
			}
		    }
		  for(unsigned int v = 0; v < space->NumResimers(k); ++v)
		    {
		      if(eliminated.Get(i, r, k, v))
			{
			  if(X + space->Get(i, r, k, v) -
			     space->Get(i, t, k, v) > 0)
			    {
			      // t eliminates r on this partition
			      elim[v] = false;
			      // update split flags
			      eliminated.Eliminate(i, r, k, v);
			      //printf("Eliminating DEP\n");
			    }
			}
		      // Note: If v is eliminated then r,v will be marked as
		      //       a DEP in the elimination table
		      else
			{
			  // r,v = DEP -> r is eliminated in this partition
			  elim[v] = false;
			  //printf("DEP implies partial elimination\n");
			}
		    } // end loop over v
		} // end loop over t
	      bool elim_flag = true;
	      for(vector<bool>::const_iterator ep = elim.begin(); 
		  ep != elim.end(); ++ep)
		{
		  if(*ep)
		    {
		      elim_flag = false;
		      break;
		    }
		}
	      if(elim_flag)
		{
		  // all elim[v] flags were thrown -> r is eliminated on all
		  // partitions
		  eliminated.Eliminate(i, r);
		  ++iElimCount;
		  // bail out to next r
		  break;
		}	    
	    } // end loop over k
	} // end loop over r
    } // end loop over i
  return iElimCount; // return number of eliminations
}
