// ****************************************************************************
// Name: GoldsteinSingles.t.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <GoldsteinSingles.t.cpp 2003-07-10 13:48:01 Mark Voorhies>
// Tests: GoldsteinSingles.h
// ****************************************************************************

#include "GoldsteinSingles.h"
#include "DeeTable.h"
#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

using namespace std;

int main(int argc, char *argv[])
{

  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2)
    {
      cerr << "Usage: GoldsteinSingles.t input_file" << endl;
      cerr << "   where input_file is a valid EGAD input file" << endl;
      return EXIT_FAILURE;
    }
  string input_file = argv[1];

  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================
  
  PROTEIN *protein;
  if(!(protein = DeeInit(input_file)))
    {
      cerr << "Error initializing energy table!" << endl;
      return EXIT_FAILURE;
    }

  // ============================================================
  //  Construct DeeTable linked to ProteinDeeSpace
  // ============================================================

  ProteinDeeSpace space(protein);
  DeeTable eliminated(&space);

  // ============================================================
  //  Run GoldsteinSingles exhaustively on the DeeTable
  // ============================================================

  cout << "Starting Goldstein Singles" << endl;
  unsigned int iElimCount = 0;
  while((iElimCount = GoldsteinSingles(eliminated)) > 0)
    {
      cout <<"Eliminated " << iElimCount << " resimers" << endl;
      eliminated.Dump();
    }

  cout << "Done" << endl;

  cout << "Self Energies: " << endl;
  
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	{
	  cout << i << "," << r << ": " << space.Get(i,r) 
	       << " = " << space.Get(i,r,i,r) << endl;
	}
    }
  /*
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(eliminated.AvailableResimers(i) == 1)
	{
	  unsigned int r = 0;
	  for(;r < space.NumResimers(i); ++r)
	    {
	      if(eliminated.Get(i,r))
		{
		  break;
		}
	    }
	  if(r >= space.NumResimers(i))
	    {
	      cerr << "AvailableResimers error!" << endl;
	      return EXIT_FAILURE;
	    }
	  cout << "Energies for selected position " << i << "," << r << endl;
	  for(unsigned int j = 0; j < space.NumPos(); ++j)
	    {
	      if(eliminated.AvailableResimers(j) == 1)
		{
		  unsigned int s = 0;
		  for(; s < space.NumResimers(j); ++s)
		    {
		      if(eliminated.Get(j,s))
			{
			  break;
			}
		    }
		  if(s >= space.NumResimers(j))
		    {
		      cerr << "AvailableResimers error!" << endl;
		      return 0;
		    }
		  cout << "  with " << j << "," << s << ": " 
		       << space.Get(i,r,j,s) << endl;
		}
	    }
	}
    }
  */

  // ============================================================
  //  Run GoldsteinSingles exhaustively on a unified DeeTable
  // ============================================================

  DeeTable unified(&space);
  unified.Unify(2,4);
  space.Unify(2,4);

  cout << "Starting Goldstein Singles" << endl;
  
  while((iElimCount = GoldsteinSingles(unified)) > 0)
    {
      cout <<"Eliminated " << iElimCount << " resimers" << endl;
      unified.Dump();
    }

  cout << "Done" << endl;


  cout << "Self Energies: " << endl;
  
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	{
	  cout << i << "," << r << ": " << space.Get(i,r) 
	       << " = " << space.Get(i,r,i,r) << endl;
	}
    }

  /*
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(unified.AvailableResimers(i) == 1)
	{
	  unsigned int r = 0;
	  for(;r < space.NumResimers(i); ++r)
	    {
	      if(unified.Get(i,r))
		{
		  break;
		}
	    }
	  if(r >= space.NumResimers(i))
	    {
	      cerr << "AvailableResimers error!" << endl;
	      return EXIT_FAILURE;
	    }
	  cout << "Energies for selected position " << i << "," << r << endl;
	  for(unsigned int j = 0; j < space.NumPos(); ++j)
	    {
	      if(unified.AvailableResimers(j) == 1)
		{
		  unsigned int s = 0;
		  for(; s < space.NumResimers(j); ++s)
		    {
		      if(unified.Get(j,s))
			{
			  break;
			}
		    }
		  if(s >= space.NumResimers(j))
		    {
		      cerr << "AvailableResimers error!" << endl;
		      return 0;
		    }
		  cout << "  with " << j << "," << s << ": " 
		       << space.Get(i,r,j,s) << endl;
		}
	    }
	}
    }
  */
  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);
  
  return EXIT_SUCCESS;
}

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}
