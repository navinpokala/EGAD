// ****************************************************************************
// Name: ExhaustiveSearch.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <ExhaustiveSearch.h 2003-07-17 17:04:42 Mark Voorhies>
// Implimented in: ExhaustiveSearch.cpp
// Description:
//   ExhaustiveSearch finds the minimum energy sequence/conformation in a
//   search space by using a backtrack exhaustive search algorithm.  The
//   search will exclude any dead end pairs supplied in the DeeTable argument.
//   If max_nodes is greater than zero, the search will fail after max_nodes
//   nodes (internal + leaf) are visited.
// ****************************************************************************

#ifndef MSV_EXHAUSTIVE_SEARCH_HEADER_FLAG
#define MSV_EXHAUSTIVE_SEARCH_HEADER_FLAG

#include <vector>

class DeeSpace;
class DeeTable;

struct ExhaustiveSolution
{
public:
  double energy;                 // minimum energy
  std::vector<unsigned int> resimers;     // resimers for minimum energy
  const DeeSpace *space;         // space for interpreting resimers
  int nodes;                     // nodes explored
  int leaves;                    // leaves explored
  bool success;                  // true if global minimum was found

  ExhaustiveSolution(const double& e, const std::vector<unsigned int>& r,
		     const DeeSpace *s, const int n_i = -1,
		     const int l_i = -1, const bool s_i = true) :
    energy(e), resimers(r), space(s), nodes(n_i), leaves(l_i),
    success(s_i){}
};


ExhaustiveSolution *ExhaustiveSearch(const DeeTable& eliminated,
				     const int max_nodes = -1);

#endif
