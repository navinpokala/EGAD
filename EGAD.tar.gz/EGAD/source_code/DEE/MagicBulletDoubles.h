// *****************************************************************************
// Name: MagicBulletDoubles.h
// By: Mehagan Hopkins and Mark Voorhies
// On: 6/3/2003
// Time-stamp: <MagicBulletDoubles.h 2003-07-18 18:19:45 Mark Voorhies>
// Implimented in: MagicBulletDoubles.cpp
// Description:
//   Impliments the Magic Bullet Doubles dead-end elimination criterion
// *****************************************************************************

#ifndef MSV_MAGIC_BULLET_DOUBLES_HEADER_FLAG
#define MSV_MAGIC_BULLET_DOUBLES_HEADER_FLAG

#include <stdio.h>

class DeeSpace;
class DeeTable;

int MagicBulletDoubles(DeeTable& eliminated);

#endif

