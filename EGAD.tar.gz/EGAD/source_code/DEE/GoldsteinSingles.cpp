// ****************************************************************************
// Name: GoldsteinSingles.cpp
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <GoldsteinSingles.cpp 2003-07-18 17:52:15 Mark Voorhies>
// Impliments: GoldsteinSingles.h
// ****************************************************************************

#include "GoldsteinSingles.h"
#include "DeeSpace.h"
#include "DeeTable.h"
#include <vector>

// Attempt to eliminate r with t at i using the Goldstein Criterion
bool GoldsteinEliminate(unsigned int i, unsigned int r, unsigned int t, 
			const DeeTable& eliminated);

using namespace std;

int GoldsteinSingles(DeeTable& eliminated)
{
	
  unsigned int iElimCount = 0;  // iElimCount is the number of eliminations 
  //                               that have been performed this round
		
  //for each position i in the protein

  for(unsigned int i = 0; i < eliminated.Space()->NumPos(); ++i)
    {
      //for each resimer r at i
      for(unsigned int r = 0; r < eliminated.Space()->NumResimers(i) ; ++r)
	{
	  //if r hasn't been eliminated yet
	  if(!eliminated.Get(i, r))
	    { 
	      continue;
	    }
	  for(unsigned int t = 0; 
	      t < eliminated.Space()->NumResimers(i); ++t)
	    {
	      if((t==r) ||
		 (!eliminated.Get(i, t)))
		{
		  continue;
		}

	      // Goldstein criterion:
	      // if E(i_r) - E(i_t) + 
	      //    \sum_{j!=i} min_{s} [E(i_r, j_s) - E(i_t, j_s)] > 0
	      // then t eliminates r
	      // (where eliminated j_s rotamers are not considered)

	      if(GoldsteinEliminate(i, r, t, eliminated))
		{
		  //eliminate r
		  eliminated.Eliminate(i, r);
		  ++iElimCount;
		  
		  //now that r has been eliminated exit the t loop 
		  //and move on to a new r
		  break;
		} 
		    
	    } // end loop over resimers t at i
	} // end loop over resimers r at i
    } // end loop over positions i

  //fprintf(message_stream,"eliminated %d resimers\n\n", iElimCount);

  return iElimCount; // return number of eliminations
}

// Attempt to eliminate r with t using the Goldstein Criterion
bool GoldsteinEliminate(unsigned int i, unsigned int r, unsigned int t,
			const DeeTable& eliminated){
  // Store the fixed cost of choosing r vs t
  double dX = eliminated.Space()->Get(i, r) - eliminated.Space()->Get(i, t);

  for(unsigned int j = 0; j < eliminated.Space()->NumPos(); ++j){
    //for each position j!=i
    if(j == i){
      continue;
    }
    //Make a note to initialize dMinDiff from dDiff
    bool bInitFlag = false;
    double dMinDiff = 0.0, dDiff = 0.0;
    //for each resimer s at j
    for(unsigned int s = 0; s < eliminated.Space()->NumResimers(j); ++s){
      //check that r and s are not a dead end pair
      if((!eliminated.Get(i, r, j, s))|| 
	 //and s has not been eliminated
	 (!eliminated.Get(j, s))){
	continue;
      }  
      //exit the loop if t,s is a DEP but r,s is not 
      //(t cannot eliminate r)
      if(!eliminated.Get(i, t, j, s)){
	return false;
      }
      dDiff = 
	eliminated.Space()->Get(i, r, j, s) - 
	eliminated.Space()->Get(i, t, j, s);
      if((dMinDiff>dDiff)||(!bInitFlag)){
	// keep track of the minimum energy difference 
	// between r and t
	dMinDiff = dDiff;  
	bInitFlag = true;
      }
    } // end loop over s at j
 
    if(!bInitFlag){
      // At this point, we have never encountered a j_s which is
      // DEP with i_t but not with i_r (if we did, we would return false).
      // Therefore, all j_s are DEP with i_r -> eliminate i_r
      return true;
    }
    //add the minimimum energy difference for each j != i
    dX += dMinDiff;  
  } // end loop over j
  
  if(dX > 0){
    // t can eliminate r by the Goldstein criterion
    return true;
  }
  // t can't eliminate r by the Goldstein criterion
  return false;
}
 
