// *****************************************************************************
// Name: ProteinDeeSpace.t.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <ProteinDeeSpace.t.cpp 2003-07-14 17:41:57 Mark Voorhies>
// Tests: ProteinDeeSpace.h
// *****************************************************************************

#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

using namespace std;

int main(int argc, char *argv[])
{
  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================

  string input_file = "1ASM_rotopt20.input";

  PROTEIN *protein;
  if(!(protein = DeeInit(input_file))){
    cerr << "Error initializing energy table!" << endl;
    return EXIT_FAILURE;
  }
  ProteinDeeSpace space(protein);

  // ============================================================
  //   Fix positions to known solution
  // ============================================================

  space.FixPos(0,1);
  space.FixPos(0,1);
  space.FixPos(0,3);
  space.FixPos(0,3);
  space.FixPos(0,3);
  space.FixPos(0,4);
  space.FixPos(0,3);
  space.FixPos(0,6);
  space.FixPos(0,7);
  space.FixPos(0,5);
  space.FixPos(0,10);
  space.FixPos(0,1);
  space.FixPos(0,3);
  space.FixPos(0,0);
  space.FixPos(0,1);
  space.FixPos(0,2);
  space.FixPos(0,5);
  space.FixPos(0,4);
  space.FixPos(0,0);

  space.DumpFixedPositions();
  cout << "Energy: " << space.FixedEnergy() << endl;

  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);

  return EXIT_SUCCESS;  
}

/*
int main(int argc, char *argv[]){

  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2){
    cerr << "Usage: ProteinDeeSpace.t input_file" << endl;
    cerr << "   where input_file is a valid EGAD input file" << endl;
    return EXIT_FAILURE;
  }
  string input_file = argv[1];

  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================

  PROTEIN *protein;
  if(!(protein = DeeInit(input_file))){
    cerr << "Error initializing energy table!" << endl;
    return EXIT_FAILURE;
  }

  // ============================================================
  //  Tests of ProteinDeeSpace specific functions
  // ============================================================

  // Construction, assignment, destruction

  ProteinDeeSpace space(protein);
  ProteinDeeSpace b(0); // should produce error message
  b = space;
  DeeSpace *c = new ProteinDeeSpace(protein);
  delete c;

  // ============================================================
  //  Tests of ProteinDeeSpace's implementation of DeeSpace
  // ============================================================

  // Space accessor functions

  cout << "space.NumPos(): " << space.NumPos() << endl;
  cout << "b.NumPos(): " << b.NumPos() << endl;

  for(unsigned int i = 0; i < space.NumPos(); ++i){
    cout << "space.NumResimers(" << i <<")" << space.NumResimers(i) << endl;
    cout << "space.PosID(" << i << ")" << space.PosID(i) << endl;
    for(unsigned int r = 0; r < space.NumResimers(i); ++r){
      cout << "   " << r << ": " 
	   << space.ResType(i,r) << " " 
	   << space.ResimerID(i,r) << endl;
    }
  }

  // Energy accessor functions

  unsigned int count = 0, max_count = 100000;

  cout << "Accessing up to " << max_count 
       << " energies with get(i,r,j,s)" << endl;

  for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i){
    cout << "i = " << i << endl;
    for(unsigned int j = i; (j < space.NumPos())&&(count < max_count); ++j){
      cout << "j = " << j << endl;
      for(unsigned int r = 0; 
	  (r < space.NumResimers(i))&&(count < max_count); ++r){
	for(unsigned int s = 0; 
	    (s < space.NumResimers(j))&&(count < max_count); ++s){
	  cout << " " << space.Get(i,r,j,s);
	  ++count;
	}
	cout << endl;
      }
      cout << endl << endl;
    }
    cout << endl << endl;
  }

  count = 0;

  cout << "Accessing up to " << max_count 
       << " energies with pair_energy(i,r,j,s)" << endl;

  for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i){
    cout << "i = " << i << endl;
    for(unsigned int j = i; (j < space.NumPos())&&(count < max_count); ++j){
      cout << "j = " << j << endl;
      for(unsigned int r = 0; 
	  (r < space.NumResimers(i))&&(count < max_count); ++r){
	for(unsigned int s = 0; 
	    (s < space.NumResimers(j))&&(count < max_count); ++s){
	  cout << " " << space.pair_energy(i,r,j,s);
	  ++count;
	}
	cout << endl;
      }
      cout << endl << endl;
    }
    cout << endl << endl;
  }

  // Unification

  if(space.NumPos() < 6){
    cout << "Not enough positions for unification test!" << endl;
  }
  else{
    // Perform unification

    cout << "Unification test..." << endl;
    space.Unify(3,5); // combine positions 3 and 5
    // Note: indices >= 5 have changed
    space.Unify(2,3); // combine position 2 with combined position 3/5
    // Note: indices >= 3 have changed
    space.Unify(0,1); // combine positions 0 and 1
    // Note: indices >= 1 have changed

    // Re-check space accessor functions

    for(unsigned int i = 0; i < space.NumPos(); ++i){
      cout << "space.NumResimers(" << i <<")" << space.NumResimers(i) << endl;
      cout << "space.PosID(" << i << ")" << space.PosID(i) << endl;
      for(unsigned int r = 0; r < space.NumResimers(i); ++r){
	cout << "   " << r << ": " 
	     << space.ResType(i,r) << " " 
	     << space.ResimerID(i,r) << endl;
      }
    }

    // Re-check energy accessor functions

    count = 0;

    cout << "Accessing up to " << max_count 
	 << " energies with Get(i,r)" << endl;
    
    for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i){
      cout << "i = " << i << endl;
      for(unsigned int r = 0; 
	  (r < space.NumResimers(i))&&(count < max_count); ++r){
	cout << " " << space.Get(i,r);
	    ++count;
      }
      cout << endl;
    }

    // Test residue and rotamer elimination

    space = ProteinDeeSpace(protein);

    cout << "Pruning test..." << endl;
    space.FixPos(5,1); // Fix position 5 at choice 1
    // Note: indices >= 5 have changed
    space.RemoveRes(3,2); // Remove resimer 2 at position 3
    space.Unify(2,3); // combine position 2 with combined position 3
    space.RemoveRes(0,3,5); // Remove resimers 3 to 5 at position 0

    // Re-check space accessor functions

    for(unsigned int i = 0; i < space.NumPos(); ++i){
      cout << "space.NumResimers(" << i <<")" << space.NumResimers(i) << endl;
      cout << "space.PosID(" << i << ")" << space.PosID(i) << endl;
      for(unsigned int r = 0; r < space.NumResimers(i); ++r){
	cout << "   " << r << ": " 
	     << space.ResType(i,r) << " " 
	     << space.ResimerID(i,r) << endl;
      }
    }

    // Re-check energy accessor functions

    count = 0;

    cout << "Accessing up to " << max_count 
	 << " energies with Get(i,r)" << endl;
    
    for(unsigned int i = 0; (i < space.NumPos())&&(count < max_count); ++i){
      cout << "i = " << i << endl;
      for(unsigned int r = 0; 
	  (r < space.NumResimers(i))&&(count < max_count); ++r){
	cout << " " << space.Get(i,r);
	    ++count;
      }
      cout << endl;
    }

  }
    


  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);

  return EXIT_SUCCESS;
}
*/

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}
