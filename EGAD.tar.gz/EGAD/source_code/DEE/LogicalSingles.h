// *****************************************************************************
// Name: LogicalSingles.h
// By: Mark Voorhies
// On: 6/3/2003
// Time-stamp: <LogicalSingles.h 2003-07-01 15:49:51 Mark Voorhies>
// Implimented in: LogicalSingles.cpp
// Description:
//   Impliments logical elimination at the single resimer level:
//      1) Any resimer that is DEP with all remaining resimers at any
//         other position may be eliminated.
//      2) If there is only one resimer at a given position, all resimers
//         that are DEP with it may be eliminated (special case of 1)
// *****************************************************************************

#ifndef MSV_LOGICAL_SINGLES_HEADER_FLAG
#define MSV_LOGICAL_SINGLES_HEADER_FLAG

#include <stdio.h>

class DeeTable;

// Perform one round of Logical Singles elimination, returning
// the number of eliminated resimers
int LogicalSingles(DeeTable& eliminated);

#endif

