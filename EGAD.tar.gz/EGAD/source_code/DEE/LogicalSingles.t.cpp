// ****************************************************************************
// Name: LogicalSingles.t.cpp
// By: Mark Voorhies
// On: 6/24/2003
// Time-stamp: <LogicalSingles.t.cpp 2003-07-16 10:37:39 Mark Voorhies>
// Tests: LogicalSingles.h
// ****************************************************************************

#include "DeeTable.h"
#include "GoldsteinSingles.h"
#include "LogicalSingles.h"
#include "ProteinDeeSpace.h"
#include "dee_utilities.h"   // For initialize_lookuptable_for_dee
#include "input_stuff.h"     // For input_stuff
#include "lookup_table.h"    // For generate_lookup_table
#include "structure_types.h" // For PROTEIN
#include <iostream>
#include <stdlib.h>
#include <string>

// Utility function for loading a PROTEIN -> move this to a library component
// Note: Multiple calls of DeeInit during a single run may produce undefined
//       behavior due to EGAD globals.
PROTEIN *DeeInit(const std::string input_file);

int Unify(DeeTable& eliminated, DeeSpace& space);

using namespace std;

int main(int argc, char *argv[])
{

  // ============================================================
  //   Parse input
  // ============================================================

  if(argc < 2)
    {
      cerr << "Usage: LogicalSingles.t input_file" << endl;
      cerr << "   where input_file is a valid EGAD input file" << endl;
      return EXIT_FAILURE;
    }
  string input_file = argv[1];

  // ============================================================
  //   Load and initialize PROTEIN using EGAD library functions
  // ============================================================
  
  PROTEIN *protein;
  if(!(protein = DeeInit(input_file)))
    {
      cerr << "Error initializing energy table!" << endl;
      return EXIT_FAILURE;
    }

  // ============================================================
  //  Construct DeeTable linked to ProteinDeeSpace
  // ============================================================

  ProteinDeeSpace space(protein);
  DeeTable eliminated(&space);
  /*
  cout << space.PosID(28) << " self energies:" << endl;
  for(unsigned int i = 0; i < space.NumResimers(28); ++i)
    {
      cout << space.Get(28, i) << " ";
    }

  cout << endl;

  int egad_pos = parse_seqpos_string("146A",
				     protein->seqpos_text_map);

  int egad_ref = 1;
  while((protein->var_pos[egad_ref].seq_position != ENDFLAG)&&
	(protein->var_pos[egad_ref].seq_position != egad_pos)){
    ++egad_ref;
  }
  if(protein->var_pos[egad_ref].seq_position == ENDFLAG)
    {
      cerr << "Bad pos!" << endl;
      return 0;
    }
  cout << egad_pos << endl;

  cout << string(protein->
		 seqpos_text_map[seqpos_to_inputted_string  
				(egad_pos,
				 protein->seqpos_text_map)].seqpos_text) 
       << endl;
  cout << egad_ref << endl;
  for(int i = 1; i <= protein->var_pos[egad_ref].number_of_resimers; 
      ++i)
    {
      cout << get_self_energy(protein, egad_ref, i) << " ";
    }
  cout << endl;
  cout << "Pairwise energies: " << endl;
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(i == 28)
	{
	  continue;
	}
      int egad_i_pos = parse_seqpos_string(const_cast<char *>(space.PosID(i).c_str()),
					   protein->seqpos_text_map);
      int egad_i_ref = 1;
      while((protein->var_pos[egad_i_ref].seq_position != ENDFLAG)&&
	    (protein->var_pos[egad_i_ref].seq_position != egad_i_pos)){
	++egad_i_ref;
      }
      if(protein->var_pos[egad_i_ref].seq_position == ENDFLAG)
	{
	  cerr << "Bad pos!" << endl;
	  return 0;
	}
      cout << space.PosID(i) << ": " << endl;
      for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	{
	  for(unsigned int s = 0; s < space.NumResimers(28); ++s)
	    {
	      cout << space.Get(i,r,28,s) << " ";
	    }
	  cout << endl;
	  for(int s = 1; s <= protein->var_pos[egad_ref].number_of_resimers;
	      ++s)
	    {
	      cout << get_energy(protein, egad_i_ref, r+1, egad_ref, s) << " ";
	    }
	  cout << endl << endl;
	}
    }

  free_PROTEIN(protein);
  return 0;
  */
  // ============================================================
  //  Run LogicalSingles and GoldsteinSingles exhaustively on the DeeTable
  // ============================================================

  unsigned int iElimCount = 0;
  bool bRepeatFlag = true;

  while(bRepeatFlag)
    {
      bRepeatFlag = false;

      cout << "Starting Logical Singles" << endl;

      while((iElimCount = LogicalSingles(eliminated)) > 0)
	{
	  cout <<"Eliminated " << iElimCount << " resimers" << endl;
	  eliminated.Dump();
	  bRepeatFlag = true;
	  // Goldstein Singles doesn't generate any DEP's, so we shouldn't
	  // be able to make any logical eliminations
	  cout << "Warning: These are unexpected eliminations!" << endl;
	}

      cout << "Starting Goldstein Singles" << endl;
  
      while((iElimCount = GoldsteinSingles(eliminated)) > 0)
	{
	  cout <<"Eliminated " << iElimCount << " resimers" << endl;
	  eliminated.Dump();
	  bRepeatFlag = true;
	}
    }

  cout << "Done" << endl;

  // ============================================================
  //   Use unification to generate some DEP's
  // ============================================================

  while(Unify(eliminated, space) != 0)
    {
      //space.DumpFixedPositions();
      bRepeatFlag = true;
      while(bRepeatFlag)
	{
	  bRepeatFlag = false;
	  
	  cout << "Starting Logical Singles" << endl;
	  
	  while((iElimCount = LogicalSingles(eliminated)) > 0)
	    {
	      cout <<"Eliminated " << iElimCount << " resimers" << endl;
	      eliminated.Dump();
	      bRepeatFlag = true;
	    }
	      
	  cout << "Starting Goldstein Singles" << endl;
	  
	  while((iElimCount = GoldsteinSingles(eliminated)) > 0)
	    {
	      cout <<"Eliminated " << iElimCount << " resimers" << endl;
	      eliminated.Dump();
	      bRepeatFlag = true;
		}
	}
      
      cout << "Done" << endl;
    }
  space.DumpFixedPositions();
  cout << "Final energy for converged positions: " << space.FixedEnergy()
       << endl;

  // ============================================================
  //  De-allocate memory and exit
  // ============================================================

  free_PROTEIN(protein);
  
  return EXIT_SUCCESS;
}

PROTEIN *DeeInit(const string input_file){
  PROTEIN *protein = 0;

  printf("Allocating memory for protein structure\n");
  if(!(protein = (PROTEIN *)malloc(sizeof(PROTEIN)))){
    fprintf(stderr, "Error allocating protein in DeeTest!\n");
    return 0;
  }

  printf("Loading %s\n", input_file.c_str());

  input_stuff(const_cast<char *>(input_file.c_str()), protein);

  printf("Generating lookup table...\n");

  generate_lookup_table(protein);

  if(!protein->lookupEnergy){
    fprintf(stderr, "lookupEnergy = 0 in DeeInit!\n");
    free_PROTEIN(protein);
    return 0;
  }

  // We need the next two lines to get number_of_resimers
  // at each position.
  printf("Initializing dead end elimination table\n");
  initialize_lookuptable_for_dee(protein);

  return protein;
}

int Unify(DeeTable& eliminated, DeeSpace& space)
{

  // Find the pair of unifiable positions that require the least
  // memory allocation

  unsigned int iPos1 = 0, iPos2 = 0, iCurMem = 0, iMemRequired = 0;
  bool bInitFlag = false, bSolvedFlag = true;

  // Remove determined positions and eliminated resimers
  // Note: re-code for efficiency

  list<unsigned int> fix_list;
  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(eliminated.AvailableResimers(i) < 2)
	{   
	  fix_list.push_front(i);
	}
      
      else
	{
	  list<unsigned int> rem_list;
	  for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	    {
	      if(!eliminated.Get(i,r))
		{
		  rem_list.push_front(r);
		}
	    }
	  for(list<unsigned int>::iterator r = rem_list.begin();
	      r != rem_list.end(); ++r)
	    {
	      eliminated.RemoveRes(i,*r);
	      space.RemoveRes(i,*r);
	    }
	  cout << "Resimers at " << space.PosID(i) << ": ";
	  for(unsigned int r = 0; r < space.NumResimers(i); ++r)
	    {
	      cout << space.ResimerID(i,r) << " ";
	    }
	  cout << endl;
	}
    }
  for(list<unsigned int>::iterator i = fix_list.begin();
      i != fix_list.end(); ++i)
    {
      unsigned int best = 0;
      bool flag = false, another_flag = false;
      for(unsigned int r = 0; r < space.NumResimers(*i); ++r)
	{
	  if(eliminated.Get(*i,r))
	    {
	      if(flag)
		{
		  cout << "Unexpected resimer " << r << " at " << *i << endl;
		  another_flag = true;
		}
	      else
		{
		  flag = true;
		  best = r;
		}
	    }
	}
      if((flag) && (!another_flag))
	{
	  cout << "Fixing " << *i << " to " << best << endl;
	  cout << "(" << space.PosID(*i) << ", "
	       << space.ResType(*i, best) << ", "
	       << space.ResimerID(*i, best) << ")" << endl;
	  if(!eliminated.Get(*i, best))
	    {
	      cout << "Oops!" << endl;
	    }
	  space.FixPos(*i,best);
	  eliminated.FixPos(*i);
	  //eliminated.Dump();
	  cout << "Logical elimination eliminated "
	       << LogicalSingles(eliminated) << " resimers" << endl;
	  //eliminated.Dump();
	}
    }

  eliminated.Dump();

  LogicalSingles(eliminated);

  eliminated.Dump();

  for(unsigned int i = 0; i < space.NumPos(); ++i)
    {
      if(eliminated.AvailableResimers(i) < 2)
	{
	  continue;
	}
      bSolvedFlag = false;
      for(unsigned int j = i + 1; j < space.NumPos(); ++j)
	{
	  if(eliminated.AvailableResimers(j) < 2)
	    {
	      continue;
	    }
	  iCurMem = space.NumResimers(i) * space.NumResimers(j);
	  if((!bInitFlag) || (iCurMem < iMemRequired))
	    {
	      bInitFlag = true;
	      iPos1 = i;
	      iPos2 = j;
	      iMemRequired = iCurMem;
	    }
	}
    }
  if(!bInitFlag)
    {
      if(!bSolvedFlag)
	{
	  cout << "Can't unify, only one undetermined position!" << endl;
	}
      else
	{
	  cout << "Can't unify, all positions are determined!" << endl;
	}
      return 0;
    }

  // Unify the chosen positions

  cout << "Unifying " << iPos1 << " with " << iPos2 << endl;
  /*
  cout << iPos1 << " self energies:" << endl;
  for(unsigned int r = 0; r < space.NumResimers(iPos1); ++r)
    {
      cout << "  " << space.ResimerID(iPos1, r) << ": " 
	   << space.Get(iPos1, r) << endl;
    }
  cout << iPos2 << " self energies:" << endl;
  for(unsigned int r = 0; r < space.NumResimers(iPos2); ++r)
    {
      cout << "  " << space.ResimerID(iPos2, r) << ": " 
	   << space.Get(iPos2, r) << endl;
    }

  cout << iPos1 << ", " << iPos2 << " pair energies:" << endl;
  for(unsigned int r = 0; r < space.NumResimers(iPos1); ++r)
    {
      for(unsigned int s = 0; s < space.NumResimers(iPos2); ++s)
	{
	  cout << "  " << space.ResimerID(iPos1, r) << ", " 
	       << space.ResimerID(iPos2, s) << ": "
	       << space.Get(iPos1, r, iPos2, s) << endl;
	}
    }
  */
  eliminated.Unify(iPos1, iPos2);
  space.Unify(iPos1, iPos2);
  /*
  cout << "Unified resimers for " << space.PosID(iPos1) << endl;
  for(unsigned int r = 0; r < space.NumResimers(iPos1); ++r)
    {
      if(eliminated.Get(iPos1, r))
	{
	  cout << "  " << space.ResimerID(iPos1,r) 
	       << ": " << space.Get(iPos1, r) << endl;
	}
    }
  */
  return 1;
}
