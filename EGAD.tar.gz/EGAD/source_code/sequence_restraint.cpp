/* EGAD: sequence_restraint.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Dec 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for generating and restraining sequences for design

*/

#include "sequence_restraint.h"

/* can plug in whatever filters you'd like */

// flips to wt while number of mutations > MAX_MUTATIONS, returns num_mutations_made (0 = inputed chr is OK)
int restrict_mutations(CHROMOSOME *chr, int initialize_flag)
{
	int num_mutations;
	int num_mutations_made;
	int i;
	static double one_over_num_pos;
	static int num_moving_positions=0;
	static char *wt_seq=NULL, *current_seq=NULL;
	extern int MAX_MUTATIONS;

	if(MAX_MUTATIONS == 0)
		return(0);

	if(initialize_flag==1)
	{
		if(wt_seq != NULL)
			free_memory(wt_seq);
		if(current_seq != NULL)
			free_memory(current_seq);

		wt_seq = (char *)calloc(MAX_RESIDUES,sizeof(char));
		current_seq = (char *)calloc(MAX_RESIDUES,sizeof(char));

		CHROMOSOME_to_variable_sequence(chr, wt_seq);

		num_moving_positions=0;
		chr->genes = chr->firstgene;
		while(chr->genes->seq_position != ENDFLAG)
		{
			if(chr->genes->varpos_ptr->fixed_flag==0)
				if(chr->genes->varpos_ptr->number_of_choices > 1)
					++num_moving_positions;

			chr->genes = chr->genes->nextgene;
		}

		one_over_num_pos = 1.0/((double)num_moving_positions); 


	}

	CHROMOSOME_to_variable_sequence(chr, current_seq);

		num_mutations = 0;
		i=0;
		while(wt_seq[i] != '\0')
		{
			if(current_seq[i] != wt_seq[i])
				++num_mutations;
			++i;
		}

	num_mutations_made = 0;

	
	while(num_mutations > MAX_MUTATIONS)
	{

		i=0;
		chr->genes = chr->firstgene;
		while(chr->genes->seq_position != ENDFLAG)
		{	
			if(chr->genes->varpos_ptr->fixed_flag==0)
			if(chr->genes->varpos_ptr->number_of_choices > 1)
			{
				if(current_seq[i] != wt_seq[i])
				{
					if(dice() <= one_over_num_pos)
					{
						while(current_seq[i] != wt_seq[i])
						{
							mutate_sidechain(chr->genes, (*chr->genes->varpos_ptr));
							
							current_seq[i] = chr->genes->choice_ptr->resparam_ptr->one_letter_code[0];

						}
						++num_mutations_made;
					}
				}
				++i;
			}

			chr->genes = chr->genes->nextgene;
		}		
		
		chr->genes = chr->firstgene;
		CHROMOSOME_to_variable_sequence(chr, current_seq);

		num_mutations = 0;
		i=0;
		while(wt_seq[i] != '\0')
		{
			if(current_seq[i] != wt_seq[i])
				++num_mutations;
			++i;
		}
	}

	return(num_mutations_made);
}


void generate_custom_sequence_CHROMOSOME(CHROMOSOME *chr, int initialize_flag)
{
	
	/*	 
	extern INVARIABLE_POSITIONS *INVAR_POS;
	extern char *SEQ_FILTER_INPUTFILENAME;
	static char *current_sequence=NULL, *new_sequence=NULL;

	if(new_sequence == NULL)
	{
		new_sequence = (char *)calloc(MAXLINE,sizeof(char));
		current_sequence = (char *)calloc(MAXLINE,sizeof(char));	
	}
	
	// get the sequence of this CHROMOSOME
	CHROMOSOME_to_sequence(chr, INVAR_POS, current_sequence);
	
	// some user function to modify the sequence -> put into new_sequence
	custom_user_sequence_function(current_sequence, new_sequence, initialize_flag, SEQ_FILTER_INPUTFILENAME);
	
	// convert the new_sequence back into a CHROMOSOME
	sequence_to_CHROMOSOME(chr, INVAR_POS, new_sequence);

	*/ 

	restrict_mutations(chr, initialize_flag);

	return;
}
