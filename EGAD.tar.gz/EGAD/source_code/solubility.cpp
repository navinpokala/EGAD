/* EGAD: solubility.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Sept 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for scoring and improving the solubility of CHROMOSOME structures.

*/

#include "solubility.h"



/* Given a charge of a protein overall_charge_pH_avg, this function returns 1 if the charge is 
	within the inputed specifications
   If SOLUBILITY_CUTOFF_FLAG=0, then 1 is returned immediately.
   Returns 0 if overall_charge_pH_avg is not within the specifications
*/
int charge_within_specifications(double overall_charge_pH_avg)
{
	extern double OVERALL_CHARGE, OVERALL_CHARGE_TOLERANCE; 
	extern int CHARGE_EQUALITY_FLAG, SOLUBILITY_CUTOFF_FLAG;

	if(SOLUBILITY_CUTOFF_FLAG == 0) 	/* not screening for solubility, so return yes */
		return(1);

	/* for CHARGE_EQUALITY_FLAG values, see input_stuff.cpp: input_stuff */

	if(CHARGE_EQUALITY_FLAG == 0)
	{
		if(fabs(fabs(overall_charge_pH_avg)  - OVERALL_CHARGE) <= OVERALL_CHARGE_TOLERANCE)
			return(1);
		else
			return(0);
	}
	else if(CHARGE_EQUALITY_FLAG == 1)
	{
		if(fabs(overall_charge_pH_avg - OVERALL_CHARGE) <= OVERALL_CHARGE_TOLERANCE)
			return(1);
		else
			return(0);
	}
	else if(CHARGE_EQUALITY_FLAG == 2)
	{
		if(overall_charge_pH_avg >= OVERALL_CHARGE)
			return(1);
		else
			return(0);
	}
	else if(CHARGE_EQUALITY_FLAG == -2)
	{
		if(overall_charge_pH_avg <= OVERALL_CHARGE)
			return(1);
		else
			return(0);
	}
	else if(CHARGE_EQUALITY_FLAG == 3)
	{
		if(fabs(overall_charge_pH_avg) >= OVERALL_CHARGE)
			return(1);
		else
			return(0);
	}
	else if(CHARGE_EQUALITY_FLAG == -3)
	{
		if(fabs(overall_charge_pH_avg) <= OVERALL_CHARGE)
			return(1);
		else
			return(0);
	}

	return(1);
}

/* returns 1 if soluble; 0 if not. Solubility based on fraction hydrophobic sasa FRACTION_HYDROPHOBIC_SASA_CUTOFF, 
	charge_within_specifications, and TRANSFER_FREE_ENERGY_DENSITY_CUTOFF. If SOLUBILITY_CUTOFF_FLAG=0,
	returns 1 */

int is_this_chr_soluble(CHROMOSOME *chr)
{
	extern int SOLUBILITY_CUTOFF_FLAG;
  	extern double FRACTION_HYDROPHOBIC_SASA_CUTOFF;
  	extern double TRANSFER_FREE_ENERGY_DENSITY_CUTOFF;
	double sasa_total, sasa_hydrophobic, frac_hydrophobic, overall_charge, transfer_free_energy_density;

	if(SOLUBILITY_CUTOFF_FLAG == 0)	/* not screening for solubility, so return yes */
		return(1);

	chr->genes = chr->firstgene;

	/* sequence space only....don't have enough info to score solubility */
	if(chr->genes->choice_ptr->lookup_res_ptr==NULL)
		return(1);

	sasa_total = 0; overall_charge = 0; transfer_free_energy_density=0;
	sasa_hydrophobic = 0;
 	frac_hydrophobic = 0;
		
	while(chr->genes->seq_position!=ENDFLAG)
	{
		sasa_total += chr->genes->choice_ptr->lookup_res_ptr->sasa_total;
		sasa_hydrophobic += chr->genes->choice_ptr->lookup_res_ptr->sasa_hphob;
		overall_charge += chr->genes->choice_ptr->resparam_ptr->overall_charge_pH_avg;
		transfer_free_energy_density += chr->genes->choice_ptr->lookup_res_ptr->E_transfer;
		chr->genes = chr->genes->nextgene;
	}
	chr->genes = chr->firstgene;

	

	frac_hydrophobic = sasa_hydrophobic/sasa_total;
	transfer_free_energy_density = transfer_free_energy_density/sasa_total;

	
	if(transfer_free_energy_density - TRANSFER_FREE_ENERGY_DENSITY_CUTOFF > EPS)
		return(0);

	if(frac_hydrophobic - FRACTION_HYDROPHOBIC_SASA_CUTOFF > EPS)	/* too hydrophobic */
		return(0);

	if(charge_within_specifications(overall_charge) == 0)
		return(0);
	
	return(1);
}

/* Calculate the sasa and overall_charge of the dummychr CHROMOSOME for all fixed positions.
	Used by MC_rotamers and downhill_linmin_CHROMOSOME when SOLUBILITY_CUTOFF_FLAG=1 */
void fixed_position_sasa_charge(CHROMOSOME *dummychr, double *fixed_sasa, double *fixed_hphob_sasa, double *fixed_charge, double *E_transfer)
{
	extern float FIXED_POSITION_PTR;

	*fixed_sasa=0; 
	*fixed_hphob_sasa=0; 
	*fixed_charge=0;
	*E_transfer=0;
	
	dummychr->genes = dummychr->firstgene;

	/* sequence space only....don't have enough info to score solubility */
	if(dummychr->genes->choice_ptr->lookup_res_ptr==NULL)
		return;

	while(dummychr->genes->seq_position!=ENDFLAG)
	{
		if(dummychr->genes->lookupRot->energy_var_fix==FIXED_POSITION_PTR) /* fixed position */
		{
				*fixed_sasa += dummychr->genes->choice_ptr->lookup_res_ptr->sasa_total;
				*fixed_hphob_sasa += dummychr->genes->choice_ptr->lookup_res_ptr->sasa_hphob;
				*fixed_charge += dummychr->genes->choice_ptr->resparam_ptr->overall_charge_pH_avg;
				*E_transfer += dummychr->genes->choice_ptr->lookup_res_ptr->E_transfer;
		}
		dummychr->genes = dummychr->genes->nextgene;
	}
	dummychr->genes = dummychr->firstgene;
}


/* given a CHROMOSOME chr, this function returns a solubility score based on how close it is to
	satsifying the three solubility criteria of 
	OVERALL_CHARGE, FRACTION_HYDROPHOBIC_SASA_CUTOFF, and TRANSFER_FREE_ENERGY_DENSITY_CUTOFF.
   A score of 0 means all three criteria have been satisfied. Otherwise, the returned score is >0.
	score = SIGMA(1.0 - target_value/desired_value <-- inverted dependent on sign and magnitude) 	
   Used by solubilize_CHROMOSOME as an objective function
*/
double score_CHROMOSOME_solubility(CHROMOSOME *chr)
{
  	extern double FRACTION_HYDROPHOBIC_SASA_CUTOFF;
  	extern double TRANSFER_FREE_ENERGY_DENSITY_CUTOFF;
	extern double OVERALL_CHARGE;
	double sasa_total, sasa_hydrophobic, frac_hydrophobic, overall_charge, transfer_free_energy_density;
	double E_transfer_ratio, frac_hphob_ratio, charge_ratio;

	chr->genes = chr->firstgene;

	/* sequence space only....don't have enough info to score solubility */
	if(chr->genes->choice_ptr->lookup_res_ptr==NULL)
		return(0);

	sasa_total = 0; overall_charge = 0; transfer_free_energy_density=0;
        sasa_hydrophobic = 0;
        frac_hydrophobic = 0;
	E_transfer_ratio=0; frac_hphob_ratio=0; charge_ratio=0;

	chr->genes = chr->firstgene;
	sasa_total = 0; overall_charge = 0; transfer_free_energy_density=0;
        sasa_hydrophobic = 0;
        frac_hydrophobic = 0;
	
        
        while(chr->genes->seq_position!=ENDFLAG)
        {
                sasa_total += chr->genes->choice_ptr->lookup_res_ptr->sasa_total;
                sasa_hydrophobic += chr->genes->choice_ptr->lookup_res_ptr->sasa_hphob;
                overall_charge += chr->genes->choice_ptr->resparam_ptr->overall_charge_pH_avg;
                transfer_free_energy_density += chr->genes->choice_ptr->lookup_res_ptr->E_transfer;
                chr->genes = chr->genes->nextgene;
        }
        chr->genes = chr->firstgene;

        frac_hydrophobic = sasa_hydrophobic/sasa_total;
        transfer_free_energy_density = transfer_free_energy_density/sasa_total;

	E_transfer_ratio=0; frac_hphob_ratio=0; charge_ratio=0;
	
	if(frac_hydrophobic > FRACTION_HYDROPHOBIC_SASA_CUTOFF)
               frac_hphob_ratio = 1.0 - FRACTION_HYDROPHOBIC_SASA_CUTOFF/frac_hydrophobic;

        if(transfer_free_energy_density > TRANSFER_FREE_ENERGY_DENSITY_CUTOFF)
	{
		if(TRANSFER_FREE_ENERGY_DENSITY_CUTOFF==0)
		{
			E_transfer_ratio = 1.0 + transfer_free_energy_density;
		}
		else if(TRANSFER_FREE_ENERGY_DENSITY_CUTOFF>0)
		{
			E_transfer_ratio = 1.0 - TRANSFER_FREE_ENERGY_DENSITY_CUTOFF/transfer_free_energy_density;
		}
		else
		{
			if(transfer_free_energy_density<0)
			{
				E_transfer_ratio = 1.0 - fabs(transfer_free_energy_density/TRANSFER_FREE_ENERGY_DENSITY_CUTOFF);
			}
			else
			{
				E_transfer_ratio = 1.0 + transfer_free_energy_density;
			}
		}
	}	

        if(charge_within_specifications(overall_charge)==0)
	{
		if(overall_charge*OVERALL_CHARGE>0)	/* same sign */
		{
			if(fabs(overall_charge)>fabs(OVERALL_CHARGE))
				charge_ratio = 1.0 - fabs(OVERALL_CHARGE/overall_charge);
			else
				charge_ratio = 1.0 - fabs(overall_charge/OVERALL_CHARGE);
		}
		else	/* opposite signs */
		{
			if(fabs(overall_charge)>fabs(OVERALL_CHARGE))
				charge_ratio = 1.0 + fabs(OVERALL_CHARGE/overall_charge);
			else
				charge_ratio = 1.0 + fabs(overall_charge/OVERALL_CHARGE);
		}
	}

	return(E_transfer_ratio + frac_hphob_ratio + charge_ratio);
}

/* This function returns in CHROMOSOME input_chr (which has allocated GENE linked list) a 
	soluble sequence. A genetic algorithm is performed, scoring solubility with score_CHROMOSOME_solubility.
	This function does NOT optimize solubility; it merely tries to identify a sequence which satisfies 
	the solubility criteria; the initial population are mutated input_chr to keep solutions near input_chr.
*/
void solubilize_CHROMOSOME(CHROMOSOME *input_chr)
{
	CHROMOSOME *chr;
	extern int SOLUBILITY_CUTOFF_FLAG;
	int i, j, first, newpopsize, popsize, max_gen, convergence_counter, numCyclesSameEnergy, GenX;
	double best_score,  prev_score, temperature_decr;
	double T, recomb_freq, mut_freq, dummy_mutfreq;

	/* input_chr->genes->choice_ptr->lookup_res_ptr must be defined if solubility is to be checked */
	if(input_chr->genes->choice_ptr->lookup_res_ptr==NULL)
		 return;

	/* not screening for solubility or it is already soluble */
	if(is_this_chr_soluble(input_chr)==1)
		return;

	first=1;
	popsize=1000;	
	newpopsize = 2*popsize;
	
	max_gen=1000;
	recomb_freq = 0.5;
	mut_freq = 0.05;
	T = 5000;
	temperature_decr=10;

	SOLUBILITY_CUTOFF_FLAG=0;	/* set this temporarily; will reset before returning */

	chr = (CHROMOSOME *)calloc(newpopsize+2,sizeof(CHROMOSOME));

	for(i=1;i<=newpopsize;++i)
	{
		chr[i].genes = (MENDEL *)malloc(sizeof(MENDEL));
		chr[i].firstgene = chr[i].genes;
		chr[i].bkbngenes = NULL; chr[i].first_bkbngene=NULL;

		input_chr->genes = input_chr->firstgene;
		while(input_chr->genes->seq_position!=ENDFLAG)
		{
			copyGENE(chr[i].genes,input_chr->genes);

			if(chr[i].genes->varpos_ptr->fixed_flag==0) /* don't mutate fixed */
			if(chr[i].genes->varpos_ptr->core_flag!='c')	/* don't mutate core */
				if(dice()<=mut_freq)
					mutate_sidechain(chr[i].genes, (*chr[i].genes->varpos_ptr) );

			chr[i].genes->nextgene = (MENDEL *)malloc(sizeof(MENDEL));
			chr[i].genes = chr[i].genes->nextgene;

			input_chr->genes = input_chr->genes->nextgene;
		}
		chr[i].genes->nextgene = NULL;
		chr[i].genes->seq_position = ENDFLAG;

		input_chr->genes = input_chr->firstgene;
		chr[i].genes = chr[i].firstgene;

		generate_custom_sequence_CHROMOSOME(&chr[i], 0);

		chr[i].energy = score_CHROMOSOME_solubility(&chr[i]);

		if(chr[i].energy <= EPS)	/* found a soluble one; bail out now */
		{
			copyCHROMOSOME((*input_chr),chr[i]);
			input_chr->energy = DBL_MAX;
	
			for(j=1;j<=i;++j)
				free_CHROMOSOME(&chr[j]);
			free_memory(chr);

			

			SOLUBILITY_CUTOFF_FLAG=1; 
			return;
		}
	}	
	
	/*	mutate chromosomes w/ the same score  */
		for(i=1; i<=newpopsize; ++i)	
		{
			while(is_chr_i_isoenergetic_with_others(i, chr, popsize)==1)
			{
				chr[i].genes = chr[i].firstgene;
				while(chr[i].genes->seq_position!=ENDFLAG)
				{
					if(chr[i].genes->varpos_ptr->fixed_flag==0) /* don't mutate fixed */
					if(chr[i].genes->varpos_ptr->core_flag!='c')	/* don't mutate core */
						if(dice()<=mut_freq)
							mutate_sidechain(chr[i].genes, (*chr[i].genes->varpos_ptr) );
					chr[i].genes = chr[i].genes->nextgene;
				}
				chr[i].genes = chr[i].firstgene;

				generate_custom_sequence_CHROMOSOME(&chr[i],0);
				chr[i].energy = score_CHROMOSOME_solubility(&chr[i]);

				if(chr[i].energy <= EPS)	/* found a soluble one; bail out now */
				{
					copyCHROMOSOME((*input_chr),chr[i]); 
					input_chr->energy = DBL_MAX;
	
					for(j=1;j<=newpopsize;++j)
						free_CHROMOSOME(&chr[j]);
					free_memory(chr);

					
					SOLUBILITY_CUTOFF_FLAG=1; 
					return;
				}
			}
		}


	sort_CHROMOSOME(&first,&newpopsize,chr);

	best_score = chr[1].energy;    
	T = 5000;
	prev_score = 0;
	dummy_mutfreq = mut_freq;
	convergence_counter=0; numCyclesSameEnergy=0; GenX=0;


	/* soluble chr has energy=0 from score_CHROMOSOME_solubility */
	/* we're not trying to optimize; we just want something that's below the cutoff */
	while(chr[1].energy > EPS )	
	{	
		prev_score = best_score;
		++GenX;


		if(convergence_counter > max_gen || fabs(chr[1].energy - chr[popsize].energy) < EPS)
		{
			failure_report("ERROR Solubility criterion is not achievable!", "fail");
			/*
			fprintf(stderr,"ERROR Solubility criterion is not achievable!\n");
			exit(1);
			*/
		}

		calculate_mating_frequencies(chr, popsize, T);  		

		/* mate chr[1]->[popsize], loading into chr[popsize+1]->[newpopsize] */
      		mate_sidechains(chr,popsize,recomb_freq,dummy_mutfreq); 
   
		/* score solubility of children */
		for(i=popsize+1; i<=newpopsize; ++i)
		{
			chr[i].energy = score_CHROMOSOME_solubility(&chr[i]);

			if(chr[i].energy <= EPS)	/* found a soluble one; bail out now */
			{
				copyCHROMOSOME((*input_chr),chr[i]); 
				input_chr->energy = DBL_MAX;
	
				for(j=1;j<=newpopsize;++j)
					free_CHROMOSOME(&chr[j]);
				free_memory(chr);

				
				SOLUBILITY_CUTOFF_FLAG=1; 
				return;
			}
		}

		/*	mutate chromosomes w/ the same score  */
		for(i=1; i<=newpopsize; ++i)	
		{
			while(is_chr_i_isoenergetic_with_others(i, chr, popsize)==1)
			{
				chr[i].genes = chr[i].firstgene;
				while(chr[i].genes->seq_position!=ENDFLAG)
				{
					if(chr[i].genes->varpos_ptr->fixed_flag==0) /* don't mutate fixed */
					if(chr[i].genes->varpos_ptr->core_flag!=2)	/* don't mutate core */
						if(dice()<=mut_freq)
							mutate_sidechain(chr[i].genes, (*chr[i].genes->varpos_ptr) );
					chr[i].genes = chr[i].genes->nextgene;
				}
				chr[i].genes = chr[i].firstgene;				

				generate_custom_sequence_CHROMOSOME(&chr[i],0);
				chr[i].energy = score_CHROMOSOME_solubility(&chr[i]);

				if(chr[i].energy <= EPS)	/* found a soluble one; bail out now */
				{
					copyCHROMOSOME((*input_chr),chr[i]); 
					input_chr->energy = DBL_MAX;
	
					for(j=1;j<=newpopsize;++j)
						free_CHROMOSOME(&chr[j]);
					free_memory(chr);

					
					SOLUBILITY_CUTOFF_FLAG=1; 
					return;
				}
			}
		}
		
		sort_CHROMOSOME(&first,&newpopsize,chr); /* sort population */
		best_score = chr[1].energy;
		
		/* increase mutation freq if it looks like we're in a local minimum; 10 generations w/ equal energy */
		/* after 10 cycles of increased mut_freq, relax for 10 cycles at mutation_freq */
		if(fabs(prev_score - best_score)<=EPS)
		{
	  		++numCyclesSameEnergy;
	  		++convergence_counter;
	 	  
	  		if(convergence_counter >= 10)
	    		{
			    if(numCyclesSameEnergy<10)
	      				dummy_mutfreq = dummy_mutfreq + 0.025; 
				else
					dummy_mutfreq = mut_freq;	      

	      			if(numCyclesSameEnergy%20==0)
					numCyclesSameEnergy=1;
	    		}
		}
      		else
		{
	  		numCyclesSameEnergy=1;
	  		dummy_mutfreq = mut_freq;
	  		convergence_counter=1;
		}

	if(T != 100)
	  T = T - temperature_decr;


	}


	copyCHROMOSOME((*input_chr),chr[1]); 

	

	input_chr->energy = DBL_MAX;
	
	for(i=1;i<=newpopsize;++i)
		free_CHROMOSOME(&chr[i]);
	free_memory(chr);


	SOLUBILITY_CUTOFF_FLAG=1;
	return;
}


