/* EGAD: complex_formation_energy.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for complex_formation_energy.cpp
   
*/



#ifndef complex_formation_energy_header_flag
#define complex_formation_energy_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "energy_functions.h"
#include "pdbATOM_utilities.h"
#include "output_stuff.h"
#include "moremath.h"
#include "io.h"
#include "input_stuff.h"
#include "lookup_table.h"
#include "MC.h"
#include "somewhat_FASTER.h"

/* for complex and free, finds the interfacial residues and their sasa change; list_of_interface_residues array ends w/ ENDFLAG and contains the seq_position; energies not calculated if calc_energy_flag==0 */
void find_interface_residues(mini_pdbATOM *complex_pdb, mini_pdbATOM *free_pdb, int num_res, int *list_of_interface_residues, double *delta_sasa_interface, double *energy_interface_residues, int calc_energy_flag);

/* coords of atoms in free_A are translated step angstroms along vector AB_hat; coords placed in new_A */
void translate_mini_pdbATOM_along_vector_AB(mini_pdbATOM *free_A, mini_pdbATOM *new_A, double step, CARTESIAN AB_hat);


/* returns the minimal distance between atoms stored in mini_pdbATOM arrays new_A and free_B */
double distance_between_two_mini_pdbATOM(mini_pdbATOM *new_A, mini_pdbATOM *free_B);

/* move proteinA away from proteinB so that they are separation_distance +/- tolerance apart
	move along the inter-centroid vector
	freeA = coordinates of A
	freeB = coordinates of B
	newA = new coordinates of A
*/
void move_complex_apart(mini_pdbATOM *free_A, mini_pdbATOM *free_B, mini_pdbATOM *new_A, const double separation_distance, double tolerance);



/* this function splits a complex in input_complex and puts the coords of the separated complex in free_A and free_B 
 	super_chain A moves away from B */
void split_complex(mini_pdbATOM *input_complex, mini_pdbATOM *free_A, mini_pdbATOM *free_B,
				char *chain_id_list,SUPER_CHAIN_ID_LIST *super_chain_id_list);

/* this function splits a complex in input_complex separation_distance apart and puts 
	the coords of the separated complex in seperated_cmplx 
*/
void seperate_the_complex(mini_pdbATOM *input_complex, mini_pdbATOM *seperated_cmplx, char *chain_id_list,
				SUPER_CHAIN_ID_LIST *super_chain_id_list, double separation_distance);

/* given a complex in input_complex, this function returns the complex_formation energy  */
void complex_formation_energy(mini_pdbATOM *input_complex, char *chain_id_list, SUPER_CHAIN_ID_LIST *super_chain_id_list, ENERGY *energy,  SASA_SUM *sasa_sum);


/* this function rotamer-optimizes the complex in protein, splits the complex, rotamer-optimizes the free, 
	and outputs all the structures and energies 
   If strncmp(protein->parameters.algorithm,"STATIC",6)==0, rotamer optimization is not performed */
void complex_formation_energy_master(char *inputfilename, PROTEIN *protein);

/* this function identifies the interface residues for a protein-protein complex, and then performs 
	 scanning mutagenesis */
void interface_scan(char *main_inputfile, PROTEIN *protein);

/* identifies and redesigns the interface residues via a multistate ga */
void design_interface(char *main_inputfile, PROTEIN *protein);

#endif
