/* EGAD: multistate.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Dec 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for multstate.cpp
*/

#ifndef multistate_header_flag
#define multistate_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "input_stuff.h"
#include "GA_utilities.h"
#include "HQM_rotamers.h"
#include "energy_functions.h"
#include "rotamer_calc_master.h"
#include "sequence_CHROMOSOME_stuff.h"
#include "sequence_restraint.h"
#include "multistate_objective_function.h"

void get_rid_of_isosequence_chrs(CHROMOSOME *chr, double mut_freq, int pop_size);

/* given a CHROMOSOME chr, create a file that can be used as a slave inputfile.
	Only the user-defined positions are written; the others are inferred from the 
	top of the main inputfile sent to the foreman job (from the OTHER_POSITIONS line)
*/
void CHROMOSOME_to_slave_inputfile(CHROMOSOME *chr, char *filename, int output_coord_flag, int initialize_flag);


void make_multistate_inputfiles_for_chr(CHROMOSOME *chr, char *prefix, int output_coord_flag, int initialize_flag);
void CHROMOSOME_array_to_fitness(int start_index, int stop_index, CHROMOSOME *chr);
void multistate_ga(PROTEIN *protein);
void GA_sequence_control(PARAMETERS *parameters, CHROMOSOME *chrs, int chrs_size, VARIABLE_POSITION var_pos[]);
void evolve_sequence(PARAMETERS *parameters, CHROMOSOME chrs[], VARIABLE_POSITION var_pos[]);


double find_best_residue(int i, VARIABLE_POSITION *varpos, CHROMOSOME *input_chr, int *best_res);
void multistate_hqm(PROTEIN *protein);

void multistate_design(PROTEIN *protein);


#endif
