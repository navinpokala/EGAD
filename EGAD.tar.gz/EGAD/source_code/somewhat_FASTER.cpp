/* EGAD: somewhat_FASTER.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for using a variation of FASTER for rotamer optimization.

FASTER = Fast and Accurate Sidechain Topology and Energy Refinement

Desmet et al Proteins 48:31 (2002)

*/

#include "somewhat_FASTER.h"

void FASTER_rotamers(PARAMETERS *parameters, CHROMOSOME *chr, VARIABLE_POSITION *var_pos, LOOKUP_ENERGY *lookupEnergy)
{

	int GenX, ii, numVarPositions,converged_flag, num_moving_positions;
	int i, j, k, i_res, i_res_rot, current_num_moving_pos;
	int best_res, best_res_rot;
	double fixed_sasa, fixed_hphob_sasa, fixed_charge, fixed_E_transfer;
	GENE i_gene;
	static int *already_used_positions=NULL, *indicies_of_floating_positions=NULL, max_residues=0;
	FILE *logfile_ptr;
	char *logfile=NULL, *escape_hatch_filename=NULL;
	time_t now, start_time;
	CHROMOSOME *best_chr, *best_rotamer_chr;
	extern int LOGFILE_FLAG, MAX_RESIDUES, SOLUBILITY_CUTOFF_FLAG,GET_PID;
	extern double MAX_OPTIMIZATION_TIME;
	extern char *CURRENT_WORKING_DIRECTORY;
	int i_res_minus1, i_minus_j;
	int j_res,j_res_rot,num_j_rot;
	extern LOOKUP_ENERGY_RESIDUE_X *NON_INTERACT_LOOKUP_RES_X;
	extern LOOKUP_ENERGY_ROTAMER_X *NON_INTERACT_LOOKUP_ROT_X;

	start_time = time(NULL);

	// eliminate some rotamers
	goldstein_singles_elimination(parameters, var_pos, lookupEnergy);

	
	current_num_moving_pos = 0;
	i=1;
	while(var_pos[i].seq_position!=ENDFLAG)
	{
		if(var_pos[i].fixed_flag == 0)
			if(var_pos[i].dead_ended_flag == 0)
				++current_num_moving_pos;

		++i;
	}

	/* not really moving, so just go through the motions */
        /* or only one position is moving....HQM will find the solution */
        if(parameters->log10_rotamer_combinations==0 || current_num_moving_pos <= 2)
        {
		randomize_sidechains(chr, 1);
                CHROMOSOME_to_lookupEnergy(chr, &parameters->fixedatoms_energy); 
		HQM_rotamers(parameters, chr, var_pos); 
		return;
        }

	now = time(NULL);

	if(LOGFILE_FLAG == 1)
	{
		logfile = (char *)calloc(MAXLINE,sizeof(char));
		sprintf(logfile,"%s.log", parameters->output_prefix);
		escape_hatch_filename = (char *)calloc(MAXLINE,sizeof(char));
		sprintf(escape_hatch_filename,"%s/escape.FASTER.%d",CURRENT_WORKING_DIRECTORY,GET_PID);

		logfile_ptr = fopen_file(logfile,"a");
		fprintf(logfile_ptr,"Starting FASTER method\t%s", ctime(&now));
		fprintf(logfile_ptr,"To exit the FASTER and move to the next step:");
                fprintf(logfile_ptr,"\ttouch %s\n",escape_hatch_filename);
		fclose(logfile_ptr);
			
	}

	// create some working dummy CHROMOSOME structures

	best_chr = (CHROMOSOME *)malloc(sizeof(CHROMOSOME));
	best_chr->bkbngenes = NULL; best_chr->first_bkbngene = NULL;
	inoculate_sidechains(best_chr, var_pos, 0);
	CHROMOSOME_to_lookupEnergy(best_chr,&parameters->fixedatoms_energy);

	
	CHROMOSOME_to_lookupEnergy(chr,&parameters->fixedatoms_energy);

	best_rotamer_chr = (CHROMOSOME *)malloc(sizeof(CHROMOSOME));
	best_rotamer_chr->bkbngenes = NULL; best_rotamer_chr->first_bkbngene = NULL;
	inoculate_sidechains(best_rotamer_chr, var_pos, 0);
	CHROMOSOME_to_lookupEnergy(best_rotamer_chr,&parameters->fixedatoms_energy);

	
	// for JOBTYPE FASTER, default parameters->number_MC_cycles = 10

	GenX=1;
	while(GenX <= parameters->number_MC_cycles)
	{
		randomize_sidechains(chr, 1);		

		MC_rotamers(parameters, chr, var_pos);
		HQM_rotamers(parameters,chr, var_pos);

		now = time(NULL);
		if(chr->energy < best_chr->energy)
		{
			copyCHROMOSOME((*best_chr), (*chr));
			if(LOGFILE_FLAG == 1)
			{
				logfile_ptr = fopen_file(logfile,"a");
				fprintf(logfile_ptr,"FASTER mc/hqm %d\t%lf\t%s",GenX, best_chr->energy, ctime(&now));
				fclose(logfile_ptr);
			}
		}
		
		if(difftime(now,start_time) >= MAX_OPTIMIZATION_TIME)
			GenX = parameters->number_MC_cycles+10;

		if(LOGFILE_FLAG == 1)
			if(does_this_file_exist(escape_hatch_filename)==1)	
				GenX = parameters->number_MC_cycles+10;


		++GenX;
	}

	// allocate memory for arrays that hold info on residues that have been visited

	if(max_residues< MAX_RESIDUES)
   	{
		max_residues=MAX_RESIDUES;
		if(indicies_of_floating_positions != NULL)
		{
			free_memory(indicies_of_floating_positions);
			free_memory(already_used_positions);
		}
		indicies_of_floating_positions = (int *)calloc(MAX_RESIDUES,sizeof(int));
		already_used_positions = (int *)calloc(MAX_RESIDUES,sizeof(int));
   	}

	for(i=1;i<=parameters->numMovingPositions+1;++i)
		already_used_positions[i] = ENDFLAG;

	i=1; k=0; num_moving_positions=0;
   	while(var_pos[i].seq_position!=ENDFLAG)
   	{
   		 if(var_pos[i].fixed_flag == 0)  /* not fixed, so add to the list */
		 if(var_pos[i].dead_ended_flag == 0)  /* not dead-ended, so add to the list */
		 {
			++k;
			++num_moving_positions;
			indicies_of_floating_positions[k] = i;
		 }
		 ++i;
   	}

	i=1;
    	while(var_pos[i].seq_position!=ENDFLAG)
      		++i;
    	numVarPositions = i-1;

	copyCHROMOSOME((*chr), (*best_chr));

	i_gene = (MENDEL *)malloc(sizeof(MENDEL));

	// calculate fixed_position contributions to sasa and charge 
 	if(SOLUBILITY_CUTOFF_FLAG == 1)
		fixed_position_sasa_charge(best_chr, &fixed_sasa, &fixed_hphob_sasa, &fixed_charge, &fixed_E_transfer);

	GenX = 1; converged_flag=0;
	while(converged_flag == 0)
	{
	
	converged_flag = 1;	ii=0; 

	
	now = time(NULL);
	if(difftime(now,start_time) >= MAX_OPTIMIZATION_TIME)
		ii = num_moving_positions + 2;	

	if(LOGFILE_FLAG == 1)
		if(does_this_file_exist(escape_hatch_filename)==1)	
			ii = num_moving_positions + 2;
	
	while(ii<num_moving_positions)
	{
		// pick a random position to fix
		k=0;
		k = randint(num_moving_positions);
		while(has_this_position_been_used(k,already_used_positions)==1 || k==0)
			k = randint(num_moving_positions);
		i=1;
		while(already_used_positions[i]!=ENDFLAG)
			++i;
		already_used_positions[i]=k;

		i = indicies_of_floating_positions[k];
		
	 	best_chr->genes = best_chr->firstgene; 
	 	while(best_chr->genes->seq_position!=var_pos[i].seq_position)
	 	{
			best_chr->genes = best_chr->genes->nextgene;
	 	}   
	 	copyGENE(i_gene,best_chr->genes);
		best_chr->genes = best_chr->firstgene; 

		copyCHROMOSOME((*chr), (*best_chr));
		
		for(i_res=1;i_res<=var_pos[i].number_of_choices;++i_res)
		if(var_pos[i].choice[i_res].in_use_flag==1)
		{
			CHOICE_to_GENE(i_gene, var_pos[i].choice[i_res], i_res);

			for(i_res_rot=1;i_res_rot<=var_pos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
			if(var_pos[i].choice[i_res].lookup_res_ptr->lookupRot[i_res_rot].in_use_flag==1)
			{
				// copy this resimer to chr

				i_gene->lookupRot_index = i_res_rot;
				i_gene->chi = i_gene->choice_ptr->resparam_ptr->rotamerlib_ptr->rotamer[i_gene->lookupRot_index].chi;
				i_gene->lookupRot = &(i_gene->choice_ptr->lookup_res_ptr->lookupRot[i_gene->lookupRot_index]);
		
				
				i_res_minus1 = i_res-1;
				

				chr->genes = chr->firstgene; 
	 			while(chr->genes->seq_position!=var_pos[i].seq_position)
					chr->genes = chr->genes->nextgene;
	 			copyGENE(chr->genes, i_gene); 
				chr->genes = chr->firstgene; 

				copyCHROMOSOME((*best_rotamer_chr), (*chr));

				best_rotamer_chr->genes = best_rotamer_chr->firstgene; 
				for(j=1;j<=numVarPositions;++j)
				if(i!=j)
				if(var_pos[j].fixed_flag==0)
				if(var_pos[j].dead_ended_flag==0)
				{
					while(best_rotamer_chr->genes->seq_position!=var_pos[j].seq_position)
						best_rotamer_chr->genes = best_rotamer_chr->genes->nextgene;
	 				best_res = best_rotamer_chr->genes->j_choice_index + 1;
					best_res_rot = best_rotamer_chr->genes->lookupRot_index;
		
					/*
					find_best_res_res_rot(j, var_pos, chr->firstgene, fixed_sasa, fixed_hphob_sasa, fixed_charge, fixed_E_transfer, &best_res, &best_res_rot);
					*/

			
				

					if(j > i)
					{
						// find the best resimer for position j
						// if i,i_res,i_res_rot interacts with any rotamer at position j
						if(ERESROT.lookupX[j-i].lookupResX != NON_INTERACT_LOOKUP_RES_X)
				 			find_best_res_res_rot(j, var_pos, chr->firstgene, fixed_sasa, fixed_hphob_sasa, fixed_charge, fixed_E_transfer, &best_res, &best_res_rot);

					}
					else 
					{
						i_minus_j = i-j;

						// if any rotamer at j interacts with i,i_res,i_res_rot, find the best resimer for position j
						j_res = 1;
						while(j_res <= var_pos[j].number_of_choices)
						{
							j_res_rot=1;
							num_j_rot = var_pos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;

							while(j_res_rot <= num_j_rot)
							{
								if(j_res <= var_pos[j].number_of_choices)
								if(ERESROTj.in_use_flag == 1)
								if(ERESROTj.lookupX[i_minus_j].lookupResX != NON_INTERACT_LOOKUP_RES_X)
								if(ERESROTj.lookupX[i_minus_j].lookupResX[i_res_minus1].lookupRotX != NON_INTERACT_LOOKUP_ROT_X)
								
								{
				 					find_best_res_res_rot(j, var_pos, chr->firstgene, fixed_sasa, fixed_hphob_sasa, fixed_charge, fixed_E_transfer, &best_res, &best_res_rot);

									j_res_rot = var_pos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers + 1;
									j_res = var_pos[j].number_of_choices + 1;
								}

								++j_res_rot;
							}
							++j_res;
						}
					}
					
					

					// the rotamer changed
	 				if(best_res != best_rotamer_chr->genes->j_choice_index + 1 || 
						best_res_rot != best_rotamer_chr->genes->lookupRot_index)
					{
						CHOICE_to_GENE(best_rotamer_chr->genes, var_pos[j].choice[best_res], best_res);
				  		best_rotamer_chr->genes->lookupRot_index = best_res_rot;
						best_rotamer_chr->genes->chi = 
	best_rotamer_chr->genes->choice_ptr->resparam_ptr->rotamerlib_ptr->rotamer[best_rotamer_chr->genes->lookupRot_index].chi;
						best_rotamer_chr->genes->lookupRot = 
	&(best_rotamer_chr->genes->choice_ptr->lookup_res_ptr->lookupRot[best_rotamer_chr->genes->lookupRot_index]);
					}

				}

				best_rotamer_chr->genes = best_rotamer_chr->firstgene; 

				CHROMOSOME_to_lookupEnergy(best_rotamer_chr, &parameters->fixedatoms_energy);
				now = time(NULL);

				if(best_rotamer_chr->energy < best_chr->energy)
				{
					copyCHROMOSOME((*best_chr), (*best_rotamer_chr));
					converged_flag = 0;
					if(LOGFILE_FLAG == 1)
					{
						logfile_ptr = fopen_file(logfile,"a");
						fprintf(logfile_ptr,"FASTER iteration %d position %d best_energy = %lf\t%s",
							GenX,var_pos[i].seq_position,best_chr->energy,ctime(&now));
						fclose(logfile_ptr);
					}
				}
			}
		}

		if(LOGFILE_FLAG == 1)
			{
				logfile_ptr = fopen_file(logfile,"a");
				fprintf(logfile_ptr,"FASTER iteration %d position %d\t%s",
						GenX,var_pos[i].seq_position,ctime(&now));
				fclose(logfile_ptr);
			}

		if(difftime(now,start_time) >= MAX_OPTIMIZATION_TIME)
			ii = num_moving_positions + 2;
	
		if(LOGFILE_FLAG == 1)
			if(does_this_file_exist(escape_hatch_filename)==1)	
				ii = num_moving_positions + 2;

		++ii;
	}
		++GenX;

		// reset the already_used_positions array
		i=1;
		while(already_used_positions[i]!=ENDFLAG)
		{
			already_used_positions[i] = ENDFLAG;
			++i;
		}
	}


	copyCHROMOSOME((*chr), (*best_chr));

	// just to double-check that there isn't better solution nearby
	MC_rotamers(parameters, chr, var_pos);
	HQM_rotamers(parameters,chr, var_pos);

			if(LOGFILE_FLAG == 1)
			{
				logfile_ptr = fopen_file(logfile,"a");
				fprintf(logfile_ptr,"FASTER final mc/hqm %lf\t%s",chr->energy, ctime(&now));
				fclose(logfile_ptr);
			}


	
	free_memory(i_gene);


	free_CHROMOSOME(best_chr);
	free_memory(best_chr);

	free_CHROMOSOME(best_rotamer_chr);
	free_memory(best_rotamer_chr);

	if(LOGFILE_FLAG == 1)
	{
		free_memory(logfile);

		if(does_this_file_exist(escape_hatch_filename)==1)
			rm_file(escape_hatch_filename);

		free_memory(escape_hatch_filename);
	}

}


void FASTER_rotamer_control(PROTEIN *protein)
{
	
	int i;
	
	inoculate_sidechains(&protein->final_chr, protein->var_pos, 0);

	FASTER_rotamers(&protein->parameters, &protein->final_chr, protein->var_pos, protein->lookupEnergy);

	// other functions like having at least 50 of this 
	if(protein->chr == NULL)
	{
		protein->sizeof_chr_array = 50;
		protein->chr = (CHROMOSOME *)calloc((protein->sizeof_chr_array+2),sizeof(CHROMOSOME));
		for(i=1;i<=protein->sizeof_chr_array;++i)
                {
                        inoculate_sidechains(&protein->chr[i], protein->var_pos,0);
                        protein->chr[i].bkbngenes = NULL;
                        protein->chr[i].first_bkbngene = NULL;
				copyCHROMOSOME(protein->chr[i], protein->final_chr);
                }
	}

	protein->E_working = protein->final_chr.energy;
        final_chr_to_final_pdb_final_energy(protein);

}

