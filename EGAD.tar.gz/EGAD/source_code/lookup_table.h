/* EGAD: lookup_table.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for lookup_table.cpp

*/

#ifndef lookup_table_header_flag
#define lookup_table_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "energy_functions.h"
#include "pairwise_energy_calc.h"
#include "dihedral_cartesian.h"
#include "GENES_pdb.h"
#include "SASA.h"
#include "lookup_table_disk_stuff.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "GA_utilities.h"
#include "sequence_CHROMOSOME_stuff.h"
#include "sequence_restraint.h"

/* initialize non-interaction pointers for the lookuptable, 
        and BASE_THREE_CONVERT matrix for local minimization of methyl groups. 
   called by generate_lookup_table
*/
void initialize_lookuptable_pointers();


void free_LOOKUP_ROTAMER_X_HBOND(LOOKUP_ROTAMER_X_HBOND **lookupRotX_hbond);

/*   This function de-allocates memory occupied by the lookup table. Called by input_stuff.cpp: free_PROTEIN */
void free_lookup_table(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos);

/* This function generates a lookup table for all possible
   var_residue-fixed_atom and var-var pairwise interaction energies for 
   fixed backbone optimizations. 
   Links protein->var_pos lookup_table pointers to appropriate locations.
   Assumes that protein has been initialized with input_stuff.cpp: input_stuff
   All the rotamer optimization jobs assume that this function has been called.
*/
void generate_lookup_table(PROTEIN *protein);



#endif
