/* EGAD: pK_calculate.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for pK_calculate.cpp
   
*/


#ifndef pK_calculate_header_flag
#define pK_calculate_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include "structure_types.h"
#include "scmf.h"

/* uses scmf to calculate the pK of ionizable groups in a protein */
void pK_calculate(PROTEIN *protein);

#endif
