/* EGAD: sequence_restraint.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Dec 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for sequence_restraint.cpp
*/

#ifndef sequence_restraint_header_flag
#define sequence_restraint_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "GA_utilities.h"
#include "sequence_CHROMOSOME_stuff.h"
#include "io.h"


// flips to wt while number of mutations > MAX_MUTATIONS, returns num_mutations_made (0 = inputed chr is OK)
int restrict_mutations(CHROMOSOME *chr, int initialize_flag);


void generate_custom_sequence_CHROMOSOME(CHROMOSOME *chr, int initialize_flag);

#endif
