/* EGAD: VARIABLE_POSITION.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for VARIABLE_POSITION.cpp

These functions are called by modify_VARIABLE_POSITION and by input_stuff.cpp: input_VARIABLE_POSITIONS

*/

#ifndef VARIABLE_POSITION_header_flag
#define VARIABLE_POSITION_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "search_and_sort.h"
#include "energy_functions.h"
#include "pdbATOM_utilities.h"
#include "pairwise_energy_calc.h"


/* Given an array var_seqpos of variable positions (ending with ENDFLAG), a pdb structure pdb, a distance cutoff, 
   and a scale factor window, this function returns the number of neighbors and variable positions; 
   these are also included in the array neighbors.    
*/
int find_neighbors(int *var_seqpos, pdbATOM *pdb, int *neighbors, double *cutoff, double window);

/* This function binds a group of VARIABLE_POSITION arrays. 
    fixed_res contains the positions that are fixed in rotamer and sequence, but are allowed to undergo 
	local rotamer relaxation.
    neighbors contains the positions that are fixed in sequence,  but are allowed to sample all rotamers. 
    user_defined contains the residues that are defined by the user as being variable.
    The array melded is the final VARIABLE_POSITION. 
*/ 
void meld_VARIABLE_POSITION(VARIABLE_POSITION *melded, VARIABLE_POSITION *fixed_res, 
				VARIABLE_POSITION *neighbors, VARIABLE_POSITION *user_defined, int *fixed_positions);


/* This function generates a VARIABLE_POSITION array for an array listofvarpos of numVarPos variable positions 
	(ending with ENDFLAG) 
    for a structure pdb. 
*/
void listofvarpos_to_VARIABLE_POSITION(int *listofvarpos, VARIABLE_POSITION *var_pos, 
					    pdbATOM *pdb, int numVarPos, RESPARAM *resparam);

/* Given an array varpos containing desired seq positions (ending w/ endflag), this function 
	extracts sidechain dihedrals from pdbATOM array pdb and creates a rotamer library (w/ rotamerlets) 
	for the native conformation for each residue specified in varpos.
	resparam = main resparam structure 
*/
void pdbATOM_to_VARIABLE_POSITION(VARIABLE_POSITION *varpos, pdbATOM *pdb, RESPARAM *resparam);

/* Given a PROTEIN containing PARAMETERS and an array of VARIABLE_POSITION, this 
	function will modify the PARAMETERS and VARIABLE_POSITION inside PROTEIN to include 
	neighboring residues whose rotamer identities are allowed to float, extract the native rotamers
	if applicable, and attach all the appropriate pointers to VARIABLE_POSITIONS.
	The born radii and energies of fixed atoms are calculated.
	Called by input_stuff.cpp: input_VARIABLE_POSITIONS
*/
void modify_VARIABLE_POSITION(PROTEIN *protein, int *fixed_positions);

/* similar to Marshall & Mayo JMB 305: 619-631 (2001) */
  /* Place a linear 3-carbon pseudosidechain (methyl acetylene MEA) at each position; get born radii */
  /* If a pseudosidechain has sasa <= CORESURF_MEA_SURF and born-CG >= CORESURF_MEA_BORN  call it core */
  /* surface if sasa < CORESURF_MEA_SURF and born-CG < CORESURF_MEA_BORN
	else interfacial */
void define_coresurfint(pdbATOM *Template, VARIABLE_POSITION *var_pos);

#endif
