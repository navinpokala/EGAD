/* EGAD: dee_utilities.h
   
Mark Voorhies, Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for dee_utilities.cpp
   
*/


#ifndef dee_utilities_header_flag
#define dee_utilities_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "io.h"

#define RESIMER_i_res protein->var_pos[i].resimer[i_resimer].i_res
#define RESIMER_i_res_rot protein->var_pos[i].resimer[i_resimer].i_res_rot

#define RESIMER_j_res protein->var_pos[j].resimer[j_resimer].i_res
#define RESIMER_j_res_rot protein->var_pos[j].resimer[j_resimer].i_res_rot

#define ERESROT_resimer protein->lookupEnergy[i].lookupRes[RESIMER_i_res].lookupRot[RESIMER_i_res_rot]
#define ERESROT_resimer_j protein->lookupEnergy[j].lookupRes[RESIMER_j_res].lookupRot[RESIMER_j_res_rot]

/* Initializes the lookuptable for dee */
void initialize_lookuptable_for_dee(PROTEIN *protein);

/* returns the pair energy for resimer pair (i,i_resimer),(j,j_resimer); i,j = seq indexes.
		if i==j, and i_resimer == j_resimer, self energy for i,i_resimer returned
		else, return 0
*/ 
double get_energy(const PROTEIN *protein, const int i, const int i_resimer, 
		  const int j, const int j_resimer);

/* returns internal and side-bkbn energy (self energy) for resimer i_resimer at seq index i */
double get_self_energy(const PROTEIN *protein, 
		       const int i, const int i_resimer);

/* for var_pos at some position, and an input_resimer at that position, find i_res and i_res_rot;
	used for converting from resimers back to residuetypes/rotamers 
*/
void get_i_res_i_res_rot_for_resimer(VARIABLE_POSITION *var_pos, int input_resimer, int *input_i_res, int *input_i_res_rot);

/* write logfile_line to logfile */
void dee_logfile(char logfile_line[], const char *logfile);

#endif
