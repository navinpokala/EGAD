/* EGAD: multistate_objective_function.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Dec 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for multistate_objective_function.cpp
*/

#ifndef multistate_objective_function_header_flag
#define multistate_objective_function_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "moremath.h"
#include "energy_functions.h"

double multistate_objective_function(CHROMOSOME *chr, ENERGY *energy, int num_competitor_structures);

#endif
