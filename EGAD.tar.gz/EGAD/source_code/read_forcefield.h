/* EGAD: read_forcefield.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for read_forcefield.cpp
   
*/


#ifndef read_forcefield_header_flag
#define read_forcefield_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "dihedral_cartesian.h"
#include "search_and_sort.h"
#include "energy_functions.h"
#include "SASA.h"
#include "io.h"
#include "ligand_stuff.h"

/* these functions are called by read_forcefield, which is called by input_stuff. */
/* pointers are linked appropriately */

/* calculate spherical volumes for each atom, taking into account covalently bound atoms;
	used for born radius calculations. called by read_forcefield.cpp: read_forcefield  */
void volume_bonded(RESPARAM *inputresparam);

/* generate and calculate CHARGE_PRODUCT matrix for all possible atompairs 
	called by read_forcefield.cpp: read_forcefield  */
void calculate_charge_products(RESPARAM *resparam);

/* This function reads in a rotamer library from rotamerfilename into an allocated array of ROTAMERLIB  
	Also reads in ligand "rotamers" 
	called by read_forcefield.cpp: read_forcefield and ligand_stuff.cpp: read_ligand_data.cpp
 */
void read_rotamers(char *rotamerfilename, ROTAMERLIB *rotamerlib);


/* read fourier-series coefficients from torsionfilename for dihedral-angle-dependent torsion energy calcs 
	called by read_forcefield.cpp: read_forcefield  
*/
void read_torsiondata(char *torsionfilename, ATOMPARAM *atomparam);

/* reads in residue or ligand topologies from resdatafilename into an allocated array of RESPARAM.
	if  count_max_res_size_flag=1, merely counts the size of residues, adjusts MAX_RES_SIZE, and returns.
	called by read_forcefield.cpp: read_forcefield and ligand_stuff.cpp: read_ligand_data.cpp
*/
void read_residuedata(char *resdatafilename, RESPARAM *resparam, ATOMPARAM *atomparam, int count_max_res_size_flag);

/* reads forcefield information into atomparam, resparam, and rotamerlib arrays (allocated by calling function). 
	sets up a lot of cross-pointers between these data structures,initializes some matricies, etc.
	read SASA tables (requires MAX_ATOMS to be defined) and ligand parameter files as well. 
	Called by input_stuff.cpp: input_stuff. 
*/

void read_forcefield(char *atomdatafile, ATOMPARAM *atomparam, RESPARAM *resparam, ROTAMERLIB *rotamerlib);

#endif
