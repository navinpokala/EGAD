/* EGAD: GENES_pdb.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for converting GENE's and CHROMOSOME's into coordinates (and vice versa).

*/


#include "GENES_pdb.h"

/* This function loads a pdbATOM array (allocated by calling function) with the variable sidechain atoms 
   represented by gene */

void GENE_to_var_pdbATOM(GENE *gene, pdbATOM *pdb)
{
  static SIDECHAIN side;
  static pdbATOM *side_atoms=NULL;

  
  if(side_atoms==NULL)
  {
	side_atoms=(pdbATOM *)calloc(MAX_RES_SIZE,sizeof(pdbATOM));
	side.atom = (micro_pdbATOM *)calloc(MAX_RES_SIZE,sizeof(micro_pdbATOM));
  }

  strcpy(pdb[1].residuetype,"END");	

 
      build_a_SideChain(&side, (*gene)->choice_ptr->bkbn, (*gene)->choice_ptr->resparam_ptr, &(*gene)->seq_position,(*gene)->chi);
      make_side_pdbATOM(side_atoms, &side);    /* make sidechain atoms */
      append_pdbATOM(side_atoms,pdb);        /* copy sidechain atoms to pdb */
   
}


/* This function loads a mini_pdbATOM array (allocated by calling function) with the variable sidechain atoms 
   represented by gene */
   
void GENE_to_mini_pdbATOM(GENE *gene, mini_pdbATOM *pdb)
{
      static SIDECHAIN *side=NULL;

      if(side==NULL)
	{
		side = (SIDECHAIN *)malloc(sizeof(SIDECHAIN));
		side->atom = (micro_pdbATOM *)calloc(MAX_RES_SIZE,sizeof(micro_pdbATOM));
	}	
   
      build_a_SideChain(side, (*gene)->choice_ptr->bkbn, (*gene)->choice_ptr->resparam_ptr, &(*gene)->seq_position,(*gene)->chi);
			       
      make_side_mini_pdbATOM(pdb, side);    /* make sidechain atoms */
   
}

/*   This function creates a CHROMOSOME containing the sidechain and backbone dihedrals 
	from the pdbATOM pdb array; resparam = main resparam structure 
*/

void pdbATOM_to_CHROMOSOME(pdbATOM *pdb, CHROMOSOME *chr, RESPARAM *resparam)
{
  int pdb_index, respdb_index, bkbn_index;
  pdbATOM *residuepdb;
  int i,q;
  BACKBONE *bkbn;
  VARIABLE_POSITION *varpos;

  residuepdb = (pdbATOM *)calloc(MAX_RES_SIZE, sizeof(pdbATOM));
  bkbn = (BACKBONE *)calloc(MAX_RESIDUES, sizeof(BACKBONE));
  
  extract_bkbn(pdb, bkbn);
  
  chr->bkbngenes = (bkbnMENDEL *)malloc(sizeof(bkbnMENDEL));
  chr->first_bkbngene = chr->bkbngenes;
  chr->bkbngenes->nextbkbngene = NULL;
  i=1; 
  while(bkbn[i].seq_position!=ENDFLAG)
  {	
      chr->bkbngenes->seq_position = bkbn[i].seq_position;
      chr->bkbngenes->phi = bkbn[i].phi;
      chr->bkbngenes->psi = bkbn[i].psi;
      chr->bkbngenes->omega = bkbn[i].omega;

      chr->bkbngenes->nextbkbngene = (bkbnMENDEL *)malloc(sizeof(bkbnMENDEL));
      chr->bkbngenes = chr->bkbngenes->nextbkbngene;
      chr->bkbngenes->nextbkbngene = NULL; chr->bkbngenes->seq_position = ENDFLAG;
      ++i;
  }
  chr->bkbngenes =  chr->first_bkbngene;
  
  chr->genes = (MENDEL *)malloc(sizeof(MENDEL));
  chr->genes->nextgene =NULL;
  chr->firstgene = chr->genes;

  chr->genes = chr->firstgene;
  pdb_index = 1; bkbn_index = 1; q=0;
  while(bkbn[bkbn_index].seq_position!=ENDFLAG)
    {
	++q;

      chr->genes->seq_position = bkbn[bkbn_index].seq_position;

      chr->genes->choice_ptr = (CHOICE *)malloc(sizeof(CHOICE));
      chr->genes->choice_ptr->bkbn = (BACKBONE *)malloc(sizeof(BACKBONE));
      *chr->genes->choice_ptr->bkbn = bkbn[bkbn_index];

	/* set some un-needed values to 0 or NULL */
	chr->genes->lookupRot_index=0;
	chr->genes->j_choice_index=0;
	chr->genes->lookupRot=NULL;
	chr->genes->choice_ptr->lookup_res_ptr=NULL;
	chr->genes->choice_ptr->in_use_flag=1;
	chr->genes->choice_ptr->composition=1;
      	
	chr->genes->varpos_ptr=(VARIABLE_POSITION *)malloc(sizeof(VARIABLE_POSITION));
	chr->genes->varpos_ptr->seq_position = chr->genes->seq_position;
	chr->genes->varpos_ptr->lookup_energy_ptr = NULL;
	chr->genes->varpos_ptr->resimer = NULL;
	chr->genes->varpos_ptr->bkbn = bkbn[bkbn_index];
	chr->genes->varpos_ptr->fixed_flag = 1; 
	chr->genes->varpos_ptr->varpos_index = q; 
	chr->genes->varpos_ptr->number_of_choices = 1; 
	chr->genes->varpos_ptr->number_of_resimers = 1; 
	chr->genes->varpos_ptr->residue_freqs[0] = 0;
	chr->genes->varpos_ptr->residue_freqs[1] = 1.0;
	chr->genes->varpos_ptr->residue_freqs[2] = ENDFLAG;
	chr->genes->varpos_ptr->choice[1] = *chr->genes->choice_ptr;
	chr->genes->varpos_ptr->seqpos_text_map_ptr =  (SEQPOS_TEXT_MAPPING_LIST *)malloc(sizeof(SEQPOS_TEXT_MAPPING_LIST));	
	chr->genes->varpos_ptr->seqpos_text_map_ptr->seq_position = chr->genes->seq_position;
	strcpy(chr->genes->varpos_ptr->seqpos_text_map_ptr->seqpos_text, pdb[pdb_index].seqpos_text);

      /* copy the pdb elements for this residue to residuepdb */
      respdb_index = 1;
      while(chr->genes->seq_position == pdb[pdb_index].seq_position && pdb[pdb_index].seq_position!= ENDFLAG)  
	{
	  residuepdb[respdb_index] = pdb[pdb_index];
	  if(residuepdb[respdb_index].atom_ptr->atomnumber == 8)
	    {
	     chr->genes->choice_ptr->resparam_ptr = (RESPARAM *)malloc(sizeof(RESPARAM));
	     *chr->genes->choice_ptr->resparam_ptr = resparam[search_residuetype_RESPARAM(residuepdb[respdb_index].residuetype, resparam)];
	    }  
	  ++respdb_index; ++pdb_index;
	}
      strcpy(residuepdb[respdb_index].residuetype,"END");
      residuepdb[respdb_index].sasa = ENDFLAG;
      residuepdb[respdb_index].seq_position = ENDFLAG;
      residuepdb[respdb_index].atom_ptr = NULL;
      
      chr->genes->chi = (double *)calloc(chr->genes->choice_ptr->resparam_ptr->rotamerlib_ptr->numChi+2, sizeof(double));	

      extract_dihedrals(residuepdb, chr->genes->chi, chr->genes->choice_ptr->resparam_ptr);
            

      chr->genes->nextgene = (MENDEL *)malloc(sizeof(MENDEL));
      chr->genes = chr->genes->nextgene;
      chr->genes->seq_position = ENDFLAG;
      chr->genes->nextgene =  NULL;
      ++bkbn_index;
    }
  chr->genes = chr->firstgene;

  varpos = (VARIABLE_POSITION *)calloc(MAX_RESIDUES,sizeof(VARIABLE_POSITION));  
  i=1;
  chr->genes = chr->firstgene;
  while(chr->genes->seq_position!=ENDFLAG)
  {
	if(strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"GLY")!=0 && 
		strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"PRO")!=0 && 
		strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"CYD")!=0)
		{
			varpos[i].seq_position  = chr->genes->seq_position;
			varpos[i].bkbn = chr->genes->varpos_ptr->bkbn;
			varpos[i].choice[1] = *chr->genes->choice_ptr;
			++i;
		}
	chr->genes = chr->genes->nextgene;
  }
  varpos[i].seq_position = ENDFLAG;
  define_coresurfint(pdb, varpos);
  i=1;
  chr->genes = chr->firstgene;
  while(chr->genes->seq_position!=ENDFLAG)
  {
	if(strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"GLY")!=0 && 
		strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"PRO")!=0 && 
		strcmp(chr->genes->choice_ptr->resparam_ptr->residuetype,"CYD")!=0)
		{
			chr->genes->varpos_ptr->core_flag = varpos[i].core_flag;
			++i;
		}
	chr->genes = chr->genes->nextgene;
  }
    

  free_memory(varpos);
  free_memory(bkbn);  
  free_memory(residuepdb);
}

/* generate mini_pdbATOM array pdb (allocated by calling function).
   If fixed_atoms == NULL, build the backbone using the bkbngenes linked list on the chromosome.
   If fixed_atoms !=NULL, use its coordinates for the backbone atoms.
   Sidechain atom coords generated from the dihedrals stored in the genes. 
*/
void CHROMOSOME_to_mini_pdbATOM(CHROMOSOME *chr, mini_pdbATOM *fixed_atoms, mini_pdbATOM *pdb, BACKBONE *chain_anchor_bkbn)
{
    static BACKBONE *bkbn=NULL;
    static SIDECHAIN *side=NULL;
    static int max_residues=0;
    int i, n, r, q, m, fixed_atm_ctr, chain_number;
    extern RESPARAM *N_TERM_RESPARAM, *C_TERM_RESPARAM;
    div_t chain_id;

    if(side==NULL)
    {
	bkbn = (BACKBONE *)calloc(MAX_RESIDUES, sizeof(BACKBONE));
	side = (SIDECHAIN *)calloc(MAX_RESIDUES, sizeof(SIDECHAIN));
	for(i=1;i<MAX_RESIDUES;++i)
		side[i].atom=(micro_pdbATOM *)calloc(MAX_RES_SIZE,sizeof(micro_pdbATOM));
	max_residues=MAX_RESIDUES;
    }
    if(max_residues<MAX_RESIDUES)	/* MAX_RESIDUES has gotten bigger; resize static arrays */
    {
	for(i=1;i<max_residues;++i)
		free_memory(side[i].atom);
	free_memory(side);
	free_memory(bkbn);

	bkbn = (BACKBONE *)calloc(MAX_RESIDUES, sizeof(BACKBONE));
	side = (SIDECHAIN *)calloc(MAX_RESIDUES, sizeof(SIDECHAIN));
	for(i=1;i<MAX_RESIDUES;++i)
		side[i].atom=(micro_pdbATOM *)calloc(MAX_RES_SIZE,sizeof(micro_pdbATOM));
	max_residues=MAX_RESIDUES;
    }    

    if(fixed_atoms == NULL)
    {
	chr->bkbngenes = chr->first_bkbngene;
	i=1;
	chain_number = 0;
	while(chr->bkbngenes->seq_position!=ENDFLAG)
	{
		chain_id = div(chr->bkbngenes->seq_position, 1000);
	    if(chain_number != chain_id.quot + 1)
	    {
		chain_number = chain_id.quot + 1;
		bkbn[i] = chain_anchor_bkbn[chain_number]; 
  	    }

	    bkbn[i].seq_position = chr->bkbngenes->seq_position;
	    bkbn[i].phi = chr->bkbngenes->phi;
	    bkbn[i].psi = chr->bkbngenes->psi;
	    bkbn[i].omega = chr->bkbngenes->omega;
	    chr->bkbngenes = chr->bkbngenes->nextbkbngene;
	    ++i;
	}
	bkbn[i].seq_position = ENDFLAG;	
	chr->bkbngenes = chr->first_bkbngene;	
	build_BACKBONE(bkbn);
	
	chr->genes = chr->firstgene;  
	i=1;
	while(chr->genes->seq_position!=ENDFLAG)
	{	
	    build_a_SideChain(&side[i], &bkbn[i],chr->genes->choice_ptr->resparam_ptr,&chr->genes->seq_position, chr->genes->chi); 
	    chr->genes = chr->genes->nextgene;
	    ++i;
	}	
    }
    else
    {
	chr->genes = chr->firstgene;  
	i=1;
	while(chr->genes->seq_position!=ENDFLAG)
	{	
	    build_a_SideChain(&side[i], chr->genes->choice_ptr->bkbn,chr->genes->choice_ptr->resparam_ptr,
									&chr->genes->seq_position,chr->genes->chi); 
	    chr->genes = chr->genes->nextgene;
	    ++i;
	}	
    }
    
    n=1; i=1;
    chr->genes = chr->firstgene;  
    fixed_atm_ctr=1;
    while(chr->genes->seq_position!=ENDFLAG)
    {
	if(fixed_atoms == NULL)
	{
	 r=4;
	 if(bkbn[i].H_NTE == NULL)
	  {
	    pdb[n].coord =  bkbn[i].N;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n; 
	    ++r;
	    pdb[n].coord =  bkbn[i].H;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	    pdb[n].coord =  bkbn[i].CA;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	    pdb[n].coord =  bkbn[i].HA;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	  }
	else
	  {
	    pdb[n].coord =  bkbn[i].N;
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n; 
	    ++r;
	    pdb[n].coord =  bkbn[i].H;
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	    pdb[n].coord =  bkbn[i].CA;
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	    pdb[n].coord =  bkbn[i].HA;
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0; 
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    r=9;
	    pdb[n].coord =  bkbn[i].H_NTE[1];
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++r;
	    pdb[n].coord =  bkbn[i].H_NTE[2];
	    pdb[n].atom_ptr = &N_TERM_RESPARAM->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	   }
	
	if(bkbn[i].O_CTE == NULL)
	  {
	    m = 9 + chr->genes->choice_ptr->resparam_ptr->numberofSideAtoms;
	    pdb[n].coord =  bkbn[i].C;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[m];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++m;
	    pdb[n].coord =  bkbn[i].O;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[m];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	  }
	else
	  {
	    m=9;
	    pdb[n].coord =  bkbn[i].C;
	    pdb[n].atom_ptr = &C_TERM_RESPARAM->atom[m];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++m;
	    pdb[n].coord =  bkbn[i].O;
	    pdb[n].atom_ptr = &C_TERM_RESPARAM->atom[m];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	    ++m;
	    pdb[n].coord =  *bkbn[i].O_CTE;
	    pdb[n].atom_ptr = &C_TERM_RESPARAM->atom[m];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n;
	  }
	  pdb[n].coord =  bkbn[i].CB;
	  pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[8];
	  pdb[n].seq_position = chr->genes->seq_position;
	  pdb[n].born_radius=0;
	  pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	  ++n;
	}
	else
	{
	    while(chr->genes->seq_position != fixed_atoms[fixed_atm_ctr].seq_position && fixed_atoms[fixed_atm_ctr].seq_position!=ENDFLAG)
	    {
		pdb[n] = fixed_atoms[fixed_atm_ctr];
		++n; ++fixed_atm_ctr;
	    }
	    
	    while(chr->genes->seq_position == fixed_atoms[fixed_atm_ctr].seq_position && fixed_atoms[fixed_atm_ctr].seq_position!=ENDFLAG)
	    {
		pdb[n] = fixed_atoms[fixed_atm_ctr];
		if(pdb[n].atom_ptr->atomnumber == 8)	/* CB needs correct pointer */
		    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[8];
		++n; ++fixed_atm_ctr;    
	    }		    
	}
	r=9;
	for(q=1;q<=chr->genes->choice_ptr->resparam_ptr->numberofSideAtoms;++q)
	{
	    pdb[n].coord = side[i].atom[r].coord;
	    pdb[n].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[r];
	    pdb[n].seq_position = chr->genes->seq_position;
	    pdb[n].born_radius=0;
	    pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
	    ++n; ++r;   
	}
	++i;
	chr->genes = chr->genes->nextgene;
    }
    chr->genes = chr->firstgene;  
    
    if(fixed_atoms!=NULL)
    {
	while(fixed_atoms[fixed_atm_ctr].seq_position!=ENDFLAG)
	    {
		pdb[n] = fixed_atoms[fixed_atm_ctr];
		pdb[n].born_radius=0;
		pdb[n].sasa = 0; pdb[n].hbond_satisfied = 0;
		++n; ++fixed_atm_ctr;
	    }
    }
    
    pdb[n].sasa = ENDFLAG;
    pdb[n].seq_position = ENDFLAG;
    pdb[n].atom_ptr = NULL;
    
    pdb[0].sasa = 0; pdb[n].hbond_satisfied = 0;
    pdb[0].seq_position = 0;
}    




/*   This function generates a pdbATOM array pdb (allocated by calling function) for a chromosome chr; 
	If fixed_atoms == NULL, build the backbone using the bkbngenes linked list on the chromosome.
   If fixed_atoms !=NULL, use its coordinates for the backbone atoms.
   Sidechain atom coords generated from the dihedrals stored in the genes. 
*/
void CHROMOSOME_to_pdbATOM(CHROMOSOME *chr, pdbATOM *fixed_atoms, pdbATOM *pdb, BACKBONE *chain_anchor_bkbn)
{
  pdbATOM *side_atoms;
  int i,j, r;
  SIDECHAIN side;
  mini_pdbATOM *mini_pdb, *mini_fixed_atoms;
  
  side.atom=(micro_pdbATOM *)calloc(MAX_RES_SIZE,sizeof(micro_pdbATOM));
  side_atoms=(pdbATOM *)calloc(MAX_RES_SIZE,sizeof(pdbATOM));

  /* make the ordered pdbATOM array */
  chr->genes = chr->firstgene;  
  
  if(fixed_atoms != NULL)
  {
  i=1; j=1;   
  while(chr->genes->seq_position!=ENDFLAG)
    {
	
        while(fixed_atoms[j].seq_position!=ENDFLAG && fixed_atoms[j].seq_position!=chr->genes->seq_position)    
	{
	  pdb[i] = fixed_atoms[j];  /* advance to this residue */
	  pdb[i].atom_number = i;
	  ++i; ++j;
	}
	while(fixed_atoms[j].seq_position!=ENDFLAG && fixed_atoms[j].seq_position == chr->genes->seq_position)   /* copy backbone atoms to pdb */
        {
	   pdb[i] = fixed_atoms[j];
	   pdb[i].atom_number = i;
	   if(strcmp(pdb[i].residuetype,chr->genes->choice_ptr->resparam_ptr->residuetype)!=0)   /* match residuetypes */
	      if(!(pdb[i].residuetype[1]=='T' && pdb[i].residuetype[2]=='E') /* strstr(pdb[i].residuetype,"TE")==0 */)		/* terminii backbone */
		strcpy(pdb[i].residuetype,chr->genes->choice_ptr->resparam_ptr->residuetype);

	   if(strcmp(pdb[i].atom_ptr->atomname, "CB")==0)
	   {
	      	pdb[i].atom_ptr = &chr->genes->choice_ptr->resparam_ptr->atom[8];
	    }	
	   ++i; ++j;
	}
	
	    build_a_SideChain(&side, chr->genes->choice_ptr->bkbn, chr->genes->choice_ptr->resparam_ptr, &(*chr).genes->seq_position, 
			       chr->genes->chi);
	    make_side_pdbATOM(side_atoms, &side);    /* make sidechain atoms */
    	
	    r=1;
	    while(side_atoms[r].seq_position!=ENDFLAG)
	    {
		pdb[i] = side_atoms[r];
		pdb[i].atom_number = i;
		strcpy(pdb[i].seqpos_text,chr->genes->varpos_ptr->seqpos_text_map_ptr->seqpos_text);
		++i; ++r;
	    }	  
	    
	chr->genes = chr->genes->nextgene; 
    }
    chr->genes = chr->firstgene;    
    
    while(fixed_atoms[j].seq_position!=ENDFLAG)    /* copy remainder of fixed atoms to pdb */
	{
	  pdb[i] = fixed_atoms[j];
	  pdb[i].atom_number = i;
	  ++i; ++j;
	}
    }
    else
    {
	mini_fixed_atoms = NULL;
	mini_pdb = (mini_pdbATOM *)calloc(MAX_ATOMS, sizeof(mini_pdbATOM));
	CHROMOSOME_to_mini_pdbATOM(chr, mini_fixed_atoms, mini_pdb, chain_anchor_bkbn);
    
	chr->genes = chr->firstgene;
	i=1; j=1;
	while(chr->genes->seq_position!=ENDFLAG)
	{
	    while(chr->genes->seq_position == mini_pdb[i].seq_position)
	    {
	    pdb[i].seq_position = mini_pdb[i].seq_position;
	    pdb[i].born_radius = mini_pdb[i].born_radius;
	    pdb[i].sasa = mini_pdb[i].sasa;
	    pdb[i].atom_ptr = mini_pdb[i].atom_ptr;
	    pdb[i].coord = mini_pdb[i].coord;
	    pdb[i].hbond_satisfied = mini_pdb[i].hbond_satisfied;
	    strcpy(pdb[i].seqpos_text,chr->genes->varpos_ptr->seqpos_text_map_ptr->seqpos_text);
	    
	    strcpy(pdb[i].atomname, pdb[i].atom_ptr->atomname);
	    strcpy(pdb[i].residuetype, chr->genes->choice_ptr->resparam_ptr->residuetype);
	    pdb[i].atom_number = i;
	    
	    ++i;
	    }
	    chr->genes = chr->genes->nextgene;
	}
	chr->genes = chr->firstgene;
	
	free_memory(mini_pdb);
    }	

    free_memory(side_atoms);

    free_memory(side.atom);

    strcpy(pdb[i].residuetype,"END");
    pdb[i].seq_position=ENDFLAG;
    pdb[i].atom_ptr = NULL;
    pdb[i].atom_number = ENDFLAG;
    pdb[i].sasa= ENDFLAG;
    	
}

