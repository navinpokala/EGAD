/* EGAD: structure_types.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains datatype and constant definitions.
   
*/

#ifndef structure_types_header_flag
#define structure_types_header_flag

/* some MAX constants */

#define MAX_PROT_RES_SIZE  24	/* max size for protein residues */		
#define MAX_CHAINS 40			/* max number of chains */
#define MAX_RES_CHOICES 40		/* max number of residue/ligand choices at a given position */

#define MAXRESTYPES 80			/* max number of residue/ligand types */
#define MAXATOMTYPES 80 		/* max number of atom types */
#define REAL_MAX_ATOMS 4000		/* max number of atoms that can be used for precalculating 
							CARTESIAN_VECTOR matrix for SASA calc */

#define MAX_TORSION_PARAMS 500	/* max number of angle-dependent torsion parameters */
#define MAX_NUM_METHYL	5		/* max number of rotatable methyl groups for local minimization of vdw energies */


/* some math constants */
#define PI M_PI 
#define LN10 M_LN10
#define PI_4 12.56637061
#define PI_2 6.283185307
#define PI_8 25.13274123
#define PI_over2  1.570796327
#define PI_over3  1.047197551
#define PI_3	9.424777961
#define PI_77_sqrt2 342.1019862
#define PI_1_5_power_1024 5701.967869
#define PI_under100 31.83098862
#define PI_over180 0.017453293
#define PI_under180 57.29578
#define PI_PLUS_LN10_PLUS_SQRT2_MINUS_E_1e5 414010.948
#define EPS 1.0e-6
#define EPS2 2.0e-6
#define TOL 1.0e-4
#define TINY 1.0e-10
#define TRUE			1	/* Useful Boolean definitions */
#define FALSE			0

#define ENDFLAG -10	/* used as an array ending value for many structures */
#define ENDFLAG2 -100

/* some physical and forcefield constants */
#define WATER_RADIUS 1.4   /* radius of water probe for SASA calculations */
#define COULOMB_CONST 332.0636  /*  (e^2)/(4*pi*epsilon0) in kcal/mol */
#define HALF_COULOMB_CONST 166.0318
#define DEBYE_CONST 35.741508   
#define R_univ 1.998e-3   /* universal gas constant */

#define ROTAMER_SPREAD_FACTOR 0.5
#define METHYL_H_SPREAD 5.0
#define NATURAL_ROTAMER_SPREAD 7.0

#define POL_ATTRACTION_CAP 0.3
#define COULOMBIC_ATTRACTION_CAP -0.3

#define MAX_DISULFIDE_BOND_LENGTH 2.5
#define MAX_DISULFIDE_BOND_LENGTH_SQRD 6.25
#define AVG_DISULFIDE_BOND_LENGTH 2.03

#define MAX_HBOND_LENGTH 2.5

#define SASA_SCALE_NUMBER	100		/* SASA scale variable */
#define SASA_MAXPOINTS	256		/* Max number of points on sphere */

#define R_initial 1.998	/* gas constant for simulated annealling optimization methods */


/* macro shortcuts for long paths */

#define CHRRES chr->genes->choice_ptr->resparam_ptr
#define CHRROT chr->genes->lookupRot

#define iRES i_gene->choice_ptr->resparam_ptr
#define iROT i_gene->lookupRot
#define jRES j_gene->choice_ptr->resparam_ptr
#define jROT j_gene->lookupRot


#define ERESROT lookupEnergy[i].lookupRes[i_res].lookupRot[i_res_rot]
#define ERESROTq lookupEnergy[i].lookupRes[i_res].lookupRot[q_res_rot]
#define ERESROTiq lookupEnergy[i].lookupRes[q_res].lookupRot[q_res_rot]
#define RESROT lookupRes[i_res].lookupRot[i_res_rot]
#define ERESROTj lookupEnergy[j].lookupRes[j_res].lookupRot[j_res_rot]
#define VRESROT varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot]
#define VRES varPos[i].choice[i_res].resparam_ptr
#define VRESROTj varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->rotamer[j_res_rot]

#define iRESROT i_gene->choice_ptr->lookup_res_ptr->lookupRot[i_res_rot]
#define CHRRESROTj chr->genes->choice_ptr->lookup_res_ptr->lookupRot[j_res_rot]
#define iRESROTJRESROT i_gene->choice_ptr->lookup_res_ptr->lookupRot[i_res_rot].lookupX[j-i].lookupResX[j_res].lookupRotX[j_res_rot]
#define iRESi_resRESj_res i_gene->choice_ptr->lookup_res_ptr->lookupResResSeq[j-i].lookupResRes[j_res]


typedef struct
{
    double r2;	    /* correllation coefficient squared */
    double rmsd;    /* root mean squared deviation */
    double rse;    /* root squared error */			
} STATISTICS;

typedef struct
{
    double E_vdw;
    double E_coulomb;
    double E_1_4;
    double E_born;
    double E_pol; 
    double E_sasa;
    double E_hbond;
    double E_structure; /* sum of atomic energies */
    double E_folded;	/* scaled E_structure */
    double E_unfolded;  /* scaled E_rss - TdS */
    double TdS;
    double E_rss;
    double E_reference;	/* E_specificity + E_solubility + E_unfolded - TdS */
    double E_specificity;
    double E_solubility;
    double E_total;	/* E_structure - E_reference */
    double pseudo_dG;	/* E_folded - E_unfolded; used for evaluation of final structures */
    int clashes;
    int num_hbond;
    int num_ss_hbond; /* number of side-side hbonds */
    int num_sb_hbond; /* number of side-bkbn hbonds */
    int num_bb_hbond; /* number of bkbn-bkbn hbonds */
    int num_unsatisfied_hbond;
    int num_side_unsatisfied_hbond;	
    int num_bkbn_unsatisfied_hbond;	
    double dG_gap;
} ENERGY;

typedef struct
{
	double attractive;		/* sum of attractive vdw energies */
	double repulsive;	/* sum of replusive vdw energies */
	double linear;	/* sum of repulsive inter-atomic vdw energies in the linear region */
	int clashes;    /* number of clashes */
} VDW_ENERGY;

typedef struct
{
    double E_vdw;
    double E_coulomb; 
    double E_1_4;
    double E_born;
    double E_pol; 
    double E_sasa;
    double E_hbond;
} var_fix_ENERGY;	/* energy between sidechain and backbone; used in lookuptable generation */

typedef struct
{
   double E_vdw;
} var_fix_vdw_ENERGY;	/* vdw energy between sidechain and backbone */

typedef struct
{
    double E_vdw;
    double E_coulomb;
    double E_pol;
    double E_hbond;
} var_var_ENERGY; /* energy between sidechain pairs; used in lookuptable generation */


typedef struct    /*define cartesian coordinates*/
{
  double x;	/* x-coordinate */
  double y;	/* y-coordinate */ 
  double z;	/* z-coordinate */
} CARTESIAN;

struct CARTESIAN_VECTOR  /* define CARTESIAN_VECTOR; used for SASA calculations */
{
    int i;  /* atom indicies */
    int j;
    float r;	/* inter-atom distances */
    float r2;
    float i_theta; /* inter-atom angles */
    float i_phi;
    float j_theta;
    float j_phi;   
    CARTESIAN_VECTOR *next;
};

typedef CARTESIAN_VECTOR *CARTESIAN_VECTOR_PTR; /* define CARTESIAN_VECTOR_PTR; used for SASA calculations */

typedef struct    /* define BACKBONE */
{
  int seq_position;     /* sequence position */
  CARTESIAN N;          /* coordinates of the backbone N */
  CARTESIAN CA;         /* coordinates of CA */
  CARTESIAN C;          /* coordinates of backbone carbonyl carbon */
  CARTESIAN O;          /* coordinates of backbone carbonyl oxygen */
  CARTESIAN CB;         /* coordinates of beta-carbon */
  CARTESIAN H;          /* coordinates of amide-proton */
  CARTESIAN HA;         /* coordinates of alpha-proton */
  CARTESIAN *H_NTE;	/* coordinates of amide-protons for charged N-terminus */
  CARTESIAN *O_CTE;	/* coordinates of backbone carbonyl oxygen for charged C-terminus */
  double phi;           /* phi dihedral angle */
  double psi;           /* psi dihedral angle */
  double omega;         /* omega dihedral angle */
} BACKBONE;
/* flag for the end of a BACKBONE array is seq_position=ENDFLAG */

/* linked list for angle-dependent torsional energies */
struct protoTORSION
{
    char atom[5][4];
    int torsion_class[5];
    double magnitude[4];  /* we'll have at most 3 terms in the fourier series */
    struct protoTORSION *next;
};

typedef struct protoTORSION TORSION;	


typedef struct   /* define ATOMPARAM: atomic forcefield parameters */
{
  int atom_class;            /* class of this atom  */
  char atomtype[5];     /* forcefield atom type */ 
  char torsiontype[4];	/* atomtype for torsional energies */
  int torsion_class;
  double sigma;        /* van der waals diameter from OPLS */
  double welldepth;     /* van der waals well depth */
  double asp;           /* atomic solvation parameter for calculating transfer free energies */
  double united_radius; /* united atom vdw radius  */
  double sasa_radius;   /*  united_radius + WATER_RADIUS */
  double sasa_radius2;  /* sasa_radius^2 */
  double sasa_sphere;  /* surface area of a sphere of radius sasa_radius */
  double sa_sphere;	/* surface area of a sphere of radius united_radius */
  double volume;    /* volume of a sphere of radius=united_radius */
  double sasa_diameter;	/* 2*sasa_radius */
  TORSION *first_torsion;   /* pointers to TORSION linked list for this atomtype */
  TORSION *torsion;
} ATOMPARAM;


typedef struct   /* define ATOMRESPARAM: parameters for an atom in a residue */
{
  int atomnumber;        /* atom number */
  char atomname[5];      /* name of atom; ie: CA, C, CG, NH, OH, etc  */
  char atomtype[4];      /* forcefield atom type */
  int charge_class;		/* index used for CHARGE_PRODUCT table lookup */
  int other_info;        /* members of the same aromatic system are equal */
			 /* backbone atoms are negative */
  int contactAtomNumber; /* number of atom directly bonded */
  int twobondAtomNumber; /* number of atom two bonds away */ 
  int dihedAtomNumber;   /* number of atom three bonds away */
  int ringContactAtom;   /* ring closure bond partner; 0=ignore */
  int ringTwoBondAtom;   /* atom two bonds away due to ring closure; 0=ignore */
  int ringDihedAtom;	/* atom that forms a dihedral with this one via a ring */
  double bondlength;     /* bondlength to previous atom */
  double bondangle;      /* atom-contactAtom-twobondAtom bondangle */
  double dihedral;       /* atom-dihedAtom dihedral angle */
  double charge;	 /* charge  */
  double charge2;	 /* charge squared */
  double born_bonded;	/* sum of desolvation factors for atoms bonded <=1,3 */
  double volume_bonded;    /* volume minus bonded atom overlap volume */
  double BORN_P4_volume; /* volume_bonded*BORN_P4 */
  double volume_over_8_PI; /* volume_bonded/8PI */
  char donorflag[5];	/* describes hbonding properties if this atom; H=donatable hydrogen; A = acceptor
					Dn = donor, n=#of donatable hydrogens; Bn = both donor and acceptor (n=#of donatable hydrogens) */
  int methyl_flag; /* 0 unless is a methyl hydrogen; if methyl hydrogen, this value equal to contactAtomNumber */
  ATOMPARAM *atom_ptr;   /* pointer to atomic forcefield parameter */
  double E_hbond_specificity;
} ATOMRESPARAM;
/* flag for end of ATOMRESPARAM is atomnumber=ENDFLAG */

typedef struct /* define micro_pdbATOM  */
{
  ATOMRESPARAM *atom_ptr;     /* pointer to ATOMRESPARAM */
  CARTESIAN coord;      /* the cartesian coordinates of the atom */
} micro_pdbATOM;
/* ended by atom_ptr=NULL; used for SIDECHAIN side.atom arrays */

typedef struct /* define milli_pdbATOM  */
{
  CARTESIAN coord;      /* the cartesian coordinates of the atom */
  double born_radius;
} milli_pdbATOM;
/* used for storing sidechain atom coords in the lookup table */

typedef struct   /*define pdbATOM */
{
  char atomname[5];	/* type of atom; ie: CA, C, CG, NE, HD1, etc */
  char residuetype[5];	/* residue type in the standard 3 letter code */
  int atom_number;	/* the pdb line number of the atom */
  int seq_position;	/* the residue number, starting at the N-terminus */
  CARTESIAN coord;	/* the cartesian coordinates of the atom */
  double sasa;		/* the solvent-accessible-surface-area of the atom */
  ATOMRESPARAM *atom_ptr;   /* a pointer to the ATOMRESPARAM parameter */
  double born_radius;   /* Born radius for this atom */
  char seqpos_text[8];	/* sequence position text */
  char chain_id;	/* chain ID character */	
  bool hbond_satisfied; 
} pdbATOM;
/* flag for the end of a pdbATOM array is residuetype="END" and atom_ptr=NULL and seq_position=ENDFLAG */

/* used for mapping internal seq_positions with text from the pdb file */
typedef struct
{
  int seq_position;
  char seqpos_text[10];
} SEQPOS_TEXT_MAPPING_LIST;
/* end array with element seq_postion=ENDFLAG */

typedef struct
{
    CARTESIAN coord;	      /* the cartesian coordinates of the atom */
    ATOMRESPARAM *atom_ptr;   /* a pointer to the ATOMRESPARAM parameter */
    int seq_position;      
    double sasa;	      /* the solvent-accessible-surface-area of the atom */   
    double born_radius;       /* Born radius for this atom */
    int box;	/* box for sasa calculations */
    bool hbond_satisfied;
} mini_pdbATOM;  
/* stripped-down pdbATOM used for most things; array ends with sasa=ENDFLAG, seq_position=ENDFLAG, and atom_ptr=NULL */

/* used for born cross-polarization calculations */
struct protoCOULOMBIC
{
    short int index_i;   /* indexes for atoms involved in an interaction */
    short int index_j;
    short int flag;	/* connectivity between i and j */
    double r2; /* (r_ij)^2 */
    struct protoCOULOMBIC *next;
};   
typedef struct protoCOULOMBIC COULOMBIC;
/* end linked list coulombic with coulombic->next=NULL */

typedef struct   /* sum of the surface areas for the given atom types */
{
    double sp3_S;
    double sp2;
    double O;
    double N;
    double H;
    double sasa_total;
    double E_transfer;	/* water-octanol transfer free energy for solubilty purposes */
}   SASA_SUM;  

typedef struct   /* define ROTAMER: a rotamer */
{
  double freq;          /* frequency of this rotamer in the database */
  char *seqpos_text;	/* if not NULL (default), then this rotamer is specific for this position */ 
  pdbATOM *ligand_coords;  /* if you want to represent the ligand directly as coords */
  int index;	/* index of this rotamer in the sorted rotamer library, before Template-dependent filtering */
  int rank;		/* frequency rank of this rotamer */
  int native_rotamer_flag;  /* 1 if this rotamer is derived from the Template structure */
  double *chi;  /* an array of dihedral angles; chi[1]=chi1, chi[2]=chi2, etc */
		/* for ligands, if coordinates are given, chi[1] = index of this rotamer
						if transform matrix is given, chi[1]->chi[12] = transform matrix
							(see ligand_stuff.cpp for definition)
						chi[13]->chi[numChi] = dihedral angles for flexible ligand */
  int chi1_class;       /* chi1_class=1 -> X1=60;  chi1_class=2 -> X2=180; chi1_class=3 -> X3=-60; */
  double chi1_freq;     /* frequency of this rotamer in this chi1 class */
  double *std_dev; /* std deviations for each angle in chi */
  double *half_std_dev; 
  double **rotamerlet;	/* array of rotamers spread +/- ROTAMER_SPREAD_FACTOR*sigma for chi1 and chi2; 
					used for local minimization of vdw energies */
  ENERGY energy;
  double *born_factor;  /* sum of born factors intrinsic for each charged atom in a rotamer */
			/* includes intra-rotamer factors */
  COULOMBIC *first_coulombic; 			
  COULOMBIC *coulombic;   /* list of intra-rotamer pairwise electrostatic interactions */			
} ROTAMER;


typedef struct   /* define ROTAMERLIB: rotamer library */
{
  char residuetype[4];            /* residue-type in standard 3 letter code */
  int residuecode;	
  int number_of_rotamers; 
  pdbATOM *ligand_base_coords;	/* base coords for ligand matrix transformation from the ligand definition file */
						/* if included in the Template file, the template coords supercede the coords in the */
						/* ligand definition file */
  int num_rotamerlets;      
  double *freq_array; /* array of rotamer frequencies */	
  ROTAMER *rotamer;  /* an array of rotamers and their freqs */
  int numChi;	/* number of chi; for sidechains, should equal resparam.num_rotatable_bonds;
			for ligands, if coordinates are given, numChi=1 (chi[1] = rotamer index);
						 if transform matrix is given, numChi = 12 (matrix) + num_rotatable_bonds
		*/
  bool generate_ligamers_flag;
} ROTAMERLIB;
/* flag for end of rotamer library is residuetype="zzz" */  

typedef struct   /* define RESPARAM: residue forcefield parameters */
{
  char residuetype[4];  /* residue type in the standard 3 letter code */
  char one_letter_code[4];
  int residuecode;
  int ligand_flag;	/* 1 if ligand, 0 otherwise */
  int protonation_flag;	/* this is the protonated form; for pH-dependence of ionizable groups */
  ROTAMERLIB *rotamerlib_ptr;  /* pointer to ROTAMERLIB */
  int numberofAtoms;    /* number of atoms in the residue  */
  int numberofSideAtoms; /* number of sidechain atoms, not including CB */
  int num_charge_H;     /* number of charged hydrogens */
  int num_non_H;        /* number of non-hydrogen atoms in the sidechain */
  int num_charged;      /* number of charged atoms in the sidechain  */
  int charged_CB_flag;  /* 1 if CB is charged; else 0 */
  int num_hbonding_sidechain_atoms;
  int numhbondsideatoms_minus1;
  int charged_flag;  /* 1 if any charged atoms */
  int num_rotatable_bonds;   /* number of rotatable bonds */  
  int num_methyl_groups; /* number of methyl groups */
  int num_methyl_confs; /* number of methyl conformations */
  double E_unfolded;	/* unfolded energy; evaluation energy ref-state energy  */
  double E_reference; 	/* tripeptide + random - TdS; design ref state w/o specificity energy */
  double E_tripeptide; /* energy in AXA tripeptide ensemble */
  double E_random; /* avg energy in random seq-conf */
  double E_specificity;	/* avg energy in natural proteins */
  double E_specificity_core; /* avg energy in core positions */
  double E_specificity_interfacial; /* avg energy in interfacial positions */
  double E_specificity_surface; /* avg energy in surface positions */
  double S; /* sidechain entropy tripeptide */
  double pKa;  /* pKa for ionizable sidechains */
  double overall_charge;
  double max_vdw;	/* max bkbn-rotamer vdw energy; rotamers with higher energies are rejected automatically */
  double max_solvation; /* max solvation energy for a rotamer; rotamers with higher energies are rejected automatically */
  ATOMRESPARAM *atom; /* list of atoms in the residue type */
  ATOMRESPARAM *sorted_atom; /* list of atoms sorted alphabetically */
  double overall_charge_pH_avg;
  ATOMRESPARAM **atom_ptr;  /* array of pointers to atom; used to save memory for lookuptable */
  ATOMRESPARAM **sidechain_hbond_atom_ptr;  /* array of pointers to atom; used to save memory for lookuptable */
  ATOMRESPARAM **non_MeH_atom_ptr; /* array of pointers to sidechain hbonding atoms; used to save memory for lookuptable */
  ATOMRESPARAM ***MeH_atom_ptr;  /* array of pointers to atom; methyl hydrogens; used to save memory for lookuptable */
  ATOMRESPARAM centroid;
} RESPARAM;
/* array ends with residuetype "zzz" */

typedef struct   /* define SIDECHAIN */
{
  int seq_position;
  RESPARAM *resparam_ptr;
  micro_pdbATOM *atom;
} SIDECHAIN;
/* flag for the end of a SIDECHAIN array is seq_position=ENDFLAG */

typedef struct 
{
   short int j_index;
   bool *i_hbond_status;	/* array (start at 0) is num_hbonding_sidechain_atoms long; value 1 if hbonding atom q+1 forms */
   bool *j_hbond_status;	/* hbond with the other sidechain */
} HBOND_ROTAMER_PAIR;	

typedef struct
{
  short int num_hbond_rot_pairs;
  HBOND_ROTAMER_PAIR *hbond_rot_pair;
  
} LOOKUP_ROTAMER_X_HBOND;

/* Energy look-up table structures */
/* energy for rotamer p for residuetype m at position i  */
/* interaction energy w/ rotamer q for residuetype n at position j */

typedef struct
{ 
  float energy_var_var;
} LOOKUP_ENERGY_ROTAMER_X;

typedef struct
{
  LOOKUP_ENERGY_ROTAMER_X *lookupRotX;
  LOOKUP_ROTAMER_X_HBOND *lookupRotX_hbond;  /* not NULL only if the pair form a hydrogen bond */
} LOOKUP_ENERGY_RESIDUE_X;

typedef struct
{
  LOOKUP_ENERGY_RESIDUE_X *lookupResX;
} LOOKUP_ENERGY_X;

typedef struct
{
  CARTESIAN **coord; 
} METHYL_H;

typedef struct
{
  CARTESIAN *non_MeH;	/* non-MeH atoms for this rotamerlet */
  METHYL_H *MeH; /* arrays of methyl hydrogens for this rotamerlet;  */
} METHYL;

typedef struct
{
   CARTESIAN *coord; /* coords for this rotamerlet */
   METHYL *methyl_group; /* NULL unless there are methyl groups */
} ROTAMERLET;

typedef struct
{
  ROTAMER *rotamer;    /* pointer to the rotamer */         
  float energy_var_fix;  /* energy between rotamer p for residue m at position i and the non-variable atoms */
  float sasa_hphob;
  LOOKUP_ENERGY_X *lookupX;        
  milli_pdbATOM *sideAtoms; /* coordinates, born radii of sidechain atoms including CB */
  float E_reference; /* environment-dependent reference state energy for this rotamer  E_ref + E_specificity */
  ROTAMERLET *rotamerlet;
  double *P; /* probabilities for SCMF optimization */
  bool in_use_flag; /* 1 if in use; 0 if not in use or eliminated */
  short int resimer_index; /* if not ENDFLAG, is the resimer index; used for calling elimination table status */
	/* the following are not NULL only if this rotamer forms an hbond w/ the backbone */
  bool *sidechain_hbond_status; /* starting w/ 1, an element for each sidechain hbonding group */
  short int num_var_fix_hbond;
  short int *bkbn_hbond_indicies; /* starting w/ 0, the index of FIXED_HBOND_SATISF_ARRAY this rotamer hbonds or exposes */
} LOOKUP_ENERGY_ROTAMER; 

typedef struct
{
  int *resres_interact_flag; 
} LOOKUP_ENERGY_RESIDUE_RESIDUE;
/* if lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 1, then 
	then the residue i_res at position i has at least one rotamer that interacts with at least one
	rotamer for residue j_res at postion j;
   this data structure exists only transiently within generate_lookup_table */
  
typedef struct
{
  int residuecode;
  int sizeof_lookupRot;
  char core_flag; /* c if core; i if interfacial; s if surface */
  LOOKUP_ENERGY_ROTAMER *lookupRot;   /* available rotamers for m */
  LOOKUP_ENERGY_RESIDUE_RESIDUE *lookupResRes;
  double E_mf; /* mean-field energy */ 
  double P; /* probabilities for SCMF optimization */
  double TdS; /* entropy for SCMF optimization */
  int fixed_flag;  /* 0 = floating; 1 = user-defined fixed; 2 = only one rotamer choice available */
  float E_transfer;	/* water-octanol transfer free energy for solubility purposes */
  float sasa_hphob;
  float sasa_total;
} LOOKUP_ENERGY_RESIDUE;


typedef struct    
{
  int seq_position;    /* sequence position i */
  int sizeof_lookupRes;
  LOOKUP_ENERGY_RESIDUE *lookupRes;
} LOOKUP_ENERGY;

/* Defining variable parameters */

typedef struct
{
  BACKBONE *bkbn;	/* pointer to BACKBONE for this choice's VARIABLE_POSITION */
  RESPARAM *resparam_ptr;     /* pointer to RESPARAM (and to the local backbone-filtered rotamerlib) */  
  LOOKUP_ENERGY_RESIDUE *lookup_res_ptr; /* pointer to LOOKUP_ENERGY_RESIDUE */
  double composition;         /* desired composition of this residue at this position */
  bool in_use_flag;		/* 1 if in use during this optimization method run, 0 if not; default to 1;
					this value is reset by  rotamer_calc_foreman.cpp: share_lookup_table */
} CHOICE;

typedef struct	/* stores i_res and i_res_rot indexes for resimers */
{
  int i_res;
  int i_res_rot;  
} RESIMER;


typedef struct
{
  int seq_position;                 /* position of variable residue */
  int fixed_flag;		    /* this position relaxes the natural rotamer */
  char core_flag;	/* c = core; i = interfacial; s = surface */
  int neighbor_level;	/* ENDFLAG = user_defined; 1 = first level, 0 = second level */
  double mea_sasa;	/* sasa of the MEA CG pseudoatom */
  double mea_born;	/* born radius of the MEA CG pseudoatom */
  BACKBONE bkbn;       /* BACKBONE for this position */	
  int number_of_choices;
  int number_of_resimers;
  bool dead_ended_flag;	/* if 1, this position has only one remaining rotamer */
  int varpos_index; /* index of this position in the array */	
  int dee_index;  /* index in dee table */
  RESIMER *resimer; 
  LOOKUP_ENERGY *lookup_energy_ptr; /* pointer to LOOKUP_ENERGY for this position */
  double residue_freqs[MAX_RES_CHOICES]; /* array of residue frequencies */
  CHOICE choice[MAX_RES_CHOICES];    /* permitted choices for this position */	
  SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map_ptr; /* pointer to SEQPOS_TEXT_MAPPING_LIST for this position */
} VARIABLE_POSITION;    
/* position = ENDFLAG is the flag for array termination */

/* Defining genes and chromosomes  */

struct protoGENE
{
  int seq_position;       /* sequence position */
  double *chi;    /* array of chi angles */
  CHOICE *choice_ptr;    /* pointer to the residue choice */
  int lookupRot_index;    /* index for the LOOKUP_ENERGY_ROTAMER and LOOKUP_ENERGY_ROTAMER_X arrays for this sidechain */
  int j_choice_index;	/* i_res - 1; index for lookuptable lookups where this position is "j" */
  VARIABLE_POSITION *varpos_ptr;
  LOOKUP_ENERGY_ROTAMER *lookupRot;  /* pointer to the lookup table; for total precalc only */
  struct protoGENE *nextgene;  /* ptr to next gene in the list */
};
/* seq_position = ENDFLAG is the flag for list termination */

typedef struct protoGENE MENDEL;         /* datatype of the gene linked-list */
typedef MENDEL *GENE;                    /* datatype of pointers to the gene list */

struct protobkbnGENE
{
  int seq_position;    /* sequence position */
  double phi;         
  double psi;          /* backbone dihedrals */ 
  double omega;
  struct protobkbnGENE *nextbkbngene;  /* pointer to next bkbngene in the list */
};
/* seq_position = ENDFLAG is the flag for list termination */

typedef struct protobkbnGENE bkbnMENDEL;     /* datatype of the bkbngene linked-list */
typedef bkbnMENDEL *bkbnGENE;                /* datatype of pointers to the bkbngene list */

struct CHROMOSOME   /* a chromosome */
{
  ENERGY energy_list;	    
  double energy;	     /* total energy */

  double pop_energy;	     /* energy - (energy of best in the population) */
  double boltzProbab;        /* mating probability based on boltzmann stats */
  double deltaRank;	     	 /* rank - pop_size; use for calculating rankProbab */
  double rankProbab;	     /* mating probability based on rank */

  GENE genes;                /* ptr to gene linked-list */
  GENE firstgene;            /* ptr to firstgene of gene linked-list */

  bkbnGENE bkbngenes;        /* ptr to bkbngene linked-list  */
  bkbnGENE first_bkbngene;   /* ptr to firstgene of bkbngene linked-list */ 
}; 

typedef struct   
{
  char *output_prefix;               /* output files prefix; name.log, name.out, name.pdb */
  char *output_prefix_sans_path;	 /* usually equal to output_prefix, unless output_prefix is a path */

	/* for VARIABLE_POSITIONS and lookup table generation */
  int numMovingPositions;	/* number of positions with more than 1 rotamer */
  int num_total_choices;	/* total number of choices; sum of varpos->number_of_choices for all positions */
  double neighbordist;     /* definition distance for neighboring residues */
  double fixedatoms_energy; 	/* internal energy of fixed atoms */
  char *algorithm;  /* the optimization method being used */
  char *sequence_algorithm; /* sequence optimization method for multistate */
  char *lookup_energy_table_directory;
  int disk_lookup_table_flag; /* 1= generate the whole pair table at once; 2 = build up lookup table as needed  */
  int avoid_wt_rotamer_flag; /* wt rotamer avoided if set to 1  */
  char *slave_file_list_filename; /* if not NULL, this job is a rotamer_calc_foreman; slave input files */
  double log10_seq_combinations;	/* defined in input_VARIABLE_POSITIONS */
  double log10_rotamer_combinations; /* defined in input_VARIABLE_POSITIONS and updated in generate_lookup_table */
  int numVarPositions;  /* number of variable positions */

	/* for GA */
  int pop_size;         /* size of actively mating population for ga */
  double recomb_freq;   /* recombination frequency for ga ... default to 0.5 */
  double mutation_freq; /* mutation frequency for ga */
  int ga_convergence;   /* convergence = # isoenergetic generations */
  int number_GA_cycles;      /* number of SuperGenerations; independent GA runs */
  int num_GA_solns_per_cycle;   /* number of solutions to be saved from each supergeneration */
  int finalGAseed_population;  /* numSuperGen*numberofSolutions */
  double ga_T0;	/* simulation temperature schedule for calculating mating freqs. */
  double ga_Tf;
  double ga_dT;

	/* for continuous minimization */
  int max_iterations;	
  int max_function_calls;
  int rebuild_backbone_flag;
  double max_bkbn_delta_dihedral;

	/* for SCMF */
  char scmf_seed[20]; /* random, weighted, uniform */
  int max_scmf_iterations;
  int number_scmf_cycles;
  double scmf_lambda;
  int scmf_quench_flag;
  int number_scmf_solns;
	
	/* for MC */
  int number_MC_cycles;
  int number_MC_solns;
  int MC_convergence;
  double mc_T0;	/* for simulated annealing cooling */
  double mc_Tf;
  double mc_dT;

	/* for DEE */
  int dee_max_nodes;
  double dee_E_bounding;
  double dee_E_bounding_ceiling;
  double ln_exhaustive_search_max_combo; /* max ln(number of combination) for exhaustive search */

	/* for HQM */
  int hqm_convergence; 

	/* for RIGID_DOCKING */
  int dock_local_flag;  // if 1, then permit only small, very local moves; otherwise, use GA with larger moves

} PARAMETERS;
/* user-specified program parameters; set up by input_stuff.cpp: input_stuff */

typedef struct
{
	int seq_position;	/* position of this invariable residue */
	char restype; /* one letter code for the residue */
} INVARIABLE_POSITIONS;
/* positions and residue types of invariable positions (ie: pro/gly); array ends with seq_position=ENDFLAG.
	generated by readpdbfile.cpp: readpdbfile  */

typedef struct
{
	char *chain_id;
} SUPER_CHAIN_ID_LIST;


struct protoALIGNMENT_DEFINITION
{
    	char *seqpos_text_initial;
	char *residuetype_initial;
	char *atomname_initial;
	char *seqpos_text_target;
	char *residuetype_target;
	char *atomname_target;
    	struct protoALIGNMENT_DEFINITION *next;	/* end linked list with next=NULL */
};   
typedef struct protoALIGNMENT_DEFINITION ALIGNMENT_DEFINITION;


/* constructed/allocated by input_stuff.cpp: input_stuff; the EGAD object */
struct PROTEIN  
{
  char *inputfilename; /* name of the inputfile for this file */

	/* forcefield/energy function structures */
  ATOMPARAM *atomparam;
  RESPARAM *resparam;
  ROTAMERLIB *rotamerlib;

	/* experimental parameters */
  double temperature;
  double pH;
  double ionic_strength;

  PARAMETERS parameters;	/* optimization method parameters (number of GA generations, max number of solns for exhaustive
						search, number of independent MC runs, etc)  */

	/* variables dealing with the inputed pdb file */	
  int num_res;
  int num_ligands;
  char *template_sequence;
  pdbATOM *Template;		/* pdbATOM of inputted Template pdb */
  char *Template_filename;
  mini_pdbATOM *mini_Template; /* mini_pdbATOM of inputted Template pdb */
  int chain_gap_flag; /* 1=there are missing residues in the Template pdb file */
  SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map;  /* maps seq position from pdb file to internal seq position */
  char *chain_id_list;	/* string consisting of chain id characters */
  SUPER_CHAIN_ID_LIST *super_chain_id_list; /* for unifying multiple chains; ie: disulfide linked, dimer of dimers, etc */
  char *wacky_numbering_list;	/* residues with non-standard numbering; for example serine protease pdb files */
  INVARIABLE_POSITIONS *invar_pos;	/* locations and identities of invariable (ie: pro/gly) positions; 
								generated by readpdbfile.cpp: readpdbfile */
  BACKBONE *bkbn;	/* BACKBONE array for Template; generated by readpdbfile.cpp: readpdbfile  */
  BACKBONE *chain_anchor_bkbn; /* BACKBONE array for the first residue of each chain; generated by readpdbfile.cpp: readpdbfile  */

    /* competitors for multi-state design */
  int num_competitors;
  char **competitor_Template; /* filenames for competitor structures */

	/* structures for aligning two structures */
  ALIGNMENT_DEFINITION *first_align_def;
  ALIGNMENT_DEFINITION *align_def;
  double align_rmsd;
  int num_align_points;

  	/*  structures for rotamer optimization */
  int numVarPositions;	/* number of variable positions */
  VARIABLE_POSITION *var_pos;	/* array of VARIABLE POSITIONS */
  pdbATOM *fixed_atoms;		/* pdbATOM of fixed atoms; generated by input_stuff.cpp: input_VARIABLE_POSITIONS */
  mini_pdbATOM *mini_fixed_atoms;  /* mini_pdbATOM of fixed atoms; generated by input_stuff.cpp: input_VARIABLE_POSITIONS */
  ENERGY fixedatoms_energy;	/* energy components for fixed atoms (bkbn, pro, gly); 
						generated by input_stuff.cpp: input_VARIABLE_POSITIONS */
  LOOKUP_ENERGY *lookupEnergy;	/* the lookup table */

  int sizeof_chr_array;
  CHROMOSOME *chr;	/* chr array used for transporting output from one optimization method to another */

	 /* structures for torsional continuous minimization */
  int *min_fixed_res;	/* these arrays hold lists of user-defined fixed or floating residues for minimization */
  int *min_float_res;	
  int *torsion_include_res;	/* score these positions for scoring rmsd for torsion adjustments */
  int *torsion_exclude_res; /* don't include these positions for rmsd for torsion adjustments */
  mini_pdbATOM *CBminus_minipdb; /* without CB atoms */

		/* final structures and energies; 
				generated by CHROMOSOME_to_lookupEnergy.cpp: final_chr_to_final_pdb_final_energy */
  CHROMOSOME final_chr;	/* the final soln chr; must be set before sending to final_chr_to_final_pdb_final_energy */
  pdbATOM *final_pdb;	/* final pdbATOM structure */
  mini_pdbATOM *final_minipdb;  /* final mini_pdbATOM structure  */
  ENERGY *final_energy;	/* energy components of the final structure (calculated with all atoms explicitly) */
  double pseudo_dG; /* fully scaled, softened, unfolded state subtracted energy */
  double E_working;	/* working energy used during the optimization; energy from lookup table for rotamer optimization */
  double E_scmf;	/* mean field energy from SCMF */
  SASA_SUM sasa_sum;	/* SASA components of final structure  */
  char *final_sequence; /* final aa sequence */

  double **energy_profile_table; /* generated by generate_energy_profile_table */  
  int calc_complex_residue_energy_flag;
  
  double *transform_matrix;
  double *translate_rotate_array; 
};

/* structure types for SASA calculations  */
typedef struct 	
{
	unsigned int mask[2*SASA_SCALE_NUMBER][8];	/* Boolean Masks */
	double x,y,z;			/* Coordinates of point */
} SASA_point;

typedef struct	
{
  mini_pdbATOM *pdb;   /* pointer to the mini_pdbATOM of interest */
  ATOMPARAM *atom_ptr;
  /* SASA masks */
  unsigned int 	mask1,mask2,mask3,mask4;
  unsigned int	mask5,mask6,mask7,mask8;
  int		box;		/* Non-bond box coordinate */
  int		number;		/* Array index for quicksort */
} SASA_ATOM;

extern int MAX_RESIDUES;
extern int MAX_ATOMS;
extern int MAX_RESIMERS;
extern int MAX_RES_SIZE;

/* macro for freeing memory; requires that the argument not be NULL	 */
#define free_memory(pointer)	\
{	\
											\
	if((pointer)!=NULL)	\
		free((pointer));	\
	else	\
	{	\
		fprintf(stderr,"ERROR...trying to free memory that's free\n");	\
		fprintf(stderr,"dumping core.....\n");	\
		abort(); 	\
	}	\
	(pointer)=NULL;	\
}

extern int DEBUG;
extern int QUIET_FLAG;
extern int MAXLINE; /* max string size */ 
extern int MXLINE_INPUT;

#endif
