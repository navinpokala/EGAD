/* EGAD: minimization.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for minimization.cpp

*/



#ifndef minimization_header_flag
#define minimization_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "dihedral_cartesian.h"
#include "pdbATOM_utilities.h"
#include "GENES_pdb.h"
#include "search_and_sort.h"
#include "energy_functions.h"
#include "pairwise_energy_calc.h"
#include "io.h"
#include "GA_utilities.h"
#include "powell.h"

/* Manages JOBTYPE MINIMIZE and JOBTYPE ADJUST_BACKBONE_TORSIONS
   For MINIMIZE, powell-minimize protein->Template in dihedral space 
	(backbone moves if protein->parameters.rebuild_backbone_flag==1). 
   For ADJUST_BACKBONE_TORSIONS, rebuild backbone w/ ideal geometry, adjust torsions to minimize rmsd with 
	original structure.	
   Assumes protein has been initialized with input_stuff.
   final structure stored in protein->final_pdb for output_PROTEIN 
*/
void torsion_minimize_PROTEIN(PROTEIN *protein);

/* given a base chr and delta_dihedral_array, generate chr_new (allocated by calling function).
	if  backbone_flag == 1, bkbnGENES are built.
	fixed_res!=NULL -> fix dihedrals for these seq positions. 
	float_res!=NULL -> float dihedrals only for these seq positions.
	delta_dihedral_array - all sidechain rotamer perturbations listed first, 
	then all backbone dihedral perturbations.
		ligands, pro, gly, cyd, ala sidechain dihedrals are defined as fixed,
		phi, psi, and omega are allowed to vary for backbone.
	chr_new can be used for CHROMOSOME_to_mini_pdbATOM 
*/
void convert_delta_dihedral_array_to_CHROMOSOME(CHROMOSOME *chr_new, double *delta_dihedral_array, CHROMOSOME *chr, int backbone_flag, int *fixed_res, int *float_res);

/*  returns value of minimization_objective_function.
    delta_dihedral_array - defined as described for convert_delta_dihedral_array_to_CHROMOSOME.
    builds the structure and evaluates the energy E.
    if backbone is allowed to move (protein->parameters.rebuild_backbone_flag==1), and if RESTRAIN_MINIMIZATION_FLAG=1,
	the objective function is: if(E>=0), Fobj = E*rmsd; else Fobj = E/rmsd; 
		(rmsd = current structure-starting structure bkbn rmsd for N, CA, C)
    if RESTRAIN_MINIMIZATION_FLAG=0, E is returned.
*/
double minimization_objective_function(double *delta_dihedral_array, POWELL *powell);

/*
	For bkbn, an array of CARTESIAN pointers is assigned such that
		cartesian[i] = &bkbn.X (X=N,H,CA,etc).
	if exclude_res!=NULL, the listed positions are not included.
	if include_res!=NULL, only those listed positions are included.
	called by bkbn_torsion_overlay_rmsd.
*/
void BACKBONE_to_CARTESIAN_array(BACKBONE *bkbn, CARTESIAN **cartesian, int *exclude_res, int *include_res);

/*
	for delta_dihedral_array, this function returns the rmsd (rmsd = current structure-starting structure bkbn rmsd).
	working_protein->torsion_exclude_res!=NULL --> listed positions not included in scoring.
	working_protein->torsion_include_res!=NULL --> only listed positions scored.
	delta_dihedral_array = array of backbone dihedral perturbations (phi,psi,omega) for all residues
*/
double bkbn_torsion_overlay_rmsd(double *delta_dihedral_array, POWELL *powell);

#endif
