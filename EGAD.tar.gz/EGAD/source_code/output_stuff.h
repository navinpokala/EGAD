/* EGAD: output_stuff.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for output_stuff.cpp.

*/


#ifndef output_stuff_header_flag
#define output_stuff_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "pdbATOM_utilities.h"
#include "energy_functions.h"
#include "search_and_sort.h"
#include "GENES_pdb.h"
#include "pairwise_energy_calc.h"
#include "io.h"
#include "lookup_table_disk_stuff.h"
#include "lookup_table.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "sequence_CHROMOSOME_stuff.h"
#include "energy_profile_table.h"

/* prints out x,y,z coords for CARTESIAN; for debugging */
#define printf_CARTESIAN(a) printf("%lf\t%lf\t%lf\n",(a).x,(a).y,(a).z)


/* prints to file_ptr stream the sum of probabilities of each residuetype in a VARIABLE_POSITION array that has been 
    subjected to mean-field optimization of residue probabilities. 
 */
void fprintf_composition_vector(FILE *file_ptr, PROTEIN *protein);

/* output an energy pair table for a given structure to a file.
	uses energies from the lookup table (JOBTYPE PAIR_ENERGY_TABLE).
	Use JOBTYPE ENERGY_PROFILE instead, since it uses actual Born radii, sasa, and is faster.
	This is still kept because this gives the correct energies when local minimization is used */
void output_lookup_table(PROTEIN *protein);

/* prints each energy component  */
void fprintf_energy(FILE *output_stream,ENERGY energy);

/* prints the sasa for each residue */
void fprintf_residuelevel_sasa(FILE *output_stream, pdbATOM *pdb);

/* prints each sasa component */
void fprintf_sasa(FILE *output_stream,SASA_SUM sasa_sum);

/* This function outputs all the energies, sequences, and rotamers encoded by the top num_solutions
   in the CHROMOSOME array to file name.out */
void output_data(CHROMOSOME *chr, int *num_solutions, const char *name, PROTEIN *protein);

/* prints coords in pdb to standard out; for debugging */
void printf_minipdb(mini_pdbATOM pdb[]);

/* This function prints a pdbATOM array to stdout in the pdb format; for debugging */
void fprintf_pdb(FILE *output_stream, pdbATOM pdb[]);

/* 
   This function inputs a CHROMOSOME and the fixed atoms
   It returns the vdw energy based on relaxing sidechains via rotamerlets and methyl-lets
   This requires that all the sidechain coords be pre-calculated by generate_lookup_table and linked appropriately
 */
double relaxed_vdw_energy(CHROMOSOME *chr, mini_pdbATOM *fixed_atoms, PARAMETERS *parameters);


/* 
   This function outputs all the calculated rotamers and the structure encoded by final_chr or final_pdb in a PROTEIN
   If final_energy == NULL, this function will also calculate the structs and energy encoded by final_chr 
*/
void output_PROTEIN(PROTEIN *protein, int output_coord_flag);

#endif
