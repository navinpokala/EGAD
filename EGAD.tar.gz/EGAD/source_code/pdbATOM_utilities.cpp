/* EGAD: pdbATOM_utilities.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for manipulating and modifying pdbATOM and mini_pdbATOM arrays
   
*/


#include "pdbATOM_utilities.h"


/* concatanates (cat) pdb1 and pdb2 into target */

void cat_mini_pdbATOM(mini_pdbATOM pdb1[], mini_pdbATOM pdb2[], mini_pdbATOM target[])
{
  int p1,p2,t;	

  target[0].seq_position=0;

  p1=1; p2=1; t=1;
  while(pdb1[p1].seq_position!=ENDFLAG)
    {
      target[t] = pdb1[p1];
      ++p1; ++t;
    }
  while(pdb2[p2].seq_position!=ENDFLAG)
    {
      target[t] = pdb2[p2];
      ++p2; ++t;
    }
  target[t].sasa = ENDFLAG;
  target[t].seq_position=ENDFLAG;
  target[t].atom_ptr = NULL;
}
  
/* concatanates (cat) pdb1 and pdb2 into target */

void cat_pdbATOM(pdbATOM pdb1[], pdbATOM pdb2[], pdbATOM target[])
{
  int p1,p2,t;	

  p1=1; p2=1; t=1;
  while(pdb1[p1].seq_position!=ENDFLAG)
    {
      target[t] = pdb1[p1];
      ++p1; ++t;
    }
  while(pdb2[p2].seq_position!=ENDFLAG)
    {
      target[t] = pdb2[p2];
      ++p2; ++t;
    }
  strcpy(target[t].residuetype,"END");
  target[t].sasa=ENDFLAG;
  target[t].seq_position=ENDFLAG;
  target[t].atom_number=ENDFLAG;
  target[t].atom_ptr = NULL;
}
  
/* 
   This function attached atom_ptrs to all the atoms in pdb = array of pdbATOM.
   resparam = main resparam array; 
*/
void attach_ptr_pdbATOM(pdbATOM *pdb, RESPARAM *resparam)
{
    int i, k, j,  q, flag, p;
    extern int NTE_FLAG, CTE_FLAG;
    RESPARAM *dummyresparam;
    pdbATOM *dummypdb;
    CARTESIAN ca, n, c_, c;
    double dihed;
    double len_HA_CA=1.090; 
    double len_CA_N=1.335;
    double angle_CA_N_C=111.10; 
    double angle_HA_CA_N=109.50; 
    double len_CB_CA = 1.525; 
    double angle_CB_CA_N = 111.10;
    
    dummypdb = (pdbATOM *)calloc(MAX_ATOMS, sizeof(pdbATOM));
    dummyresparam = NULL;
    
    i=1;
    while(pdb[i].seq_position!=ENDFLAG)
    {
	pdb[i].hbond_satisfied = 0;

	    if(strcmp(pdb[i].residuetype, "GLY")==0) /* build 2HA for GLY if not available */
	    {	
		j=i;
		k = pdb[i].seq_position; 
		flag=0;
		while(pdb[i].seq_position == k && flag == 0)	/* look for 2HA */
		{
		    if(strcmp(pdb[i].atomname, "2HA")==0)
			flag = 1;
		    else if(strcmp(pdb[i].atomname, "CA")==0)
			ca = pdb[i].coord;
		    else if(strcmp(pdb[i].atomname, "N")==0)
			n = pdb[i].coord;
		    else if(strcmp(pdb[i].atomname, "C")==0)
			c = pdb[i].coord;
		    ++i;
		}
		if(flag==0)  /* 2HA not found, so build it */
		{
		    k=i; 
		    
		    i=j;
		    while(strcmp(pdb[i].atomname, "C")!=0 && i!=1)  /* get C of previous residue */		
			--i;
		    
		    if(i!=1)	    /* this gly is not at the N-term, so this pdb[i].atomname == "C" */
			c_ = pdb[i].coord;
		    else    /* couldn't find  pdb[i].atomname == "C" by moving backwards; we must get calc coords for C */
			{
			    dihed = 180;
			    c_ = chi2xyz(&c, &ca, &n, &len_CA_N, &angle_CA_N_C, &dihed);
			}
		
		
		    i=k;
		    q=1;
		    while(pdb[i].seq_position!=ENDFLAG)	/* copy rest of pdb to dummypdb */
		    {
			dummypdb[q] = pdb[i];
			++q; ++i;
		    }
		    dummypdb[q] = pdb[i];
		  
		    i=k;
		    pdb[i].seq_position = pdb[i-1].seq_position;
		    pdb[i].atom_number = i;
		    strcpy(pdb[i].residuetype, "GLY");
		    strcpy(pdb[i].atomname, "2HA");
		    strcpy(pdb[i].seqpos_text, pdb[i-1].seqpos_text);

		    if(pdb[i].seq_position%1000 > 1)
			dihed = dihedral(&c_, &n, &ca, &c) - 120;
		    else
			dihed = -120;
		    
		    pdb[i].coord = chi2xyz(&ca, &n, &c_, &len_HA_CA, &angle_HA_CA_N, &dihed);
		    
		    ++i;
		    q=1;
		    while(dummypdb[q].seq_position!=ENDFLAG)
		    {
			pdb[i] = dummypdb[q];
			++q; ++i;
		    }
		    pdb[i] = dummypdb[q];
		}
		i=j;
	    }
	    else	/* build CB if needed */
		{	
		j=i;
		k = pdb[i].seq_position; 
		flag=0;
		while(pdb[i].seq_position == k && flag == 0)	/* look for CB */
		{
		    if(strcmp(pdb[i].atomname, "CB")==0)
			flag = 1;
		    else if(strcmp(pdb[i].atomname, "CA")==0)
			ca = pdb[i].coord;
		    else if(strcmp(pdb[i].atomname, "N")==0)
			n = pdb[i].coord;
		    else if(strcmp(pdb[i].atomname, "C")==0)
			c = pdb[i].coord;
		    ++i;
		}
		if(flag==0)  /* CB not found, so build it */
		{
		    k=i; 
		    
		    i=j;
		    while(strcmp(pdb[i].atomname, "C")!=0 && i!=1)  /* get C of previous residue */		
			--i;
		    
		    if(i!=1)	    /* this is not at the N-term, so this pdb[i].atomname == "C" */
			c_ = pdb[i].coord;
		    else    /* couldn't find  pdb[i].atomname == "C" by moving backwards; we must get calc coords for C */
			{
			    dihed = 180;
			    c_ = chi2xyz(&c, &ca, &n, &len_CA_N, &angle_CA_N_C, &dihed);
			}
		
		
		    i=k;
		    q=1;
		    while(pdb[i].seq_position!=ENDFLAG)	/* copy rest of pdb to dummypdb */
		    {
			dummypdb[q] = pdb[i];
			++q; ++i;
		    }
		    dummypdb[q] = pdb[i];
		  
		    i=k;
		    pdb[i].seq_position = pdb[i-1].seq_position;
		    pdb[i].atom_number = i;
		    strcpy(pdb[i].residuetype, pdb[i-1].residuetype);
		    strcpy(pdb[i].atomname, "CB");
			strcpy(pdb[i].seqpos_text, pdb[i-1].seqpos_text);
		    
		    if(pdb[i].seq_position%1000 > 1)
			dihed = dihedral(&c_, &n, &ca, &c) - 120;
		    else
			dihed = -120;
		    
		    pdb[i].coord = chi2xyz(&ca, &n, &c_, &len_CB_CA, &angle_CB_CA_N, &dihed);
		    
		    ++i;
		    q=1;
		    while(dummypdb[q].seq_position!=ENDFLAG)
		    {
			pdb[i] = dummypdb[q];
			++q; ++i;
		    }
		    pdb[i] = dummypdb[q];
		}
		i=j;
	    }
	

	p=pdb[i].seq_position;
	while(p == pdb[i].seq_position)
	{
	if(NTE_FLAG==1 && strcmp(pdb[i].atomname,"1H")==0)	/* this has a charged N-term, so back up and reassign the residuetype and pointers */
	{					/* finish completely assigning this residue and advance to the next one */
		k = pdb[i].seq_position;
		while(pdb[i].seq_position == k && i!=0)
		    --i;
		++i;
		while(pdb[i].seq_position == k)
		{
		    if(strcmp(pdb[i].atomname, "N")==0 || strcmp(pdb[i].atomname, "C")==0 || strcmp(pdb[i].atomname, "O")==0 || 
			strcmp(pdb[i].atomname, "1H")==0 || strcmp(pdb[i].atomname, "H")==0 || strcmp(pdb[i].atomname, "CA")==0 ||
			strcmp(pdb[i].atomname, "HA")==0 || strcmp(pdb[i].atomname, "1HA")==0 || strcmp(pdb[i].atomname, "2H")==0 ||
			strcmp(pdb[i].atomname, "3H")==0)
			{
			    if(strcmp(pdb[i].atomname, "1HA")==0)
					strcpy(pdb[i].atomname, "HA");
			    strcpy(pdb[i].residuetype, "NTE");	/* backbone atoms are NTE */
			}
		    dummyresparam = (RESPARAM *)bsearch(pdb[i].residuetype,resparam,MAXRESTYPES,sizeof(RESPARAM),restypecompare_resparam);
		    
		    if(dummyresparam == NULL)
		    {
			fprintf(stderr, "ERROR Do not recognize residuetype %s at position %d\n", pdb[i].residuetype,pdb[i].seq_position);
			exit(1);
		    }
		    
		    pdb[i].atom_ptr = &dummyresparam->sorted_atom[search_atomname_ATOMRESPARAM(pdb[i].atomname,dummyresparam->sorted_atom)];

			

		    pdb[i].sasa=0;	 pdb[i].hbond_satisfied = 0;
		    ++i;	
		}
	}
	else
	{
	    if(pdb[i].seq_position!=ENDFLAG)
	    {
		dummyresparam = (RESPARAM *)bsearch(pdb[i].residuetype,resparam,MAXRESTYPES,sizeof(RESPARAM),restypecompare_resparam);
		
		if(dummyresparam == NULL)
		    {
			fprintf(stderr, "ERROR Do not recognize residuetype %s at position %d\n", pdb[i].residuetype,pdb[i].seq_position);
			exit(1);
		    }
		
		
		pdb[i].atom_ptr = &dummyresparam->sorted_atom[search_atomname_ATOMRESPARAM(pdb[i].atomname,dummyresparam->sorted_atom)];

		

		pdb[i].sasa=0;	pdb[i].hbond_satisfied = 0;
	    }
	    if(CTE_FLAG==1 && (strcmp(pdb[i].atomname,"OT")==0 || strcmp(pdb[i].atomname,"OXT")==0)) /* charged C-term */
	    {
		k = pdb[i].seq_position;
		while(pdb[i].seq_position == k)
		    --i;
		++i;
		while(pdb[i].seq_position == k && pdb[i].seq_position!=ENDFLAG)
		{
		    if(strcmp(pdb[i].atomname, "N")==0 || strcmp(pdb[i].atomname, "C")==0 || strcmp(pdb[i].atomname, "O")==0 || 
			strcmp(pdb[i].atomname, "OT")==0 || strcmp(pdb[i].atomname, "H")==0 || strcmp(pdb[i].atomname, "CA")==0 ||
			strcmp(pdb[i].atomname, "HA")==0 || strcmp(pdb[i].atomname, "1HA")==0)
			{
			    if(strcmp(pdb[i].atomname, "1HA")==0)
				strcpy(pdb[i].atomname, "HA");
			    strcpy(pdb[i].residuetype, "CTE");	/* backbone atoms are CTE */
			}
		    
		    dummyresparam = (RESPARAM *)bsearch(pdb[i].residuetype,resparam,MAXRESTYPES,sizeof(RESPARAM),restypecompare_resparam);
		    
		    if(dummyresparam == NULL)
		    {
			fprintf(stderr, "ERROR Do not recognize residuetype %s at position %d\n", pdb[i].residuetype,pdb[i].seq_position);
			exit(1);
		    }
		
		    
		    pdb[i].atom_ptr = &dummyresparam->sorted_atom[search_atomname_ATOMRESPARAM(pdb[i].atomname,dummyresparam->sorted_atom)];

			
		    pdb[i].sasa=0;	pdb[i].hbond_satisfied = 0;
		    ++i;	
		}	    	
	    }
	    else
		++i;
	}
	}
	 
	    		    
    }
    
      
    strcpy(pdb[i].residuetype,"END");
     pdb[i].atom_number = ENDFLAG;
    pdb[i].sasa=ENDFLAG;
     pdb[i].seq_position=ENDFLAG;
     pdb[i].atom_ptr=NULL;
    
     
      pdb[0].atom_number = ENDFLAG;
    pdb[0].sasa=ENDFLAG;
     pdb[0].seq_position=ENDFLAG;
     pdb[0].atom_ptr=NULL;
     
     
     free_memory(dummypdb);
}


/* Given template pdbATOM and VARIABLE_POSITION array varPos, this function fills the pdbATOM fixed_atm array with
  fixed atoms whose structure does not change during the course of an optimization */   
void make_fixed_pdbATOM(pdbATOM *Template, VARIABLE_POSITION *varPos, pdbATOM *fixed_atm)
{
 int i, H_flag, HA_flag, O_flag, varpos_ctr, fixed_ctr, Template_ctr, j;
 char *restype;
 BACKBONE *bkbn;
 double dihed;
 double len_HA_CA=1.090; 
 double angle_HA_CA_N=109.50; 
 double len_H_N=1.010; 
 double angle_H_N_C=119.80; 
 double len_O_C=1.229;   
 double angle_O_C_CA=120.50; 
 extern ATOMRESPARAM *H_ATOMRESPARAM, *HA_ATOMRESPARAM, *O_ATOMRESPARAM, *U_ATOMRESPARAM;
 
 restype = (char *)calloc(4, sizeof(char));
 
 bkbn = (BACKBONE *)calloc(MAX_RESIDUES, sizeof(BACKBONE));
 extract_bkbn(Template, bkbn);
    
   varpos_ctr = 1; fixed_ctr = 1; Template_ctr = 1; i=1;
   while(varPos[varpos_ctr].seq_position!=ENDFLAG)
    {
      while(varPos[varpos_ctr].seq_position != bkbn[i].seq_position)
	++i;	
      while(Template[Template_ctr].seq_position != varPos[varpos_ctr].seq_position && Template[Template_ctr].seq_position != ENDFLAG) 
	{
	  fixed_atm[fixed_ctr] = Template[Template_ctr];
	  fixed_atm[fixed_ctr].hbond_satisfied = 0;
	  ++Template_ctr; ++fixed_ctr;
	}
      strcpy(restype, Template[Template_ctr].residuetype);	
      H_flag = 0; HA_flag = 0;	O_flag = 0;

	 
	j=Template_ctr;
	while(strcmp(Template[j].atomname,"N")!=0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
		++j;
	if(strcmp(Template[j].atomname,"N")==0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
	{
		fixed_atm[fixed_ctr].hbond_satisfied = 0; fixed_atm[fixed_ctr] = Template[j];  ++fixed_ctr; 
	}
	else
	{
		fprintf(stderr,"Cannot find N for residue %d\n",varPos[varpos_ctr].seq_position);
		exit(1);
	}
	j=Template_ctr;
	while(strcmp(Template[j].atomname,"CA")!=0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
		++j;
	if(strcmp(Template[j].atomname,"CA")==0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
	{
		fixed_atm[fixed_ctr].hbond_satisfied = 0; fixed_atm[fixed_ctr] = Template[j];  ++fixed_ctr; 
	}
	else
	{
		fprintf(stderr,"Cannot find CA for residue %d\n",varPos[varpos_ctr].seq_position);
		exit(1);
	}
	j=Template_ctr;
	while(strcmp(Template[j].atomname,"C")!=0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
		++j;
	if(strcmp(Template[j].atomname,"C")==0 && Template[j].seq_position==varPos[varpos_ctr].seq_position)
	{
		fixed_atm[fixed_ctr].hbond_satisfied = 0; fixed_atm[fixed_ctr] = Template[j];  ++fixed_ctr; 
	}
	else
	{
		fprintf(stderr,"Cannot find C for residue %d\n",varPos[varpos_ctr].seq_position);
		exit(1);
	}
	
	 

      while(Template[Template_ctr].seq_position==varPos[varpos_ctr].seq_position && 
		Template[Template_ctr].seq_position != ENDFLAG)
	{	
		fixed_atm[fixed_ctr].hbond_satisfied = 0;

	 /*
	  if(strcmp(Template[Template_ctr].atomname,"N")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr];  ++fixed_ctr; 
	    }
	  if(strcmp(Template[Template_ctr].atomname,"CA")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr; 
	    }
	  if(strcmp(Template[Template_ctr].atomname,"C")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr; 
	    }
	  
	 */


	  if(strcmp(Template[Template_ctr].atomname,"H")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr; H_flag = 1;
	    }
          if(strcmp(Template[Template_ctr].atomname,"1H")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr; H_flag = 1;
	    }
	  if(strcmp(Template[Template_ctr].atomname,"2H")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr];  ++fixed_ctr; 
	    }
	  if(strcmp(Template[Template_ctr].atomname,"3H")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr];  ++fixed_ctr; 
	    }

	

	  if(strcmp(Template[Template_ctr].atomname,"HA")==0 || strcmp(Template[Template_ctr].atomname,"1HA")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr; HA_flag = 1;
	    }
          if(strcmp(Template[Template_ctr].atomname,"2HA")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr;
	    }
          
	  if(strcmp(Template[Template_ctr].atomname,"O")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr];  ++fixed_ctr; O_flag = 1;
	    }
	  if(strcmp(Template[Template_ctr].atomname,"OT")==0 || strcmp(Template[Template_ctr].atomname,"OXT")==0) 
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr];  ++fixed_ctr;
		/* C-term oxygen */
	    }
	  if(strcmp(Template[Template_ctr].atomname,"HT")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr;
		/* C-term hydrogen */
	    }
	  
	if(strcmp(Template[Template_ctr].atomname,"CB")==0)
	    {
	      fixed_atm[fixed_ctr] = Template[Template_ctr]; ++fixed_ctr;
	      strcpy(restype, Template[Template_ctr].residuetype);
	    }

	  ++Template_ctr;
	}
      
      if(H_flag == 0 && strcmp(restype, "PRO")!=0) /* need to build amide H */
      {
	  H_flag = 1;
	  dihed = bkbn[i-1].omega + 180;
	  fixed_atm[fixed_ctr].coord = chi2xyz(&bkbn[i].N, &bkbn[i-1].C, &bkbn[i-1].CA, &len_H_N, &angle_H_N_C, &dihed);

	  if(strcmp(restype,"UUU")!=0)
	  	fixed_atm[fixed_ctr].atom_ptr = H_ATOMRESPARAM;
	  else
		fixed_atm[fixed_ctr].atom_ptr = U_ATOMRESPARAM;

	  strcpy(fixed_atm[fixed_ctr].atomname, H_ATOMRESPARAM->atomname);

	  strcpy(fixed_atm[fixed_ctr].residuetype, restype);
	  fixed_atm[fixed_ctr].sasa = 0; fixed_atm[fixed_ctr].hbond_satisfied = 0;
	  fixed_atm[fixed_ctr].seq_position = bkbn[i].seq_position;
	  
	  strcpy(fixed_atm[fixed_ctr].seqpos_text, Template[Template_ctr-1].seqpos_text);

	  ++fixed_ctr;
      }
      if(HA_flag == 0)	/* need to build HA */
      {
	 HA_flag = 1;
	 dihed = bkbn[i].phi + 120; 
	 fixed_atm[fixed_ctr].coord = chi2xyz(&bkbn[i].CA, &bkbn[i].N, &bkbn[i-1].C, &len_HA_CA, &angle_HA_CA_N, &dihed);

	 if(strcmp(restype,"UUU")!=0)
	 	fixed_atm[fixed_ctr].atom_ptr = HA_ATOMRESPARAM;
	 else
		fixed_atm[fixed_ctr].atom_ptr = U_ATOMRESPARAM;
         
	 strcpy(fixed_atm[fixed_ctr].atomname, HA_ATOMRESPARAM->atomname);
	 strcpy(fixed_atm[fixed_ctr].residuetype, restype);
	 fixed_atm[fixed_ctr].sasa = 0; fixed_atm[fixed_ctr].hbond_satisfied = 0;
	 fixed_atm[fixed_ctr].seq_position = bkbn[i].seq_position;
	 
	 strcpy(fixed_atm[fixed_ctr].seqpos_text, Template[Template_ctr-1].seqpos_text);

	 if(strcmp(fixed_atm[fixed_ctr].residuetype,"GLY")==0)
		strcpy(fixed_atm[fixed_ctr].atomname, "1HA");

	 ++fixed_ctr;
      }	
      if(O_flag == 0)	/* need to build O */
      {
	 O_flag = 1;
	 dihed = bkbn[i].psi + 180;
	 fixed_atm[fixed_ctr].coord = chi2xyz(&bkbn[i].C, &bkbn[i].CA, &bkbn[i].N, &len_O_C, &angle_O_C_CA, &dihed);
	 fixed_atm[fixed_ctr].atom_ptr = O_ATOMRESPARAM;
	 strcpy(fixed_atm[fixed_ctr].atomname, O_ATOMRESPARAM->atomname);
	 strcpy(fixed_atm[fixed_ctr].residuetype, restype);
	 fixed_atm[fixed_ctr].sasa = 0; fixed_atm[fixed_ctr].hbond_satisfied = 0;
	 fixed_atm[fixed_ctr].seq_position = bkbn[i].seq_position;

	 strcpy(fixed_atm[fixed_ctr].seqpos_text, Template[Template_ctr-1].seqpos_text);
	 
	 ++fixed_ctr;
      }	

      ++varpos_ctr;
    }
    
  while(Template[Template_ctr].seq_position != ENDFLAG) 
	{
	  fixed_atm[fixed_ctr] = Template[Template_ctr];
	  fixed_atm[fixed_ctr].hbond_satisfied = 0;
	  ++Template_ctr; ++fixed_ctr;
	}  
    
    
  strcpy(fixed_atm[fixed_ctr].residuetype,"END");
  fixed_atm[fixed_ctr].sasa = ENDFLAG;
  fixed_atm[fixed_ctr].atom_ptr = NULL;
  fixed_atm[fixed_ctr].seq_position = ENDFLAG;
  fixed_atm[fixed_ctr].atom_number =  ENDFLAG;
  
  
  free_memory(restype);
  free_memory(bkbn); 
}

/* for an allocated mini_pdbATOM array, generate coords, etc, from BACKBONE bkbn */ 
void make_bkbn_mini_pdbATOM(mini_pdbATOM *pdb, BACKBONE *bkbn)
{
  extern ATOMRESPARAM *CB_ATOMRESPARAM, *H_ATOMRESPARAM, *HA_ATOMRESPARAM, 
	    *C_ATOMRESPARAM, *O_ATOMRESPARAM, *N_ATOMRESPARAM, *CA_ATOMRESPARAM;
  
  
  pdb[1].coord = bkbn->N;
  pdb[1].atom_ptr = N_ATOMRESPARAM;
  pdb[1].seq_position = bkbn->seq_position;
  pdb[1].sasa = 0;
  pdb[1].born_radius = 0;
  pdb[1].hbond_satisfied = 0;

  pdb[2].coord = bkbn->H;
  pdb[2].atom_ptr = H_ATOMRESPARAM;
  pdb[2].seq_position = bkbn->seq_position;
  pdb[2].sasa = 0;
  pdb[2].born_radius = 0;
  pdb[2].hbond_satisfied = 0;  

  pdb[3].coord = bkbn->CA;
  pdb[3].atom_ptr = CA_ATOMRESPARAM;
  pdb[3].seq_position = bkbn->seq_position;
  pdb[3].sasa = 0;
  pdb[3].born_radius = 0;
  pdb[3].hbond_satisfied = 0;
  
  pdb[4].coord = bkbn->HA;
  pdb[4].atom_ptr = HA_ATOMRESPARAM;
  pdb[4].seq_position = bkbn->seq_position;
  pdb[4].sasa = 0;
  pdb[4].born_radius = 0;
  pdb[4].hbond_satisfied = 0;

  pdb[5].coord = bkbn->C;
  pdb[5].atom_ptr = C_ATOMRESPARAM;
  pdb[5].seq_position = bkbn->seq_position;
  pdb[5].sasa = 0;
  pdb[5].born_radius = 0;
  pdb[5].hbond_satisfied = 0;
  
  pdb[6].coord = bkbn->O;
  pdb[6].atom_ptr = O_ATOMRESPARAM;
  pdb[6].seq_position = bkbn->seq_position;
  pdb[6].sasa = 0;
  pdb[6].born_radius = 0;
  pdb[6].hbond_satisfied = 0;

  pdb[7].coord = bkbn->CB;
  pdb[7].atom_ptr = CB_ATOMRESPARAM;
  pdb[5].seq_position = bkbn->seq_position;
  pdb[7].sasa = 0;
  pdb[7].born_radius = 0;
  pdb[7].hbond_satisfied = 0;
    
  
  pdb[8].atom_ptr = NULL;
  pdb[8].seq_position = ENDFLAG;
  pdb[8].sasa = ENDFLAG;
  pdb[8].born_radius = 0;
 

}   



/* generates the mini_pdbATOM array var_atm (allocated by calling function) for a SIDECHAIN */

void make_side_mini_pdbATOM(mini_pdbATOM *var_atm, SIDECHAIN *side)
{
  int atomnumber, r, ctr;

  
  atomnumber=1;

  ctr=1; 
  r=9; /* remember, RESPARAM/SIDECHAIN atom numbering starts at 9 */
  
  
  while(side->atom[r].atom_ptr!=NULL)
    {
      var_atm[ctr].atom_ptr = side->atom[r].atom_ptr;	
      var_atm[ctr].coord = side->atom[r].coord;
      var_atm[ctr].seq_position =  side->seq_position;
      var_atm[ctr].born_radius=0;
      var_atm[ctr].sasa = 0;
      var_atm[ctr].hbond_satisfied = 0;
      var_atm[ctr].box=0;
      ++r;
      ++ctr; ++atomnumber;
    }
  var_atm[ctr].atom_ptr=NULL;
  var_atm[ctr].sasa = ENDFLAG;
  var_atm[ctr].seq_position=ENDFLAG;
  var_atm[0].seq_position=0;
  var_atm[ctr].box=0;
}   


/* generates the pdbATOM array var_atm (allocated by calling function) for a SIDECHAIN */

void make_side_pdbATOM(pdbATOM *var_atm, SIDECHAIN *side)
{
  int atomnumber, r;

  pdbATOM *var_atm0;
  
  atomnumber=1;

  var_atm0 = var_atm;

  ++var_atm; 
  r=9; /* remember, RESPARAM/SIDECHAIN atom numbering starts at 9 */
  
  while(side->atom[r].atom_ptr!=NULL)
    {
      strcpy((*var_atm).atomname,(*side).atom[r].atom_ptr->atomname);
      (*var_atm).atom_ptr = side->atom[r].atom_ptr;	
      strcpy((*var_atm).residuetype,side->resparam_ptr->residuetype);
      (*var_atm).atom_number = atomnumber;
      (*var_atm).seq_position=(*side).seq_position;
      (*var_atm).coord = (*side).atom[r].coord;
      (*var_atm).sasa=0; (*var_atm).born_radius=0; (*var_atm).hbond_satisfied = 0;
      ++r;
      ++var_atm; ++atomnumber;
    }
  
  strcpy((*var_atm).residuetype,"END"); (*var_atm).atom_ptr= NULL;
  (*var_atm).sasa = ENDFLAG; (*var_atm).seq_position = ENDFLAG; 
  var_atm = var_atm0;   /* reset array to var_atm[0] */

}   

/* append pdb to the end of pre-loaded array target */
void append_mini_pdbATOM(mini_pdbATOM pdb[], mini_pdbATOM target[])
{
  int p,t;

  t=1;
  while(target[t].seq_position!=ENDFLAG) /* advance to the end of target */
    ++t;
 
  p=1;
  while(pdb[p].seq_position!=ENDFLAG)
    {
      target[t] = pdb[p];
      ++p; ++t;
    }

  /* mark the new end of target */
  target[t].sasa = ENDFLAG;
  target[t].atom_ptr = NULL;
  target[t].seq_position=ENDFLAG;

}

/* append pdb to the end of pre-loaded array target */

void append_pdbATOM(pdbATOM pdb[], pdbATOM target[])
{
  int p,t;

  t=1;
  while(target[t].seq_position!=ENDFLAG) /* advance to the end of target */
    ++t;
 
  p=1;
  while(pdb[p].seq_position!=ENDFLAG)
    {
      target[t] = pdb[p];
      ++p; ++t;
    }

  /* mark the new end of target */
  strcpy(target[t].residuetype,"END");
  target[t].sasa=ENDFLAG;
  target[t].atom_ptr = NULL;
  target[t].seq_position=ENDFLAG;

}

/* parses a seqpos string into an internal sequence position (returned value) */

int parse_seqpos_string(char *seqpos_string, SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map)
{
	int i;


	i=1;
	while(seqpos_text_map[i].seq_position!=ENDFLAG)
	{
		if(strcmp(seqpos_string, seqpos_text_map[i].seqpos_text)==0)
			return(seqpos_text_map[i].seq_position);
		++i;
	}

	fprintf(stderr,"ERROR cannot find the inputed residue %s in the Template pdb file\n",seqpos_string);
	exit(1);
}

/* for a sequence position, return the seqpos_text_map index */
int seqpos_to_inputted_string(int seq_pos, SEQPOS_TEXT_MAPPING_LIST *seqpos_text_map)
{
	int i;


	i=1;
	while(seqpos_text_map[i].seq_position!=ENDFLAG)
	{

		if(seqpos_text_map[i].seq_position == seq_pos)
		{
			return(i);
		}
		++i;
	}
	
	fprintf(stderr,"ERROR cannot find the inputed residue %d\n",seq_pos); 
	exit(1);
}

/* generates sequence (allocated by calling function) for a pdbATOM array.
	resparam = main resparam array;  */
void pdbATOM_to_sequence(pdbATOM *pdb, char *sequence, RESPARAM *resparam)
{
	int i,n;

	i=1; n=0;
	while(pdb[i].seq_position!=ENDFLAG)
	{
		if(strcmp(pdb[i].atom_ptr->atomname,"N")==0)
		{
			sequence[n] = resparam[search_residuetype_RESPARAM(pdb[i].residuetype,resparam)].one_letter_code[0];
			++n;
		}
		++i;
	}
	sequence[n] = '\0';

}

char find_one_letter_code_pdbATOM_seq_position(pdbATOM *pdb, int seq_position, RESPARAM *resparam)
{
	int i;
	RESPARAM *dummyresparam;

	i=1;
	while(pdb[i].seq_position != seq_position)
		++i;

	dummyresparam = (RESPARAM *)bsearch(pdb[i].residuetype,resparam,MAXRESTYPES,sizeof(RESPARAM),restypecompare_resparam);

	return(dummyresparam->one_letter_code[0]);
}
