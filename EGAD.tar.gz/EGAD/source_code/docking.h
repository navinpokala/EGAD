/* EGAD: docking.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for docking.cpp

*/

#ifndef docking_header_flag
#define docking_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "moremath.h"
#include "powell.h"
#include "general_GA.h"
#include "energy_functions.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "complex_formation_energy.h"

void align_structures(PROTEIN *protein);

void rigid_dock(PROTEIN *protein);



/* vdw, coulomb, hbond energies between arrays i_atoms and j_atoms */
/* born pair energies calc'd with born radii already in i_atoms in j_atoms */
ENERGY pair_energy_arraypair(mini_pdbATOM *i_atoms, mini_pdbATOM *j_atoms, int calc_born_flag);

#endif
