/* EGAD: GENES_pdb.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for GENES_pdb.cpp

*/


#ifndef GENES_pdb_header_flag
#define GENES_pdb_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "dihedral_cartesian.h"
#include "pdbATOM_utilities.h"
#include "search_and_sort.h"
#include "VARIABLE_POSITION.h"

/* This function loads a pdbATOM array (allocated by calling function) with the variable sidechain atoms 
   represented by gene */
void GENE_to_var_pdbATOM(GENE *gene, pdbATOM *pdb);

/* This function loads a mini_pdbATOM array (allocated by calling function) with the variable sidechain atoms 
   represented by gene */
void GENE_to_mini_pdbATOM(GENE *gene, mini_pdbATOM *pdb);

/* generate mini_pdbATOM array pdb (allocated by calling function).
   If fixed_atoms == NULL, build the backbone using the bkbngenes linked list on the chromosome.
   If fixed_atoms !=NULL, use its coordinates for the backbone atoms.
   Sidechain atom coords generated from the dihedrals stored in the genes. 
*/
void CHROMOSOME_to_mini_pdbATOM(CHROMOSOME *chr, mini_pdbATOM *fixed_atoms, mini_pdbATOM *pdb, BACKBONE *chain_anchor_bkbn);

/*   This function generates a pdbATOM array pdb (allocated by calling function) for a chromosome chr; 
	If fixed_atoms == NULL, build the backbone using the bkbngenes linked list on the chromosome.
   If fixed_atoms !=NULL, use its coordinates for the backbone atoms.
   Sidechain atom coords generated from the dihedrals stored in the genes. 
*/
void CHROMOSOME_to_pdbATOM(CHROMOSOME *chr, pdbATOM *fixed_atoms, pdbATOM *pdb, BACKBONE *chain_anchor_bkbn);

/*   This function creates a CHROMOSOME containing the sidechain and backbone dihedrals 
	from the pdbATOM pdb array; resparam = main resparam structure 
*/
void pdbATOM_to_CHROMOSOME(pdbATOM *pdb, CHROMOSOME *chr, RESPARAM *resparam);



#endif
