/* EGAD: dihedral_cartesian.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for dihedral_cartesian.cpp

*/


#ifndef dihedral_cartesian_header_flag
#define dihedral_cartesian_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "ligand_stuff.h"

/* returns the coordinates of atom P  
   P---contactAtom             
             \             
           twobondAtom------dihedAtom   
  bondlength = P-b bondlength  
  bondangle = orbital hybridization angle of P-b-c  
  dihedral = P-d dihedral angle, w/ respect to d, clockwise  
*/

CARTESIAN chi2xyz(CARTESIAN *contactAtom, CARTESIAN *twobondAtom, 
		  CARTESIAN *dihedAtom, double *bondlength, 
		  double *bondangle, double *dihedral);
		  
/* This function returns the dihedral angle between atoms A and D */
double dihedral(CARTESIAN *A, CARTESIAN *B, CARTESIAN *C, CARTESIAN *D);

/* 
   This function generates coordinates for a BACKBONE array that has been loaded w/ dihedrals
   bkbn[1] must contain backbone coords for the first residue 
*/
void build_BACKBONE(BACKBONE *bkbn);

/* given the position, the resparam, and the rotamers, this 
   function will generate the cartesian coords of the sidechain atoms into side */

void build_a_SideChain(SIDECHAIN *side, BACKBONE *bkbn, RESPARAM *resparam, int *res_position, double chi[]);

/* extract BACKBONE from atom (array of pdbATOM)
	bkbn must be allocated by the calling function  */
  
void extract_bkbn(pdbATOM *atom, BACKBONE bkbn[]);

/* extract BACKBONE from atom (array of mini_pdbATOM)
	bkbn must be allocated by the calling function  */

void extract_mini_to_bkbn(mini_pdbATOM *atom, BACKBONE bkbn[]);


/* returns the coordinates of the centroid for an array of mini_pdbATOM */
CARTESIAN get_centroid(mini_pdbATOM *pdb);

/* This function extracts the dihedrals from a pdbATOM array containing the atoms for a single residue
   The dihedrals are returned in chi array of double. resparam must be for the residuetype of interest
   This is not very fast or efficient, but there is no need to be as it is done infrequently */

void extract_dihedrals(pdbATOM *pdb, double chi[], RESPARAM *resparam);

/* reduces an array pdb of pdbATOM to an array minipdb of mini_pdbATOM */
void pdbATOM_to_mini_pdbATOM(pdbATOM *pdb, mini_pdbATOM *minipdb);

#endif
