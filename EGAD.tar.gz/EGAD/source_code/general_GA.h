/* EGAD: general_GA.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for general_GA.cpp

*/

#ifndef general_GA_header_flag
#define general_GA_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "io.h"
#include "moremath.h"
#include "powell.h"

/*	Lamarackian genetic algorithm 
		each candidate is powell-minimized

	GA parameters defined in powell->protein->parameters

	soln, upper_bound, lower_bound are double arrays of n elements; 
	soln[i] = will contain final solution for variable i
	upper_bound[i] = max value for variable i
	lower_bound[i] = min value for variable i
	max_iterations = number of GA generations
	score = fitness of final solution
	func = objective function....takes powell POWELL as an argument

*/

void general_purpose_GA(double soln[],double upper_bound[],double lower_bound[], int n, int max_iterations, double *score, double (*func)(double [], POWELL *), POWELL *powell, time_t start_time);

#endif
