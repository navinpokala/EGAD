/* EGAD: batch_jobs.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for batch_jobs.cpp

*/

#ifndef batch_jobs_flag
#define batch_jobs_flag

#include "structure_types.h"
#include "io.h"

/* filename contains a list of egad inputfiles. This function serially launches egad jobs
	to execute those files. A logfile filename.log is written; failures are written to filename.fail
*/
void launch_batch_jobs(char *filename);

#endif
