/* EGAD: egad.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This header file should be included by other programs that use the EGAD library of functions or datastructures.

*/

#ifndef egad_header_flag
#define egad_header_flag


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <vector>
#include <string>

#include "structure_types.h"
#include "input_stuff.h"
#include "VARIABLE_POSITION.h"
#include "pdbATOM_utilities.h"
#include "pairwise_energy_calc.h"
#include "energy_functions.h"
#include "lookup_table.h"
#include "lookup_table_disk_stuff.h"
#include "io.h"
#include "GA_utilities.h"
#include "HQM_rotamers.h"
#include "GA.h"
#include "output_stuff.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "sequence_CHROMOSOME_stuff.h"
#include "GENES_pdb.h"
#include "SASA.h"
#include "dihedral_cartesian.h"
#include "moremath.h"
#include "read_forcefield.h"
#include "readpdbfile.h"
#include "search_and_sort.h"
#include "minimization.h"
#include "powell.h"
#include "general_GA.h"
#include "scmf.h"
#include "MC.h"
#include "dee_utilities.h"
#include "parallel_egad.h"
#include "born_radius_sasa.h"
#include "pK_calculate.h"
#include "energy_profile_table.h"
#include "complex_formation_energy.h"
#include "ligand_stuff.h"
#include "rotamer_calc_foreman.h"
#include "rotamer_calc_master.h"
#include "scanning_mutagenesis.h"
#include "solubility.h"
#include "batch_jobs.h"
#include "multistate.h"
#include "multistate_objective_function.h"
#include "sequence_restraint.h"
#include "docking.h"
#include "somewhat_FASTER.h"

int DEBUG=0;

#endif
