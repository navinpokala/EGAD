/* EGAD: EGAD.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains the EGAD main function from which all EGAD tasks are launched.

*/


#include "egad.h"


/* parses the EGAD main command line arguments to get processor names if necessary */
void get_processors_from_command_line(PROTEIN *protein, int argc, char **argv)
{
  int i,j,num_processors;
  extern char *AVAILABLE_PROCESSORS_FILE;
  extern int GET_PID, NUM_SYSTEM_CPU;
  FILE *file_ptr;
  
  num_processors = 0;

  i=3;
  
      convert_string_to_all_caps(argv[i]);

	  if( (strstr(argv[i],"PROCESSOR")!=0 || strstr(argv[i],"CPU")!=0) && strstr(argv[i],"FILE")!=0)	/* processor file in command line */
	    {
	      if(AVAILABLE_PROCESSORS_FILE==NULL)
		AVAILABLE_PROCESSORS_FILE=(char *)calloc(MXLINE_INPUT,sizeof(char));
	      
	      ++i;
	      sscanf(argv[i],"%s",AVAILABLE_PROCESSORS_FILE);	
	      return;
	    }

	  sscanf(argv[i],"%d",&num_processors);	/* processors listed explicitly in command line */
	  ++i;
	  
	  if(num_processors == 0)
	    {
	      fprintf(stderr,"USAGE: EGAD.exe blah.input (lookup_table_master or parallel) num_processors available_processors: processor_1 processor_2 ..... processor_num_processors\n");
	      fprintf(stderr,"USAGE: EGAD.exe blah.input (lookup_table_master or parallel) available_processors_file: list_of_processors_file\n");
	      exit(1);
	    }

	  convert_string_to_all_caps(argv[i]);
	      if(strstr(argv[i],"PROCESSOR")!=0 || strstr(argv[i],"CPU")!=0)	
		{
		  
		  if(AVAILABLE_PROCESSORS_FILE==NULL)
		    AVAILABLE_PROCESSORS_FILE=(char *)calloc(MXLINE_INPUT,sizeof(char));
		  
		  sprintf(AVAILABLE_PROCESSORS_FILE,"temp.avail_processors.%d",GET_PID);
		  file_ptr = fopen(AVAILABLE_PROCESSORS_FILE,"w");
		  if(argv[i+1] != NULL)
		  {
		  	for(j=1;j<=num_processors;++j)
		    {
		      ++i;
		      fprintf(file_ptr,"%s\n",argv[i]);	
		    }
		  }
		  else
		  {
			NUM_SYSTEM_CPU = num_processors;
			for(j=1;j<=num_processors;++j)
		    {
		      fprintf(file_ptr,"cpu_%d\n",j);
		    }
                  }
		  fclose(file_ptr);
		  return;
		}
	     else 	
		{
	      fprintf(stderr,"USAGE: EGAD.exe blah.input (lookup_table_master or parallel) num_processors available_processors: processor_1 processor_2 ..... processor_num_processors\n");
	      fprintf(stderr,"USAGE: EGAD.exe blah.input (lookup_table_master or parallel) available_processors_file: list_of_processors_file\n");
	      exit(1);
	    	}
}

/* EGAD main function */

int main(int argc, char **argv)
{
  int master_pid, number_of_jobs, i;
  PROTEIN *protein;
  ENERGY energy;
  extern int GB_FLAG, SASA_FLAG, TORSION_FLAG, COULOMB_FLAG, GET_PID, LOOKUP_TABLE_SLAVE_FLAG, OUTPUT_COORD_FLAG, QUIET_FLAG;
  extern char *EXECUTABLE_FILENAME;
  extern SASA_SUM SASA_SUM_TEMP;
  
  if(argc == 1)
    {
      fprintf(stderr,"ERROR: no argument given\n");
      exit(1);
    }		
  
 /* get the name of the current executable; used for launching slaves if needed
	can also specify in inputfile (parsed by input_stuff) */
  EXECUTABLE_FILENAME = (char *)calloc(MXLINE_INPUT,sizeof(char));
  strcpy(EXECUTABLE_FILENAME,argv[0]);

  if(argc > 2)	
    {
	if(strstr(argv[1],"batch")!=0 || strstr(argv[1],"BATCH")!=0)	/* batch job */
	{
		GET_PID = getpid();	QUIET_FLAG = 1;
		launch_batch_jobs(argv[2]);
		exit(0);
	}

	convert_string_to_all_caps(argv[2]);
	

	if(strcmp(argv[2],"LOOKUP_TABLE_SLAVE")==0)
  		QUIET_FLAG = 1;

      if(strcmp(argv[2],"LOOKUP_TABLE_FOREMAN")==0)	/* this is a LOOKUP_TABLE_FOREMAN job */
	{
	  GET_PID = getpid();
	  sscanf(argv[3],"%d",&master_pid);
	  sscanf(argv[4],"%d",&number_of_jobs);
	  lookup_table_foreman(argv[1], master_pid, number_of_jobs);
	  exit(0);
	}

    }
  
  /* read input file */
  protein = (PROTEIN *)malloc(sizeof(PROTEIN));
  input_stuff(argv[1], protein);

    	
	/* this is a parallelized job of some sort, or is a lookup_table_slave */
  if(argc > 2)
  {
	if(argc > 3)
		get_processors_from_command_line(protein, argc, argv);

	if(strcmp(argv[2],"LOOKUP_TABLE_SLAVE")==0)
	{
		LOOKUP_TABLE_SLAVE_FLAG=1;
	  	strcpy(protein->parameters.algorithm, "LOOKUP_TABLE_SLAVE");
	}

	if(strcmp(argv[2],"LOOKUP_TABLE_MASTER")==0)
	{
		lookup_table_master(argv[1], protein);
	}
  }

	if(strcmp(protein->parameters.algorithm, "LOOKUP_TABLE_SLAVE") == 0)
		{
			generate_lookup_table(protein); 
			free_PROTEIN(protein); 
			exit(0);
		}
	

  if(strcmp(protein->parameters.algorithm, "INTERFACE_ALANINE_SCAN") == 0 ||
	strcmp(protein->parameters.algorithm, "INTERFACE_SATURATION_MUTAGENESIS") == 0)
  {
	interface_scan(argv[1], protein);
	free_PROTEIN(protein);
	exit(0);
  }
  
  if(strcmp(protein->parameters.algorithm, "INTERFACE_DESIGN") == 0)
  {
	design_interface(argv[1], protein);
	exit(0);
  }

  if(strncmp(protein->parameters.algorithm, "ALIGN",5) == 0)
	{
		align_structures(protein);
		output_PROTEIN(protein,OUTPUT_COORD_FLAG);
		exit(0);
	}

   if(strcmp(protein->parameters.algorithm, "RIGID_DOCK") == 0)
	{
		rigid_dock(protein);
		output_PROTEIN(protein,OUTPUT_COORD_FLAG);
		exit(0);
	}	

	/* some multistate job */
  if(protein->num_competitors!=0)
  {
	multistate_design(protein);
	free_PROTEIN(protein);
	exit(0);
  }	

	/* this is a rotamer calc foreman; will run slave rotamer optimizations */
  if(protein->parameters.slave_file_list_filename!=NULL)
  {
	rotamer_calc_foreman(argv[1], protein);
	exit(0);
  }
 
	/* MINIMIZE and ADJUST_BACKBONE_TORSIONS are all run by torsion_minimize_PROTEIN */
  else if(strcmp(protein->parameters.algorithm, "MINIMIZE") == 0 || 
	strcmp(protein->parameters.algorithm, "HBUILD") == 0 || 
		strcmp(protein->parameters.algorithm, "ADJUST_BACKBONE_TORSIONS") == 0)
    {	
	torsion_minimize_PROTEIN(protein);
	output_PROTEIN(protein,OUTPUT_COORD_FLAG);
	exit(0);
    }
 
	/* POINT_ENERGY; print out the energy of the inputted structure */
  else if(strstr(protein->parameters.algorithm, "POINT_ENERGY") != 0)
    {
	
	energy = energy_calc(protein->mini_Template, GB_FLAG, SASA_FLAG); 

	
	energy.E_1_4 = ((double)TORSION_FLAG)*energy.E_1_4;
	energy.E_coulomb = ((double)COULOMB_FLAG)*energy.E_coulomb;
	fprintf_energy(stdout,energy);
	if(SASA_FLAG!=0)
	{
		fprintf_sasa(stdout,SASA_SUM_TEMP);

		if(strstr(protein->parameters.algorithm, "SASA") != 0)
		{
			i=1;
			while(protein->Template[i].seq_position!=ENDFLAG)
			{
				protein->Template[i].sasa = protein->mini_Template[i].sasa;
				++i;
			}
			fprintf(stdout,"seq_position\tresiduetype\tSASA_sidechain\tSASA_residue\n");	
			fprintf_residuelevel_sasa(stdout,protein->Template);
		}
	}

    }
	/* ENERGY_PROFILE_TABLE; output the inter-sidechain energy table for the inputted structure  */
  else if(strcmp(protein->parameters.algorithm, "ENERGY_PROFILE_TABLE") == 0)
  {
	generate_energy_profile_table(&protein->energy_profile_table, protein->mini_Template, protein->num_res);
	output_energy_profile_table(protein->energy_profile_table, protein->parameters.output_prefix, protein->num_res, protein->seqpos_text_map, protein->template_sequence);
  }	
	/* seperate a protein-protein complex, and output the complex formation energy */
 else if(strstr(protein->parameters.algorithm, "COMPLEX_FORMATION_ENERGY") != 0)
  {
	  complex_formation_energy_master(argv[1],protein); 
  } 
  else if(strcmp(protein->parameters.algorithm, "SCANNING_MUTAGENESIS") == 0)
  {
	scanning_mutagenesis(argv[1],protein);
	free_PROTEIN(protein);
	exit(0);
  }
  else if(strcmp(protein->parameters.algorithm, "ALANINE_SHAVE") == 0)
  {
	alanine_shave(protein);
	free_PROTEIN(protein);
	exit(0);
  }
  else	/* rotamer optimization of some sort */
  {   
    /* generate lookup table */
    generate_lookup_table(protein); 
 
	
    if(strcmp(protein->parameters.algorithm, "SCMF_PK")==0)	/* calculate pK */
    {
	pK_calculate(protein);
	free_PROTEIN(protein);
	exit(0);
    }
    else if(strcmp(protein->parameters.algorithm, "GA")==0)	/* GA for rotamer optimization */
    {
       GA_rotamers_master_control(protein);
    }
    else if(strcmp(protein->parameters.algorithm, "SCMF")==0)	/* SCMF for getting mean-field energies */
    {
	scmf(protein);
    }
    else if(strncmp(protein->parameters.algorithm, "MC",2)==0)  /* MC for rotamer optimization */
    {
	MC_rotamer_control(protein);
    }
    else if(strcmp(protein->parameters.algorithm, "FASTER")==0)  /* FASTER for rotamer optimization */
    {
	FASTER_rotamer_control(protein);
    }

    output_PROTEIN(protein,OUTPUT_COORD_FLAG);	/* output the final stucture, energy */
   
  }

	free_PROTEIN(protein); /* free memory */

	

  exit(0);
}
