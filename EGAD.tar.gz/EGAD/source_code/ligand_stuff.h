/* EGAD: ligand_stuff.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for ligand_stuff.cpp

*/


#ifndef ligand_stuff_header_flag
#define ligand_stuff_header_flag

#include "structure_types.h"
#include "read_forcefield.h"
#include "io.h"
#include "moremath.h"

/* Extracts the transform matrix for a ligand given its coords in pdb. 
	resparam must be assigned to the proper ligand by the calling function.
	The matrix is read into the chi array (allocated by calling function).
	If the ligand "rotamers" are input directly as coordinates, this function places the 
		coords in pdb into the last "rotamer" for this ligand.
	This function is called by extract_dihedral; rotatable bond dihedrals are calculated there if needed. */
void extract_transform_matrix_for_ligand(pdbATOM *pdb, double *chi, RESPARAM *resparam);

/* Called by build_a_Sidechain.
	This function loads the SIDECHAIN ligand with coords corresponding to "rotamer" chi.
	For "rotamers" = coordinates, chi = rotamerlib index.
	For "rotamers" = transform matrix + dihedrals, chi = matrix + dihedrals.
	resparam must be assigned to the proper ligand by the calling function */
void build_a_Ligand(SIDECHAIN *side, RESPARAM *resparam, double chi[]);

/* called by read_forcefield.cpp: read_rotamers if GENERATE_LIGAMERS is defined */
void generate_ligamers(FILE *input_file_ptr, ROTAMERLIB *rotamerlib, char *line);


/* read ligand coordinates into ligand_coords (allocated by calling function).
	file_ptr at "START" line of the file, immediately preeceding the first coordinate
	Reads until "END". */
void read_ligand_coords(FILE *file_ptr, pdbATOM *ligand_coords);


/* read the ligand data in file ligandfilename. Place ligand info into the main resparam and rotamerlib structures.
	This function is called from read_forcefield */
void read_ligand_data(char *ligandfilename, RESPARAM *ligand_resparam, ROTAMERLIB *ligand_rotamerlib, 
					 ATOMPARAM *atomparam);

/* This function is called after the Template pdb file has been read, and the ligandparam files loaded,
	but before the VARIABLE_POSITIONS have been parsed.
	It creates virtual backbone atoms for each ligand (for book-keeping purposes).
	These (as well as the ligand atoms) are considered to be in chain 'l'
	It extracts the ligand coords from the Template pdb file (if any)
		if "rotamers" = transform matrix, coordinate from pdb file = base_coords for transformation
	Calculates intrinsic energies for ligands and protein sidechains */	
void initialize_stuff_for_ligands(PROTEIN *protein);

#endif
