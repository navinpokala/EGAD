/* EGAD: lookup_table_disk_stuff.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for lookup_table_disk_stuff.h

*/



#ifndef lookup_table_disk_header_flag
#define lookup_table_disk_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "pairwise_energy_calc.h"
#include "io.h"

/* load all relevant and available var-fix energies from disk. 
	return 1 if there are any energies that need to be calculated 
*/
int load_lookupRes_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, int num_fixed_atom_hbonding_atoms, PARAMETERS *parameters);

/* save var-fix energies for a residue at position seq_position to disk. 
	Also save coordinates for sidechains and rotamerlets.
	lookupRes and resparam_ptr are specific for the residuetype at this position.
*/
void save_lookupRes_to_disk(int seq_position, int fixed_flag, int num_fixed_atom_hbonding_atoms, LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, PARAMETERS *parameters);

/* load all relevant and available LOOKUP_ENERGY_RESIDUE_RESIDUE (list of residue-residue pairs that actually interact) from disk.
	return 1 if the interaction table is missing elements that need to be calculated by generate_lookup_table 
*/
int load_lookupResRes_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters);

/* save list of residue-residue pairs that actually interact with i,i_res to disk; 
	varPos is the VARIABLE_POSITION array for all positions, not just i.
	lookupEnergy is the entire lookuptable structure
*/
void save_lookupResRes_to_disk(int i, int i_res, LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters);

/* load all relevant and available LOOKUP_ENERGY_RESIDUE_X (pairs of residue-residue energies) from disk;
	if they are not on disk, calculate and save  
*/
void load_lookupResX_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters);

 /* load coordinates for sidechain and rotamerlets from disk for a residue at a position.
	lookupRes and resparam_ptr are specific for the residue.
	structure_filename is defined by the calling function for the position and residuetype 
*/
void load_coordinates_lookupRes(LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, char *structure_filename);
 
/* save to disk coordinates for sidechain and rotamerlets for a residue at a position.
	lookupRes and resparam_ptr are specific for the residue.
	structure_filename is defined by the calling function for the position and residuetype 
*/
void save_coordinates_lookupRes(LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, char *structure_filename);

/* if using lookup table on disk, check to make sure that forcefield and template pdb are identical.
	Reference state values and solubility filters are included only after everything has been saved/loaded from disk, 
	so these do not need to be identical to the job that generated the table previously. 
	If this is a new table, create the path.
*/
int check_lookup_table(PROTEIN *protein);

/* free rotamerlet coordinates from memory; resparam_ptr and rotamerlet are for a given position and residuetype */
void free_ROTAMERLET(ROTAMERLET *rotamerlet, RESPARAM *resparam_ptr);

/* this function loads sideAtoms coordinates for all LOOKUP_ENERGY_ROTAMER's for 
	all LOOKUP_ENERGY_RESIDUE's at all positions.
	assumes that the lookup table for protein has been created with lookup_table.cpp: generate_lookup_table
*/
void load_all_lookupRes_coordinates(PROTEIN *protein);



#endif
