/* EGAD: lookup_table_disk_stuff.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains functions for reading and writing pair energy lookup_table elements to and from disk.

*/


#include "lookup_table_disk_stuff.h"

extern int GET_PID, LOGFILE_FLAG;
extern char *CURRENT_WORKING_DIRECTORY;

/* free rotamerlet coordinates from memory; resparam_ptr and rotamerlet are for a given position and residuetype */
void free_ROTAMERLET(ROTAMERLET *rotamerlet, RESPARAM *resparam_ptr)
{
  int x,y,k;
  
  if(rotamerlet==NULL)
	return;

  for(k=1;k<=resparam_ptr->rotamerlib_ptr->num_rotamerlets;++k)
    {
      if(rotamerlet[k].coord!=NULL)
	{
	  free_memory(rotamerlet[k].coord);
	  rotamerlet[k].coord = NULL;
	}	
      if(rotamerlet[k].methyl_group!=NULL)
	{
	  if(rotamerlet[k].methyl_group->non_MeH!=NULL)
	    {
	      free_memory(rotamerlet[k].methyl_group->non_MeH);
	      rotamerlet[k].methyl_group->non_MeH = NULL;
	    }	
	  if(rotamerlet[k].methyl_group->MeH!=NULL)
	    {	
	      for(x=1;x<=resparam_ptr->num_methyl_groups;++x)
		{
		  for(y=1;y<=3;++y)
		    {
		      if(rotamerlet[k].methyl_group->MeH[x].coord[y]!=NULL)
			{
			  free_memory(rotamerlet[k].methyl_group->MeH[x].coord[y]);
			  rotamerlet[k].methyl_group->MeH[x].coord[y] = NULL;  
			}    
		    }	
		  free_memory(rotamerlet[k].methyl_group->MeH[x].coord); 
		  rotamerlet[k].methyl_group->MeH[x].coord = NULL;
		}
	      free_memory(rotamerlet[k].methyl_group->MeH);
	      rotamerlet[k].methyl_group->MeH = NULL;
	    }	
	  free_memory(rotamerlet[k].methyl_group);
	  rotamerlet[k].methyl_group = NULL; 
	}	
    }    

	free_memory(rotamerlet);

}
/* load all relevant and available var-fix energies from disk. 
	return 1 if there are any energies that need to be calculated 
*/
int load_lookupRes_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, int num_fixed_atom_hbonding_atoms, PARAMETERS *parameters)
{
  int i;
  int i_res;
  int i_res_rot;
  FILE *energy_file_ptr, *log_file_ptr;
  char *energy_filename, *logfilename, *escape_hatch_filename;
  double denom;
  ROTAMERLIB *rotamerlib_ptr;
  int rotamer_index;
  int calc_var_fix_flag;
  extern char *CURRENT_WORKING_DIRECTORY;
  
	rotamerlib_ptr = NULL;
	energy_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));
	logfilename = NULL; escape_hatch_filename=NULL;
  	calc_var_fix_flag=0;
  
	
	if(LOGFILE_FLAG!=0)
	{
		logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));
		sprintf(logfilename,"%s/%d.lookup_log",CURRENT_WORKING_DIRECTORY, GET_PID);
		log_file_ptr = fopen_file(logfilename,"w");

		escape_hatch_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));
		sprintf(escape_hatch_filename,"%s/escape.lookup_table.%d",CURRENT_WORKING_DIRECTORY,GET_PID);
		fprintf(log_file_ptr,"To exit lookup_table generation and the program\n");
		fprintf(log_file_ptr,"touch\t%s\n",escape_hatch_filename);
		fflush(log_file_ptr);
	}
	else
		log_file_ptr = NULL;

  for(i=1;i<=parameters->numVarPositions; ++i)      /*  position i loop */
    {
      varPos[i].lookup_energy_ptr = &lookupEnergy[i];  /* copy lookup_energy_ptr */ 
      lookupEnergy[i].seq_position = varPos[i].seq_position;
      
      lookupEnergy[i].sizeof_lookupRes = varPos[i].number_of_choices;
      lookupEnergy[i].lookupRes = (LOOKUP_ENERGY_RESIDUE *)calloc((lookupEnergy[i].sizeof_lookupRes+1),sizeof(LOOKUP_ENERGY_RESIDUE));
      
      for(i_res=1; i_res<=varPos[i].number_of_choices; ++i_res)  /* residuetype i_res loop */
	{
	  
	  if(varPos[i].fixed_flag == 0)
	    sprintf(energy_filename, "%s/var_fix/%d/%s.%d.var_fix_energy", 
		    parameters->lookup_energy_table_directory, 
		    lookupEnergy[i].seq_position,
		    varPos[i].choice[i_res].resparam_ptr->residuetype, 
		    lookupEnergy[i].seq_position);
	  else
	    sprintf(energy_filename, "%s/var_fix/%d/%s.%d.var_fix_energy.fixed", 
		    parameters->lookup_energy_table_directory, 
		    lookupEnergy[i].seq_position,
		    varPos[i].choice[i_res].resparam_ptr->residuetype, 
		    lookupEnergy[i].seq_position);			    
	  
	  energy_file_ptr = NULL;
	  if(does_this_file_exist(energy_filename))
	  	energy_file_ptr = fopen_file(energy_filename, "rb");
	  
	  if(energy_file_ptr != NULL)
	    {
		

	      varPos[i].choice[i_res].lookup_res_ptr = &lookupEnergy[i].lookupRes[i_res];
	      varPos[i].choice[i_res].bkbn  = &varPos[i].bkbn;   
	      lookupEnergy[i].lookupRes[i_res].residuecode = varPos[i].choice[i_res].resparam_ptr->residuecode;
	      lookupEnergy[i].lookupRes[i_res].lookupResRes = NULL;
	      
	      fread(&lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot, sizeof(int), 1, energy_file_ptr);
	      fread(&lookupEnergy[i].lookupRes[i_res].E_transfer, sizeof(float), 1, energy_file_ptr);
              fread(&lookupEnergy[i].lookupRes[i_res].sasa_hphob, sizeof(float), 1, energy_file_ptr);
	      fread(&lookupEnergy[i].lookupRes[i_res].sasa_total, sizeof(float), 1, energy_file_ptr);
		
	      rotamerlib_ptr = varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr;
	      
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr = (ROTAMERLIB *)malloc(sizeof(ROTAMERLIB));
	      *varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr = *rotamerlib_ptr;
	      
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers = lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot;
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer = (ROTAMER *)calloc((lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot+2), sizeof(ROTAMER));
	    
	      lookupEnergy[i].lookupRes[i_res].lookupRot = (LOOKUP_ENERGY_ROTAMER *)calloc((lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot+1),sizeof(LOOKUP_ENERGY_ROTAMER));
	      
	      denom = 0;
	      for(i_res_rot=1;i_res_rot<=lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot;++i_res_rot)  /* get indexes and energies of rotamers actually used */
		{
		  ERESROT.sidechain_hbond_status = NULL;
		  ERESROT.bkbn_hbond_indicies	= NULL;
		  ERESROT.num_var_fix_hbond = 0;

		  fread(&rotamer_index, sizeof(int), 1, energy_file_ptr);
		  fread(&ERESROT.energy_var_fix, sizeof(float), 1, energy_file_ptr);
		  fread(&ERESROT.sasa_hphob, sizeof(float), 1, energy_file_ptr);
		  
		/* DUDE */
		  if(ERESROT.energy_var_fix<=-10000)
		  {
				fclose(energy_file_ptr);
				failure_report("ERESROT.energy_var_fix<=-10000 in loading","abort");
		  }

		  fread(&ERESROT.num_var_fix_hbond, sizeof(short int), 1, energy_file_ptr);	

		  if(ERESROT.num_var_fix_hbond!=0)
		  {
		  	ERESROT.bkbn_hbond_indicies = (short int *)calloc(ERESROT.num_var_fix_hbond,sizeof(short int));
		  	fread(ERESROT.bkbn_hbond_indicies, sizeof(short int), 
					ERESROT.num_var_fix_hbond, energy_file_ptr);
		  }

		  if(varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms!=0)
		  {
				ERESROT.sidechain_hbond_status = (bool *)calloc(varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms+2,sizeof(bool));
			    fread(ERESROT.sidechain_hbond_status, sizeof(bool), 
					varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms+2, energy_file_ptr);

		  }

		  ERESROT.P = NULL;
		  varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot] = rotamerlib_ptr->rotamer[rotamer_index];
		  varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot].rank = i_res_rot;
		  denom += varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot].freq;
		}
	      
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->freq_array = (double *)calloc((lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot+2), sizeof(double));
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->freq_array[0] = 0; 
	      varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->freq_array[1] = 0;
	      	      
	      for(i_res_rot=1;i_res_rot<=lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot;++i_res_rot)
		{
		  varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot].freq = 
		    varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot].freq/denom;
		  varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->freq_array[i_res_rot] = 
		    varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->freq_array[i_res_rot-1] + 
		    varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot].freq;
		  ERESROT.rotamer = &varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->rotamer[i_res_rot];
		  ERESROT.lookupX = (LOOKUP_ENERGY_X *)calloc((parameters->numVarPositions-i + 1), sizeof(LOOKUP_ENERGY_X));	
		  ERESROT.sideAtoms = NULL;
		  ERESROT.rotamerlet = NULL;
		}
	      
	      fclose(energy_file_ptr);

		if(LOGFILE_FLAG!=0)
		{
	  fprintf(log_file_ptr,"read var-fix\t%d\t%s\t%d rotamers\n",lookupEnergy[i].seq_position, varPos[i].choice[i_res].resparam_ptr->residuetype, lookupEnergy[i].lookupRes[i_res].sizeof_lookupRot);	
		fflush(log_file_ptr);

			if(does_this_file_exist(escape_hatch_filename)==1)
			{
				fclose(log_file_ptr);
				rm_file(escape_hatch_filename);
				sprintf(logfilename,"%s exists; bailing out",escape_hatch_filename);
				failure_report(logfilename,"exit");
			}
		}

	    }
	  else	/* this residuetype has not been calculated yet */
	    {
	      calc_var_fix_flag = 1;
	      varPos[i].choice[i_res].lookup_res_ptr = NULL;
	      lookupEnergy[i].lookupRes[i_res].lookupRot = NULL;
	    }	
	}
    }	 



  if(LOGFILE_FLAG!=0)
  {
  	fclose(log_file_ptr);
	free_memory(logfilename);
	free_memory(escape_hatch_filename);
  }

  free_memory(energy_filename); 

  return(calc_var_fix_flag);
}	 


/* save var-fix energies for a residue at position seq_position to disk. 
	Also save coordinates for sidechains and rotamerlets.
	lookupRes and resparam_ptr are specific for the residuetype at this position.
*/
void save_lookupRes_to_disk(int seq_position, int fixed_flag, int num_fixed_atom_hbonding_atoms, LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, PARAMETERS *parameters)
{
  int i_res_rot;
  char *structure_filename, *energy_filename, *dir_name, *tempfilename, *escape_hatch_filename=NULL, *logfilename=NULL;
  FILE *energy_file_ptr, *log_file_ptr;
  extern char *CURRENT_WORKING_DIRECTORY;
	
	energy_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 

  if(fixed_flag == 0)
    sprintf(energy_filename, "%s/var_fix/%d/%s.%d.var_fix_energy", 
	    parameters->lookup_energy_table_directory, 
	    seq_position,
	    resparam_ptr->residuetype, 
	    seq_position);
  else
    sprintf(energy_filename, "%s/var_fix/%d/%s.%d.var_fix_energy.fixed", 
	    parameters->lookup_energy_table_directory, 
	    seq_position,
	    resparam_ptr->residuetype, 
	    seq_position);
  
  if(does_this_file_exist(energy_filename) == 1)
  {
    free_memory(energy_filename);
    return;
  }


  	structure_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	dir_name = (char *)calloc(MXLINE_INPUT,sizeof(char));
	tempfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));
	
  sprintf(tempfilename,"%s.%d",energy_filename,GET_PID);  

  energy_file_ptr = fopen(tempfilename, "wb");
  
  if(energy_file_ptr == NULL)
    {
      sprintf(dir_name, "%s/var_fix/%d/",parameters->lookup_energy_table_directory, seq_position);
      
      if(does_this_file_exist(dir_name) == 0)   /* %s/var_fix/%d/ does not exist */
	{   
	  sprintf(dir_name, "%s/var_fix/%d/", parameters->lookup_energy_table_directory, seq_position);
	  make_directory(dir_name);
	  sprintf(dir_name, "%s/coordinates/%d/",parameters->lookup_energy_table_directory, seq_position);
	  make_directory(dir_name);
	}
      
      if(does_this_file_exist(energy_filename) == 1)
	{
	free_memory(structure_filename); 
	free_memory(energy_filename); 
	free_memory(dir_name);
	free_memory(tempfilename);
	return;
	}
      energy_file_ptr = fopen_file(tempfilename, "wb"); /* if it didn't exist before, it better exist now! */
	if(energy_file_ptr == NULL)
	{
		sprintf(dir_name, "Cannot create %s", tempfilename);
		failure_report(dir_name,"exit");
	}
    }
  
  
  fwrite(&lookupRes->sizeof_lookupRot, sizeof(int), 1, energy_file_ptr);
  fwrite(&lookupRes->E_transfer, sizeof(float), 1, energy_file_ptr);
  fwrite(&lookupRes->sasa_hphob, sizeof(float), 1, energy_file_ptr);
  fwrite(&lookupRes->sasa_total, sizeof(float), 1, energy_file_ptr);

  for(i_res_rot=1;i_res_rot<=lookupRes->sizeof_lookupRot;++i_res_rot)  /* get indexes and energies of rotamers actually used */
    {
	
      fwrite(&lookupRes->lookupRot[i_res_rot].rotamer->index, sizeof(int), 1, energy_file_ptr);
      fwrite(&lookupRes->lookupRot[i_res_rot].energy_var_fix, sizeof(float), 1, energy_file_ptr);
      fwrite(&lookupRes->lookupRot[i_res_rot].sasa_hphob, sizeof(float), 1, energy_file_ptr);
      
      

		  fwrite(&lookupRes->lookupRot[i_res_rot].num_var_fix_hbond, sizeof(short int), 
					1, energy_file_ptr);

		  if(lookupRes->lookupRot[i_res_rot].num_var_fix_hbond!=0)
		  	fwrite(lookupRes->lookupRot[i_res_rot].bkbn_hbond_indicies, sizeof(short int), 
					lookupRes->lookupRot[i_res_rot].num_var_fix_hbond, energy_file_ptr);

		  if(resparam_ptr->num_hbonding_sidechain_atoms!=0)
			   fwrite(lookupRes->lookupRot[i_res_rot].sidechain_hbond_status, sizeof(bool), 
					resparam_ptr->num_hbonding_sidechain_atoms+2, energy_file_ptr);

    }
  

  fclose(energy_file_ptr);
  
  mv_file(tempfilename,energy_filename);
  
  if(fixed_flag == 0)
    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
	    parameters->lookup_energy_table_directory, 
	    seq_position,
	    resparam_ptr->residuetype, 
	    seq_position);
  else
    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure.fixed", 
	    parameters->lookup_energy_table_directory, 
	    seq_position,
	    resparam_ptr->residuetype, 
	    seq_position);		    
  
  save_coordinates_lookupRes(lookupRes, resparam_ptr, structure_filename);
  
	if(LOGFILE_FLAG!=0)
	{
		logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));
		
		sprintf(logfilename,"%s/%d.lookup_log",CURRENT_WORKING_DIRECTORY, GET_PID);

		
		log_file_ptr = fopen_file(logfilename,"a");
		fprintf(log_file_ptr,"wrote var-fix\t%d\t%s\t%d rotamers\n",seq_position, resparam_ptr->residuetype, lookupRes->sizeof_lookupRot);
		fclose(log_file_ptr);

		escape_hatch_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));
		sprintf(escape_hatch_filename,"%s/escape.lookup_table.%d",CURRENT_WORKING_DIRECTORY,GET_PID);
		if(does_this_file_exist(escape_hatch_filename)==1)
			{
				rm_file(escape_hatch_filename);
				sprintf(logfilename,"%s exists; bailing out",escape_hatch_filename);
				failure_report(logfilename,"exit");
			}
			

		free_memory(logfilename); free_memory(escape_hatch_filename);
	}

	free_memory(structure_filename); 
	free_memory(energy_filename); 
	free_memory(dir_name);
	free_memory(tempfilename);
	
}


/* load all relevant and available LOOKUP_ENERGY_RESIDUE_RESIDUE (list of residue-residue pairs that actually interact) from disk.
	return 1 if the interaction table is missing elements that need to be calculated by generate_lookup_table 
*/
int load_lookupResRes_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters)
{
  int i, j;
  int i_res, j_res;
  int i_res_rot, j_res_rot;
  int n, q;
  int j_choice_flag[MAX_RES_CHOICES+2], flag, flag2;
  int calc_var_var_flag;
  FILE *interaction_list_file_ptr, *log_file_ptr;
  char *interaction_list_filename, *dummystring, *structure_filename,*tempfilename, *logfilename=NULL;
  char j_choice[MAX_RES_CHOICES+2][4];
  long fp_start_j, fp_middle_j, fp_end_j;
  milli_pdbATOM **i_atoms = NULL, **j_atoms = NULL;
  extern int MAX_ROTAMERS;
  
  calc_var_var_flag = 0;
  
  i_atoms = (milli_pdbATOM **)calloc(MAX_ROTAMERS, sizeof(milli_pdbATOM *)); 
  j_atoms = (milli_pdbATOM **)calloc(MAX_ROTAMERS, sizeof(milli_pdbATOM *));
  

	interaction_list_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	dummystring = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	structure_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	tempfilename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 

	if(LOGFILE_FLAG!=0)
	{
		logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
		sprintf(logfilename,"%s/%d.lookup_log",CURRENT_WORKING_DIRECTORY, GET_PID);
		log_file_ptr = fopen_file(logfilename,"a");
	}
	else
		log_file_ptr = NULL;

  for(i=1;i<=parameters->numVarPositions; ++i)      /*  position i loop */
    {
      for(i_res=1; i_res<=varPos[i].number_of_choices; ++i_res)  /* residuetype i_res loop */
	{
				
	
	
	sprintf(interaction_list_filename, "%s/interaction_lists/%d/%s.%d.interaction_list", 
		  parameters->lookup_energy_table_directory,
		  lookupEnergy[i].seq_position,
		  varPos[i].choice[i_res].resparam_ptr->residuetype, 
		  lookupEnergy[i].seq_position);

	  sprintf(tempfilename,"%s.%d",interaction_list_filename,GET_PID);
	  
	  interaction_list_file_ptr = NULL;
	  if(does_this_file_exist(interaction_list_filename)==1)
	  {
	  	interaction_list_file_ptr = fopen_file(interaction_list_filename, "rb");

		if(LOGFILE_FLAG!=0)
		fprintf(log_file_ptr,"read-modify interaction table\t%d\t%s\n",lookupEnergy[i].seq_position, 
		  varPos[i].choice[i_res].resparam_ptr->residuetype);	
	  }
	  
	  if(interaction_list_file_ptr!=NULL)	
	    {
	        /* create copy for modification */
	      	fclose(interaction_list_file_ptr);
	      	cp_file(interaction_list_filename,tempfilename);  
	      	interaction_list_file_ptr = fopen_file(tempfilename, "rb+"); 
	      
	      	
	      lookupEnergy[i].lookupRes[i_res].lookupResRes = (LOOKUP_ENERGY_RESIDUE_RESIDUE *)calloc((parameters->numVarPositions-i + 1), sizeof(LOOKUP_ENERGY_RESIDUE_RESIDUE));
	      
	      for(j=(i+1);j<=parameters->numVarPositions;++j)
		{
		  lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag = (int *)calloc(varPos[j].number_of_choices, sizeof(int));
		  for(j_res=1;j_res<=varPos[j].number_of_choices;++j_res)
		    lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 0;
		  
		  fp_start_j = ftell(interaction_list_file_ptr);
		  flag = 0;
		  n=1;
		  while(n<MAX_RES_CHOICES)	 /* file has MAX_RES_CHOICES entries; positions not assigned are given zzz */
		    {				/* if we add more residues, the first zzz is overwritten */
		      fread(j_choice[n], sizeof(char), 4, interaction_list_file_ptr);
		      fread(&j_choice_flag[n], sizeof(int), 1, interaction_list_file_ptr); /* 1 if i/i_res and j/j_res interact */
		      if(j_choice_flag[n]==1)
			flag = 1;
		      ++n;	
		    }
		  fp_end_j = ftell(interaction_list_file_ptr);
		  if(flag == 1)	/* at least one residue at position j interacts w/ residue i_res at position i */
		    {
		      for(j_res=1;j_res<=varPos[j].number_of_choices;++j_res)
			{
			  flag2=0;
			  n=1;
			  while(strcmp(j_choice[n],"zzz")!=0 && flag2 == 0)	/* find if j_res and i_res interact */
			    {
			      if(strcmp(varPos[j].choice[j_res].resparam_ptr->residuetype, j_choice[n]) == 0)
				flag2 = 1;
			      else
				++n;
			    }
			  
			  if(strcmp(j_choice[n],"zzz")!=0)
			    {
			      if(j_choice_flag[n] == 1 && flag2 == 1)   /* they interact */
				{
				  lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 1;
				}
			      else	/* no interaction */
				{
				  lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 0;
				}        
			    }
			  else    /* this i_res/j_res pair hasn't been tested yet */
			    {
			      if(Distance_sqrd(varPos[i].bkbn.CB, varPos[j].bkbn.CB)<=FORCEFIELD_DISTANCE_CUTOFF_SQRD)
				{
				  lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 1;
				}
			      else
				{
				  for(i_res_rot=1; i_res_rot<= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
				    {
				      if(ERESROT.sideAtoms == NULL)
					{
					  sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
						  parameters->lookup_energy_table_directory, 
						  lookupEnergy[i].seq_position, 
						  varPos[i].choice[i_res].resparam_ptr->residuetype, 
						  lookupEnergy[i].seq_position);
					  
					  load_coordinates_lookupRes(&lookupEnergy[i].lookupRes[i_res], varPos[i].choice[i_res].resparam_ptr, structure_filename);
					}
				      i_atoms[i_res_rot] = ERESROT.sideAtoms;
				    }    
				  i_atoms[varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers + 1] = NULL;
				  
				  for(j_res_rot=1; j_res_rot<= varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++j_res_rot)
				    {
				      if(ERESROTj.sideAtoms == NULL)
					{
					  sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
						  parameters->lookup_energy_table_directory, 
						  lookupEnergy[j].seq_position, 
						  varPos[j].choice[j_res].resparam_ptr->residuetype, 
						  lookupEnergy[j].seq_position);
					  
					  load_coordinates_lookupRes(&lookupEnergy[j].lookupRes[j_res], varPos[j].choice[j_res].resparam_ptr, structure_filename);
					}
				      j_atoms[j_res_rot] = ERESROTj.sideAtoms;
				    }    
				  j_atoms[varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers + 1] = NULL;
				  				  
				  if(do_these_interact(i_atoms, j_atoms,
						       (varPos[i].choice[i_res].resparam_ptr->numberofSideAtoms+1), 
						       (varPos[j].choice[j_res].resparam_ptr->numberofSideAtoms+1)) == 1) 
				    lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 1;
				  else
				    lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] = 0;	
				}
			      
			      /* insert into appropriate place in file */
			      fseek(interaction_list_file_ptr, fp_start_j, 0); /* find start of j in the file */
			      strcpy(dummystring, "AAA");
			      while(strcmp(dummystring, "zzz")!=0)    /* advance to first zzz entry */
				{
				  fread(dummystring, sizeof(char), 4, interaction_list_file_ptr);
				  fread(&q, sizeof(int), 1, interaction_list_file_ptr);
				}
			      fp_middle_j = ftell(interaction_list_file_ptr);	/* replace with j_res */
			      fseek(interaction_list_file_ptr, fp_middle_j, 0);
			      fwrite(varPos[j].choice[j_res].resparam_ptr->residuetype, sizeof(char), 4, interaction_list_file_ptr);
			      fwrite(&lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1], sizeof(int), 1, interaction_list_file_ptr);	
			      fseek(interaction_list_file_ptr, fp_end_j, 0);	/*  pointer to where it was before */	
			    }
			}
		    }
		}
	      fclose(interaction_list_file_ptr);
	      mv_file(tempfilename, interaction_list_filename);
	      
	    }
	  else	/* need to create the file because it doesn't exist!! */
	    {
	    	
	      calc_var_var_flag = 1;
	      lookupEnergy[i].lookupRes[i_res].lookupResRes = NULL;
	    }
	}
    }
      
  free_memory(i_atoms);   free_memory(j_atoms);   
  i_atoms = NULL; j_atoms = NULL; 
  
	free_memory(interaction_list_filename); 
	free_memory(dummystring); 
	free_memory(structure_filename); 
	free_memory(tempfilename); 
	

	if(LOGFILE_FLAG!=0)
	{
		fclose(log_file_ptr);
		free_memory(logfilename);
	}

  return(calc_var_var_flag);	
}


/* save list of residue-residue pairs that actually interact with i,i_res to disk; 
	varPos is the VARIABLE_POSITION array for all positions, not just i.
	lookupEnergy is the entire lookuptable structure
*/
void save_lookupResRes_to_disk(int i, int i_res, LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters)
{
  int j;
  int j_res;
  int n, q;
  char *interaction_list_filename, *dir_name, *tempfilename, zzz[4], *logfilename;
  FILE *interaction_list_file_ptr, *log_file_ptr;
    
  strcpy(zzz, "zzz");
    
  q=0;
    
	interaction_list_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	

  sprintf(interaction_list_filename, "%s/interaction_lists/%d/%s.%d.interaction_list", 
		  parameters->lookup_energy_table_directory,
		  lookupEnergy[i].seq_position,
		  varPos[i].choice[i_res].resparam_ptr->residuetype, 
		  lookupEnergy[i].seq_position);



  if(does_this_file_exist(interaction_list_filename) == 1)
  {
    free_memory(interaction_list_filename);
    return;
  }

	dir_name = (char *)calloc(MXLINE_INPUT,sizeof(char));  
	tempfilename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 


  sprintf(tempfilename,"%s.%d",interaction_list_filename,GET_PID);  
  interaction_list_file_ptr = fopen(tempfilename, "wb");
    
  if(interaction_list_file_ptr==NULL)
    {

       sprintf(dir_name, "%s/var_var/%d/",  parameters->lookup_energy_table_directory, lookupEnergy[i].seq_position);  
       make_directory(dir_name);
	
       sprintf(dir_name, "%s/interaction_lists/%d/",  parameters->lookup_energy_table_directory, lookupEnergy[i].seq_position);  
       make_directory(dir_name);
	
      if(does_this_file_exist(interaction_list_filename) == 1)  /* this process created the directory, but another one created the file */
	{
	free_memory(interaction_list_filename); 
	free_memory(dir_name); 
	free_memory(tempfilename);
	return;
	}
	
      interaction_list_file_ptr = fopen_file(tempfilename, "wb");  /* it better exist now */
	if(interaction_list_file_ptr == NULL)
	{
		sprintf(dir_name,"Cannot create %s",tempfilename);
		failure_report(dir_name,"exit");
	}
	
    }
    
    
  for(j=(i+1);j<=parameters->numVarPositions;++j)
    {
      n=1;
      for(j_res=1;j_res<=varPos[j].number_of_choices;++j_res)	 
	{				
	  fwrite(varPos[j].choice[j_res].resparam_ptr->residuetype, sizeof(char), 4, interaction_list_file_ptr);
	  fwrite(&lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1], sizeof(int), 1, interaction_list_file_ptr); /* 1 if i/i_res and j/j_res interact */
	  ++n;	
	}
      while(n<MAX_RES_CHOICES)    /* file has MAX_RES_CHOICES entries; positions not assigned are given zzz */
	{			    /* if we add more residues, the first zzz is overwritten */
	  fwrite(zzz, sizeof(char), 4, interaction_list_file_ptr);
	  fwrite(&q, sizeof(int), 1, interaction_list_file_ptr); /* 1 if i/i_res and j/j_res interact */
	  ++n;
	}
		 
    }
    
  fclose(interaction_list_file_ptr);
  
  mv_file(tempfilename,interaction_list_filename);


	if(LOGFILE_FLAG!=0)
	{
		logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
		sprintf(logfilename,"%s/%d.lookup_log",CURRENT_WORKING_DIRECTORY, GET_PID);
		log_file_ptr = fopen_file(logfilename,"a");
		fprintf(log_file_ptr,"create interaction table\t%d\t%s\n",lookupEnergy[i].seq_position, 
		  						varPos[i].choice[i_res].resparam_ptr->residuetype);
		fclose(log_file_ptr);
		free_memory(logfilename);
	}


	free_memory(interaction_list_filename); 
	free_memory(dir_name); 
	free_memory(tempfilename);

}

/* load all relevant and available LOOKUP_ENERGY_RESIDUE_X (pairs of residue-residue energies) from disk;
	if they are not on disk, calculate and save  
*/

#define ERESROTRESX ERESROT.lookupX[j-i].lookupResX[j_res_minus_1]

void load_lookupResX_from_disk(LOOKUP_ENERGY *lookupEnergy, VARIABLE_POSITION *varPos, PARAMETERS *parameters)
{	 
  int go_flag;
  int i, j, h;
  int i_res, j_res, j_res_minus_1;
  int i_res_rot, j_res_rot;
  bool read_error_flag;  /* used for dealing with read errors that (rarely) occur when NFS is really stressed */
  FILE *var_var_file_ptr, *log_file_ptr;
  char *structure_filename, *var_var_filename, *dir_name, *directoryname, *tempfilename;
  char *escape_hatch_filename=NULL, *logfilename=NULL, *path;
  int directory_open_flag, number_of_elements, elements_read_so_far, element_log_ctr, quiet_flag;
  MENDEL i_gene, j_gene;
  short int num_hbond_rot_pairs;
  extern LOOKUP_ENERGY_ROTAMER_X *NON_INTERACT_LOOKUP_ROT_X;
  extern LOOKUP_ENERGY_RESIDUE_X *NON_INTERACT_LOOKUP_RES_X;
  extern float NON_INTERACT_PTR;
  extern int LOOKUP_TABLE_SLAVE_FLAG, QUIET_FLAG;
  extern char *CURRENT_WORKING_DIRECTORY;

element_log_ctr=0;

	quiet_flag = QUIET_FLAG;

	structure_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	var_var_filename = (char *)calloc(MXLINE_INPUT,sizeof(char)); 
	dir_name = (char *)calloc(MXLINE_INPUT,sizeof(char));
	tempfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));	
	
	directoryname = (char *)calloc(MXLINE_INPUT,sizeof(char));	
	path = (char *)calloc(MXLINE_INPUT,sizeof(char));
	
	if(LOGFILE_FLAG!=0)
	{
	logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));	
	sprintf(logfilename,"%s/%d.lookup_log",CURRENT_WORKING_DIRECTORY, GET_PID);
	log_file_ptr = fopen_file(logfilename,"a");

	escape_hatch_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));
	sprintf(escape_hatch_filename,"%s/escape.lookup_table.%d",CURRENT_WORKING_DIRECTORY,GET_PID);

	if(does_this_file_exist(escape_hatch_filename)==1)
			{
				fclose(log_file_ptr);
				rm_file(escape_hatch_filename);
				sprintf(logfilename,"%s exists; bailing out",escape_hatch_filename);
				failure_report(logfilename,"exit");
			}

	}
	else	
		log_file_ptr = NULL;

	sprintf(path,"%s/var_var",parameters->lookup_energy_table_directory);
	make_directory(path);

	number_of_elements=0;

	if(LOGFILE_FLAG!=0)
	{

	
	    for(i=1;i<=parameters->numVarPositions; ++i)
		for(i_res=1; i_res<=varPos[i].number_of_choices; ++i_res)
			for(j=i+1;j<=parameters->numVarPositions; ++j)
				if(lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag != NULL)
					for(j_res=1; j_res<=varPos[j].number_of_choices; ++j_res)
						if(lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res-1] == 1)
							number_of_elements += varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers*varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;
	

		fprintf(log_file_ptr,"Rotamer-rotamer elements: %d\n",number_of_elements);
		fflush(log_file_ptr);	
	}

	

  i_gene.nextgene = NULL; j_gene.nextgene = NULL; 
  elements_read_so_far=0;
  for(i=1;i<=parameters->numVarPositions; ++i)      /*  position i loop */
    {
	directory_open_flag = 0;
      for(i_res=1; i_res<=varPos[i].number_of_choices; ++i_res)  /* residuetype i_res loop */
	{

	  
	  for(j=(i+1);j<=parameters->numVarPositions;++j)
	    {
		go_flag=0;
	  if(parameters->disk_lookup_table_flag == 1)  // generate the whole table now
		go_flag = 1;
	  else
	 	if(varPos[i].fixed_flag == 1 || varPos[j].fixed_flag == 1)  // disk_lookup_table_flag !=1 ; only do var w/ fixed sidechains
			go_flag = 1;

	
	  if(go_flag==1)
		{

	
		if(LOGFILE_FLAG!=0)
	if(does_this_file_exist(escape_hatch_filename)==1)
			{
				fclose(log_file_ptr);
				rm_file(escape_hatch_filename);
				sprintf(logfilename,"%s exists; bailing out",escape_hatch_filename);
				failure_report(logfilename,"exit");
			}

	      if(lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag != NULL)	/* at least one residue at position j interacts w/ residue i_res at position i */
		{

			if(directory_open_flag == 0)
			{
				sprintf(directoryname,"%d",varPos[i].seq_position);
				while(create_directory(directoryname, path)==0);
				directory_open_flag = 1;
			}
		  for(i_res_rot = 1; i_res_rot<= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
		    {
		      ERESROT.lookupX[j-i].lookupResX = (LOOKUP_ENERGY_RESIDUE_X *)calloc((varPos[j].number_of_choices),sizeof(LOOKUP_ENERGY_RESIDUE_X));
		    }
		  for(j_res=1;j_res<=varPos[j].number_of_choices;++j_res)
		    {
			j_res_minus_1 = j_res-1;

		      if(lookupEnergy[i].lookupRes[i_res].lookupResRes[j-i].resres_interact_flag[j_res_minus_1] == 1)   /* they interact */
			{
			  if(varPos[i].fixed_flag == 0 && varPos[j].fixed_flag == 0)
			    sprintf(var_var_filename, "%s/var_var/%d/%d.%d/%s.%d.%s.%d.var_var_energy", 
				    parameters->lookup_energy_table_directory, 
				    varPos[i].seq_position,
				    varPos[i].seq_position,varPos[j].seq_position, 
				    varPos[i].choice[i_res].resparam_ptr->residuetype, 
				    varPos[i].seq_position, 
				    varPos[j].choice[j_res].resparam_ptr->residuetype, 
				    varPos[j].seq_position);
			  else							/* at least one of the positions is fixed; remember, if both positions are fixed,  */
			    {							/*	lookupEnergy[i].lookupRes[i_res].lookupResRes[j_res_minus_1].resres_interact_flag = NULL */

				if(varPos[i].fixed_flag == 1)	/* i is fixed */
				sprintf(var_var_filename, "%s/var_var/%d/%d.%d/%s.%d.f.%s.%d.var_var_energy", 
					parameters->lookup_energy_table_directory, 
					varPos[i].seq_position,
					varPos[i].seq_position,varPos[j].seq_position, 
					varPos[i].choice[i_res].resparam_ptr->residuetype, 
					varPos[i].seq_position, 
					varPos[j].choice[j_res].resparam_ptr->residuetype, 
					varPos[j].seq_position);
			      else	/* j is fixed */
				sprintf(var_var_filename, "%s/var_var/%d/%d.%d/%s.%d.%s.%d.f.var_var_energy", 
					parameters->lookup_energy_table_directory, 
					varPos[i].seq_position,
					varPos[i].seq_position,varPos[j].seq_position, 
					varPos[i].choice[i_res].resparam_ptr->residuetype, 
					varPos[i].seq_position, 
					varPos[j].choice[j_res].resparam_ptr->residuetype, 
					varPos[j].seq_position);	
			    }
				
			  
			  for(i_res_rot = 1; i_res_rot<= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
			    {
				  ERESROTRESX.lookupRotX_hbond = NULL;

			      ERESROTRESX.lookupRotX = 
				(LOOKUP_ENERGY_ROTAMER_X *)calloc((varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers),sizeof(LOOKUP_ENERGY_ROTAMER_X)); 
				}
			    
			elements_read_so_far += varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers*varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;

			  var_var_file_ptr=NULL;
			  if(does_this_file_exist(var_var_filename))
			  	var_var_file_ptr = fopen_file(var_var_filename, "rb");
			    
			  if(var_var_file_ptr!=NULL)	/* the var_var energies for this sidechain pair exist, so load them */
			    {
				if(LOOKUP_TABLE_SLAVE_FLAG == 0)	/* if 1, then this is slave job; don't actually need to load */
				{
					if(LOGFILE_FLAG==2)
						fprintf(log_file_ptr,"read\t%d\t%s\t%d\t%s\n",varPos[i].seq_position,
							varPos[i].choice[i_res].resparam_ptr->residuetype,
							varPos[j].seq_position, varPos[j].choice[j_res].resparam_ptr->residuetype);
						

					read_error_flag = 1;	

					while(read_error_flag==1)
					{
			      		for(i_res_rot=1;i_res_rot <= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
						{
							fread(ERESROTRESX.lookupRotX, sizeof(LOOKUP_ENERGY_ROTAMER_X), varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers, var_var_file_ptr);
				
					if(varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms != 0)
						if(varPos[j].choice[j_res].resparam_ptr->num_hbonding_sidechain_atoms != 0)
						{
							fread(&num_hbond_rot_pairs,sizeof(short int),1,var_var_file_ptr);
							if(num_hbond_rot_pairs!=0)
							{
								ERESROTRESX.lookupRotX_hbond = (LOOKUP_ROTAMER_X_HBOND *)malloc(sizeof(LOOKUP_ROTAMER_X_HBOND));
								ERESROTRESX.lookupRotX_hbond->num_hbond_rot_pairs = num_hbond_rot_pairs;
								ERESROTRESX.lookupRotX_hbond->hbond_rot_pair = (HBOND_ROTAMER_PAIR *)calloc(num_hbond_rot_pairs,sizeof(HBOND_ROTAMER_PAIR));

								for(h=0;h<ERESROTRESX.lookupRotX_hbond->num_hbond_rot_pairs;++h)
								{
									fread(&ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_index,sizeof(short int),1,var_var_file_ptr); 
									ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].i_hbond_status = (bool *)calloc(varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms,sizeof(bool));

									ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_hbond_status = (bool *)calloc(varPos[j].choice[j_res].resparam_ptr->num_hbonding_sidechain_atoms,sizeof(bool));

									fread(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].i_hbond_status,sizeof(bool),varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms,var_var_file_ptr);

									fread(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_hbond_status,sizeof(bool),varPos[j].choice[j_res].resparam_ptr->num_hbonding_sidechain_atoms,var_var_file_ptr);

								}
							}
						}
					} // end i_res_rot

			// check for weird read errors and re-read if necessary

			read_error_flag = 0;
			for(i_res_rot=1;i_res_rot <= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
				for(j_res_rot=1;j_res_rot <= varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++j_res_rot)
							if(ERESROTRESX.lookupRotX[j_res_rot-1].energy_var_var<=-10000)
								read_error_flag=1;

							

			if(read_error_flag==1)
			{
				if(log_file_ptr!=NULL)
						fprintf(log_file_ptr,"error reading\t%d\t%s\t%d\t%s\ttry again\n",varPos[i].seq_position,
							varPos[i].choice[i_res].resparam_ptr->residuetype,
							varPos[j].seq_position, varPos[j].choice[j_res].resparam_ptr->residuetype);

				QUIET_FLAG = 0;
				failure_report("error reading ERESROTRESX.lookupRotX","warn");
				QUIET_FLAG = quiet_flag;
				
				for(i_res_rot=1;i_res_rot <= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
				{
					if(ERESROTRESX.lookupRotX_hbond!=NULL)
					{
						if(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair!=NULL)
						{
							for(h=0;h<ERESROTRESX.lookupRotX_hbond->num_hbond_rot_pairs;++h)
							{
								free_memory(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].i_hbond_status);
								free_memory(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_hbond_status);
							}
	
							free_memory(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair);
						}

						free_memory(ERESROTRESX.lookupRotX_hbond);
					}
				}

				fclose(var_var_file_ptr);
				sleep(5);
				var_var_file_ptr = fopen_file(var_var_filename, "rb");
			}

				}  // end read_error_flag==1

				}	// LOOKUP_TABLE_SLAVE_FLAG == 0
			      fclose(var_var_file_ptr);
			    }
			  else    /* since these sidechains interact, but energies have not been calculated, both sets of coordinates must be loaded at some point */
			    {
			      /* load coordinates for i/i_res if they haven't been loaded already */
				   
			 
			      if(lookupEnergy[i].lookupRes[i_res].lookupRot[1].sideAtoms == NULL)
				{
				  if(varPos[i].fixed_flag == 0)
				    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
					    parameters->lookup_energy_table_directory, 
					    lookupEnergy[i].seq_position, 
					    varPos[i].choice[i_res].resparam_ptr->residuetype, 
					    lookupEnergy[i].seq_position);
				  else
				    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure.fixed", 
					    parameters->lookup_energy_table_directory, 
					    lookupEnergy[i].seq_position, 
					    varPos[i].choice[i_res].resparam_ptr->residuetype, 
					    lookupEnergy[i].seq_position);		
				  load_coordinates_lookupRes(&lookupEnergy[i].lookupRes[i_res], varPos[i].choice[i_res].resparam_ptr, structure_filename);
				}
			      if(lookupEnergy[j].lookupRes[j_res].lookupRot[1].sideAtoms == NULL)
				{
				  if(varPos[j].fixed_flag == 0)
				    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
					    parameters->lookup_energy_table_directory, 
					    lookupEnergy[j].seq_position, 
					    varPos[j].choice[j_res].resparam_ptr->residuetype, 
					    lookupEnergy[j].seq_position);
				  else
				    sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure.fixed", 
					    parameters->lookup_energy_table_directory, 
					    lookupEnergy[j].seq_position, 
					    varPos[j].choice[j_res].resparam_ptr->residuetype, 
					    lookupEnergy[j].seq_position);	
				  load_coordinates_lookupRes(&lookupEnergy[j].lookupRes[j_res], varPos[j].choice[j_res].resparam_ptr, structure_filename);
				}	
								 

   				  i_gene.varpos_ptr = &varPos[i];
			      i_gene.choice_ptr = &varPos[i].choice[i_res];
			      i_gene.seq_position = varPos[i].seq_position;
			      i_gene.j_choice_index = i_res-1;
				    
				  j_gene.varpos_ptr = &varPos[j];
			      j_gene.choice_ptr = &varPos[j].choice[j_res];
			      j_gene.seq_position = varPos[j].seq_position;
			      j_gene.j_choice_index = j_res-1;
	    
			      for(i_res_rot=1;i_res_rot<=varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
				{
				  i_gene.lookupRot = &ERESROT;
				  i_gene.lookupRot_index = i_res_rot;
					
				  for(j_res_rot=1; j_res_rot<= varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++j_res_rot)    
				    {
				      j_gene.lookupRot = &ERESROTj;
				      j_gene.lookupRot_index = j_res_rot; 


			      ERESROTRESX.lookupRotX[j_res_rot-1].energy_var_var = rotamer_pair_energy(&i_gene, &j_gene, &ERESROTRESX.lookupRotX_hbond);
				      if(ERESROTRESX.lookupRotX[j_res_rot-1].energy_var_var == 0)
						ERESROTRESX.lookupRotX[j_res_rot-1].energy_var_var = NON_INTERACT_PTR;
				
				    }
						// trim lookupRotX_hbond 
					if(ERESROTRESX.lookupRotX_hbond!=NULL)
					{
						trim_LOOKUP_ROTAMER_X_HBOND(&ERESROTRESX.lookupRotX_hbond);
					}
				}
				
				  var_var_file_ptr=NULL;
				  if(does_this_file_exist(var_var_filename))
			      	var_var_file_ptr = fopen_file(var_var_filename, "rb");

			      if(var_var_file_ptr == NULL)	// still doesn't exist so create it 
				{
				  sprintf(tempfilename,"%s.%d",var_var_filename,GET_PID);
				  var_var_file_ptr = fopen(tempfilename, "wb");
				    
				  if(var_var_file_ptr==NULL)	// can't be created because the directory has not been created 
				    {
				      sprintf(dir_name, "%s/var_var/%d/%d.%d/", 
					      parameters->lookup_energy_table_directory, 
					      varPos[i].seq_position,
					      varPos[i].seq_position,varPos[j].seq_position);
							
				      // create the directory; if can't 0 is returned so make next level up directory 		
				      // try making it again 
							
				      if(make_directory(dir_name) == 0)	
					{
					  sprintf(dir_name, "%s/var_var/%d/",  parameters->lookup_energy_table_directory, varPos[i].seq_position);
					  make_directory(dir_name);
				
			  	  // now try making it 
					  sprintf(dir_name, "%s/var_var/%d/%d.%d/", 
						  parameters->lookup_energy_table_directory, 
						  varPos[i].seq_position,
						  varPos[i].seq_position,varPos[j].seq_position);
					  make_directory(dir_name);		
					}
					
					
				      var_var_file_ptr = fopen_file(tempfilename, "wb"); //  it better exist, or we have a problem
						if(var_var_file_ptr  == NULL)
						{
							sprintf(dir_name,"Cannot create %s",tempfilename);
							failure_report(dir_name,"exit");
						}
				    }
				    
		
				if(LOGFILE_FLAG==2)
			fprintf(log_file_ptr,"write\t%d\t%s\t%d\t%s\n",varPos[i].seq_position,
						varPos[i].choice[i_res].resparam_ptr->residuetype,
						varPos[j].seq_position, varPos[j].choice[j_res].resparam_ptr->residuetype);
					

				  for(i_res_rot=1;i_res_rot <= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
				  {
				    fwrite(ERESROT.lookupX[j-i].lookupResX[j_res_minus_1].lookupRotX, sizeof(LOOKUP_ENERGY_ROTAMER_X), varPos[j].choice[j_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers, var_var_file_ptr);
				

					if(varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms != 0)
						if(varPos[j].choice[j_res].resparam_ptr->num_hbonding_sidechain_atoms != 0)
						{
							num_hbond_rot_pairs = 0;
							if(ERESROTRESX.lookupRotX_hbond == NULL)
								fwrite(&num_hbond_rot_pairs,sizeof(short int),1,var_var_file_ptr);
							else
							{
								num_hbond_rot_pairs = ERESROTRESX.lookupRotX_hbond->num_hbond_rot_pairs;
								fwrite(&num_hbond_rot_pairs,sizeof(short int),1,var_var_file_ptr);
							}

							if(num_hbond_rot_pairs!=0)
							{
								
								for(h=0;h<ERESROTRESX.lookupRotX_hbond->num_hbond_rot_pairs;++h)
								{
									fwrite(&ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_index,sizeof(short int),1,var_var_file_ptr); 
									
									fwrite(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].i_hbond_status,sizeof(bool),varPos[i].choice[i_res].resparam_ptr->num_hbonding_sidechain_atoms,var_var_file_ptr);

									fwrite(ERESROTRESX.lookupRotX_hbond->hbond_rot_pair[h].j_hbond_status,sizeof(bool),varPos[j].choice[j_res].resparam_ptr->num_hbonding_sidechain_atoms,var_var_file_ptr);

								}
							}
						}
				


				  }
				  fclose(var_var_file_ptr);
				  mv_file(tempfilename, var_var_filename);
			 

				}
			      else	// this file was or is being made by another process, so don't interfere 
				fclose(var_var_file_ptr);
			
				

			    }   
			}
		      else	/* no interaction */
			for(i_res_rot = 1; i_res_rot<= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
			  ERESROT.lookupX[j-i].lookupResX[j_res_minus_1].lookupRotX = NON_INTERACT_LOOKUP_ROT_X;
		    } /* end j_res */
		}
	      else
		for(i_res_rot = 1; i_res_rot<= varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
		  ERESROT.lookupX[j-i].lookupResX = NON_INTERACT_LOOKUP_RES_X;
	    }	/* end j */
	  }	
	    
	  if(lookupEnergy[i].lookupRes[i_res].lookupRot[1].sideAtoms!=NULL)
	    for(i_res_rot=1;i_res_rot<=varPos[i].choice[i_res].resparam_ptr->rotamerlib_ptr->number_of_rotamers;++i_res_rot)
	      {
		free_memory(ERESROT.sideAtoms);
			
		if(ERESROT.rotamerlet!=NULL)
		    free_ROTAMERLET(ERESROT.rotamerlet, varPos[i].choice[i_res].resparam_ptr);
	      }
	}	/* end i_res */
	
	
	if(LOGFILE_FLAG!=0)
	{
	   if(elements_read_so_far>=0.25*number_of_elements)
	   {
		if(elements_read_so_far>=0.75*number_of_elements && element_log_ctr < 75)
		{
			sprintf(logfilename,"%d.lookup_log.0.75.done", GET_PID);
			fprintf(log_file_ptr,">3/4 done; %d rotamer-rotamer elements remaining\n",number_of_elements-elements_read_so_far);
			element_log_ctr = 75;	touch_file(logfilename);
		}
		else
		{
			if(elements_read_so_far>=0.5*number_of_elements && element_log_ctr < 50)
			{
				sprintf(logfilename,"%d.lookup_log.0.5.done", GET_PID);
				fprintf(log_file_ptr,">1/2 done; %d rotamer-rotamer elements remaining\n",number_of_elements-elements_read_so_far);
				element_log_ctr = 50;	touch_file(logfilename);
			}
			else if(element_log_ctr < 25)
			{
				sprintf(logfilename,"%d.lookup_log.0.25.done", GET_PID);
				fprintf(log_file_ptr,">1/4 done; %d rotamer-rotamer elements remaining\n",number_of_elements-elements_read_so_far);
				element_log_ctr = 25;	touch_file(logfilename);
			}	
		}
	    }
		fprintf(log_file_ptr,"read-write pair energies\t%d\n",varPos[i].seq_position);
		fflush(log_file_ptr);

		if(does_this_file_exist(escape_hatch_filename)==1)
			{
				fclose(log_file_ptr);
				rm_file(escape_hatch_filename);
				sprintf(logfilename,"%s exists; bailing out",escape_hatch_filename);
				failure_report(logfilename,"exit");
			}


	}

    }	/* end i */


	if(LOGFILE_FLAG!=0)
	{
		fclose(log_file_ptr);
	
		sprintf(logfilename,"%d.lookup_log.0.75.done", GET_PID);
		if(does_this_file_exist(logfilename)==1)
			rm_file(logfilename);

		sprintf(logfilename,"%d.lookup_log.0.5.done", GET_PID);
		if(does_this_file_exist(logfilename)==1)
			rm_file(logfilename);

		sprintf(logfilename,"%d.lookup_log.0.25.done", GET_PID);
		if(does_this_file_exist(logfilename)==1)
			rm_file(logfilename);

		free_memory(logfilename);	free_memory(escape_hatch_filename);
	}
	free_memory(structure_filename); free_memory(var_var_filename); free_memory(dir_name); free_memory(tempfilename);  free_memory(directoryname);
	free_memory(path);
}

 /* load coordinates for sidechain and rotamerlets from disk for a residue at a position.
	lookupRes and resparam_ptr are specific for the residue.
	structure_filename is defined by the calling function for the position and residuetype 
*/
void load_coordinates_lookupRes(LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, char *structure_filename)
{
  FILE *file_ptr;
  int h,k, x, y,  i_res_rot;
  extern int LOCAL_MINIMIZATION_FLAG;
   
  file_ptr = fopen_file(structure_filename, "rb");			

  for(i_res_rot=1; i_res_rot<= resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
    {
      lookupRes->lookupRot[i_res_rot].sideAtoms = (milli_pdbATOM *)calloc((resparam_ptr->numberofSideAtoms+2), sizeof(milli_pdbATOM));
      fread(lookupRes->lookupRot[i_res_rot].sideAtoms, sizeof(milli_pdbATOM),resparam_ptr->numberofSideAtoms+2, file_ptr);
	
      if(LOCAL_MINIMIZATION_FLAG == 1)
	{
	  lookupRes->lookupRot[i_res_rot].rotamerlet = (ROTAMERLET *)calloc((resparam_ptr->rotamerlib_ptr->num_rotamerlets+1), sizeof(ROTAMERLET));
	  for(h=1;h<=resparam_ptr->rotamerlib_ptr->num_rotamerlets;++h)
	    {
	      lookupRes->lookupRot[i_res_rot].rotamerlet[h].coord = (CARTESIAN *)calloc((resparam_ptr->numberofSideAtoms+2), sizeof(CARTESIAN));
	    
	      fread(lookupRes->lookupRot[i_res_rot].rotamerlet[h].coord, sizeof(CARTESIAN),resparam_ptr->numberofSideAtoms+2, file_ptr);
	    
	      if(resparam_ptr->num_methyl_groups != 0)
		{
		  lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group = (METHYL *)malloc(sizeof(METHYL));
		  lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->non_MeH = 
		    (CARTESIAN *)calloc((resparam_ptr->numberofSideAtoms+2 - 3*resparam_ptr->num_methyl_groups), sizeof(CARTESIAN));
		  fread(lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->non_MeH, sizeof(CARTESIAN),(resparam_ptr->numberofSideAtoms+2 - 3*resparam_ptr->num_methyl_groups), file_ptr);

		  lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->MeH = (METHYL_H *)calloc(resparam_ptr->num_methyl_groups+1,sizeof(METHYL_H)); 
		
		  for(x=1;x<=resparam_ptr->num_methyl_groups;++x)
		    {
		      lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->MeH[x].coord = (CARTESIAN **)calloc(4, sizeof(CARTESIAN *));
		      k=1;
		      for(y=-1;y<=1;++y)
			{
			  lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->MeH[x].coord[k] =  (CARTESIAN *)calloc(4, sizeof(CARTESIAN));
			
			  fread(lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->MeH[x].coord[k], sizeof(CARTESIAN),4, file_ptr);
	
			  ++k;
			}
		    }		    
		}    
	    }
	}
    }		    
  fclose(file_ptr);	    
}

 /* save to disk coordinates for sidechain and rotamerlets for a residue at a position.
	lookupRes and resparam_ptr are specific for the residue.
	structure_filename is defined by the calling function for the position and residuetype 
*/
void save_coordinates_lookupRes(LOOKUP_ENERGY_RESIDUE *lookupRes, RESPARAM *resparam_ptr, char *structure_filename)
{
  FILE *file_ptr;
  int h,k, x, y, i_res_rot;
  extern int LOCAL_MINIMIZATION_FLAG;
  char *tempfilename;

  if(does_this_file_exist(structure_filename) == 1)
    return;

   tempfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));

  sprintf(tempfilename,"%s.%d",structure_filename,GET_PID);
  file_ptr = fopen_file(tempfilename, "wb");
    
  for(i_res_rot=1; i_res_rot<= resparam_ptr->rotamerlib_ptr->number_of_rotamers; ++i_res_rot)
    {
      fwrite(lookupRes->lookupRot[i_res_rot].sideAtoms, sizeof(milli_pdbATOM),resparam_ptr->numberofSideAtoms+2, file_ptr);
	
      if(LOCAL_MINIMIZATION_FLAG == 1)
	{
	  for(h=1;h<=resparam_ptr->rotamerlib_ptr->num_rotamerlets;++h)
	    {
	      fwrite(lookupRes->lookupRot[i_res_rot].rotamerlet[h].coord, sizeof(CARTESIAN),resparam_ptr->numberofSideAtoms+2, file_ptr);
	    
	      if(resparam_ptr->num_methyl_groups != 0)
		{
		  fwrite(lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->non_MeH, sizeof(CARTESIAN),(resparam_ptr->numberofSideAtoms+2 - 3*resparam_ptr->num_methyl_groups), file_ptr);

		  for(x=1;x<=resparam_ptr->num_methyl_groups;++x)
		    {
		      k=1;
		      for(y=-1;y<=1;++y)
			{
			  fwrite(lookupRes->lookupRot[i_res_rot].rotamerlet[h].methyl_group->MeH[x].coord[k], sizeof(CARTESIAN),4, file_ptr);
			  ++k;
			}
		    }		    
		}    
	    }
	}
    }		    
  fclose(file_ptr);	 
  
  mv_file(tempfilename,structure_filename);

	free_memory(tempfilename);

}


/* if using lookup table on disk, check to make sure that forcefield and template pdb are identical.
	Reference state values and solubility filters are included only after everything has been saved/loaded from disk, 
	so these do not need to be identical to the job that generated the table previously. 
	If this is a new table, create the path.
*/	
    
int check_lookup_table(PROTEIN *protein)
{
  char *dummystring;
  CARTESIAN *dummy_cartesian;
  FILE *lookuptable_info_file;
  int dummyint, i, j, good, new_restype_flag;
  double dummydouble;
  RESPARAM *dummyresparam;
  ROTAMERLIB *dummyrotamerlib;
  extern double IONIC_STRENGTH,PH,TEMPERATURE;
  extern double VDW_RADII_SCALE,VDW_CUTOFF,VDW_ATTRACTIVE_FACTOR,VDW_REPULSIVE_FACTOR;
  extern double VDW_LINEAR_START_POINT;
  extern double GENERAL_ASP,HYDROPHOBIC_ASP;
  extern int SASA_FLAG;
  extern int GB_FLAG;
  extern int COULOMB_FLAG;
  extern int TORSION_FLAG;
  extern double WEIGHT_VDW,WEIGHT_1_4,WEIGHT_ELECTROSTATICS;
  extern int LOCAL_MINIMIZATION_FLAG;
  extern int INTRA_ROTAMER_FLAG, CHARGES_PH_INDEPENDENT_FLAG;
  

  	/* didn't make dir because either the dir already exists or the path is nonexistent */
	if(make_directory(protein->parameters.lookup_energy_table_directory) == 0)	
		touch_file(protein->parameters.lookup_energy_table_directory);	/* if can't touch this, will exit with error */

  dummy_cartesian=NULL;
  dummyresparam = (RESPARAM *)calloc(MAXRESTYPES, sizeof(RESPARAM));
  dummyrotamerlib = (ROTAMERLIB *)calloc(MAXRESTYPES, sizeof(ROTAMERLIB));
  dummystring = (char *)calloc(MXLINE_INPUT, sizeof(char));
  
  good = 0; 
  
  sprintf(dummystring, "%s/forcefield_info", protein->parameters.lookup_energy_table_directory);

  lookuptable_info_file = NULL;
 
  new_restype_flag=0;
  if(does_this_file_exist(dummystring))  
  	lookuptable_info_file = fopen_file(dummystring, "rb");
  else
	new_restype_flag=1;

  if(new_restype_flag == 0)   /* read in the data and make sure it's the same */
    {
      fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
      if(dummydouble == 12345)
	{
	  fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
	  if(dummyint == CHARGES_PH_INDEPENDENT_FLAG)
	  {	      
		if(dummyint == 0)	/* same pH & temp. required iff CHARGES_PH_INDEPENDENT_FLAG=0; ie: pH-avg'd charges */
		{
			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
			if(dummydouble!=PH)
				{
					fprintf(stderr, "ERROR pH old = %lf for CHARGES_PH_INDEPENDENT_FLAG=0\n", dummydouble);
					exit(1);
				}
			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
				if(dummydouble!=TEMPERATURE)
				{
					fprintf(stderr, "ERROR TEMPERATURE old = %lf for CHARGES_PH_INDEPENDENT_FLAG=0\n", dummydouble);
					exit(1);
				}
		}

	  fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
	  if(dummydouble == IONIC_STRENGTH)
	    {
		if(dummydouble!=0) /* for non-zero ionic strengths, temp. must be the same */
		{
			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
			if(dummydouble!=TEMPERATURE)
			{
				fprintf(stderr, "ERROR TEMPERATURE old = %lf for IONIC_STRENGTH!=0\n", dummydouble);
				exit(1);
			}
		}

	      fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
	      if(dummydouble == INTERNAL_DIELECTRIC)
		{	   

			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == VDW_LINEAR_START_POINT)
			{

		      fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == VDW_RADII_SCALE)
			{
			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == VDW_CUTOFF)
			{
			fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == VDW_ATTRACTIVE_FACTOR)
			{
				fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == VDW_REPULSIVE_FACTOR)
				{
				fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == WEIGHT_VDW)
			   {
				fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == WEIGHT_1_4)
			   {
			  fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
		      if(dummydouble == WEIGHT_ELECTROSTATICS)
			   {
			
			      fread(&dummydouble, sizeof(double), 1, lookuptable_info_file); 
			      if(dummydouble == GENERAL_ASP)
				{    
		    
				fread(&dummydouble, sizeof(double), 1, lookuptable_info_file); 
			      if(dummydouble == HYDROPHOBIC_ASP)
				{  

				  fread(&dummydouble, sizeof(double), 1, lookuptable_info_file);
				  if(fabs(dummydouble - protein->fixedatoms_energy.E_vdw)<=EPS)
				    {
		    
				      fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
				      if(dummyint == SASA_FLAG)
					{
					  fread(&dummyint, sizeof(int), 1, lookuptable_info_file);  
					  if(dummyint == GB_FLAG)
					    {
					      fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
					      if(dummyint == COULOMB_FLAG)
						{
						  fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
						  if(dummyint == TORSION_FLAG)
						    {
						      fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
						      if(dummyint == LOCAL_MINIMIZATION_FLAG)
							{
							  fread(&dummyint, sizeof(int), 1, lookuptable_info_file);
							  if(dummyint == INTRA_ROTAMER_FLAG)
							    {
							      fread(dummyresparam, sizeof(RESPARAM),MAXRESTYPES, lookuptable_info_file);
							      i=1; 
							      while(strcmp(dummyresparam[i].residuetype, "zzz")!=0)
								{
								  j=1;
								  while(strcmp(protein->resparam[j].residuetype, dummyresparam[i].residuetype)!=0 && 
									strcmp(protein->resparam[j].residuetype, "zzz")!=0)
								    ++j;
									/* this residue is in the new resparam; make sure they are identical */
								  if(strcmp(protein->resparam[j].residuetype, "zzz")!=0)  
								    {
								      if(protein->resparam[j].numberofAtoms ==  dummyresparam[i].numberofAtoms)
									{
									  if(protein->resparam[j].max_vdw ==  dummyresparam[i].max_vdw)
									    {
									      if(protein->resparam[j].residuecode ==  dummyresparam[i].residuecode)
										{
											if(protein->resparam[j].max_solvation ==  dummyresparam[i].max_solvation)			
											{
										  		good = 0;
											}
											else
											{
										  fprintf(stderr, "ERROR Different max_solvation for %s\n", protein->resparam[j].residuetype);
										  exit(1);
											}
										}
									      else
										{
										  fprintf(stderr, "ERROR Different residuecode for %s\n", protein->resparam[j].residuetype);
										  exit(1);
										}	
									    }
									  else
									    {
									      fprintf(stderr, "ERROR Different max_vdw for %s\n", protein->resparam[j].residuetype);
									      exit(1);
									    }
									}
								      else
									{
									  fprintf(stderr, "ERROR Different number of atoms for %s\n", protein->resparam[j].residuetype);
									  exit(1);
									}	    		    	
								    }
									else
										new_restype_flag=1;
								  ++i;
								}    			    
							      fread(dummyrotamerlib, sizeof(ROTAMERLIB),MAXRESTYPES, lookuptable_info_file);
							      i=1;
							      while(strcmp(dummyrotamerlib[i].residuetype, "zzz")!=0)
								{
								  j=1;
								  while(strcmp(protein->rotamerlib[j].residuetype, dummyrotamerlib[i].residuetype)!=0 && 
									strcmp(protein->rotamerlib[j].residuetype, "zzz")!=0)
								    ++j;
								  if(strcmp(protein->rotamerlib[j].residuetype, "zzz")!=0)
								    {
								      if(protein->rotamerlib[j].number_of_rotamers == dummyrotamerlib[i].number_of_rotamers)
									{
									  if(protein->rotamerlib[j].num_rotamerlets == dummyrotamerlib[i].num_rotamerlets)
									    {
											if(protein->rotamerlib[j].numChi == dummyrotamerlib[i].numChi)
											{
									      		good = 1;
											}
											else
											{
												fprintf(stderr, "ERROR Different number of chi for %s\n", protein->rotamerlib[j].residuetype);
									      		exit(1);
											}
									    }
									  else
									    {
									      fprintf(stderr, "ERROR Different number of num_rotamerlets for %s\n", protein->rotamerlib[j].residuetype);
									      exit(1);
									    }	
									}
								      else
									{
									  fprintf(stderr, "ERROR Different number of rotamers for %s\n", protein->rotamerlib[j].residuetype);
									  exit(1);
									}			    	
								    }	
								  ++i;	
								}
							    }
							  else
							    {
							      fprintf(stderr, "ERROR INTRA_ROTAMER_FLAG old = %d\n", dummyint);
							      exit(1);
							    }
							}
						      else
							{
							  fprintf(stderr, "ERROR LOCAL_MINIMIZATION_FLAG old = %d\n", dummyint);
							  exit(1);
							}
						    }
						  else
						    {
						      fprintf(stderr, "ERROR TORSION_FLAG old = %d\n", dummyint);
						      exit(1);
						    }
						}
					      else
						{
						  fprintf(stderr, "ERROR COULOMB_FLAG old = %d\n", dummyint);
						  exit(1);
						}
					    }
					  else
					    {
					      fprintf(stderr, "ERROR GB_FLAG old = %d\n", dummyint);
					      exit(1);
					    }
					}
				      else
					{
					  fprintf(stderr, "ERROR SASA_FLAG old = %d\n", dummyint);
					  exit(1);
					}
				    }
				  else
				    {   
				      fprintf(stderr, "ERROR template pdb file is different\n");
				      exit(1); 
				    }
				}
				else
				{
				  fprintf(stderr, "ERROR HYDROPHOBIC_ASP old = %f\n", dummydouble);
				  exit(1);
				}
			    }
			      else
				{
				  fprintf(stderr, "ERROR GENERAL_ASP old = %f\n", dummydouble);
				  exit(1);
				}
			    }
				
			  
			else
			{
			  fprintf(stderr, "ERROR WEIGHT_ELECTROSTATICS old = %f\n",  dummydouble);
			  exit(1);
			}
		    }
			else
			{
			  fprintf(stderr, "ERROR WEIGHT_1_4 old = %f\n",  dummydouble);
			  exit(1);
			}
		    }
			else
			{
			  fprintf(stderr, "ERROR WEIGHT_VDW old = %f\n",  dummydouble);
			  exit(1);
			}
		    }
			else
			{
			  fprintf(stderr, "ERROR VDW_REPULSIVE_FACTOR old = %f\n",VDW_REPULSIVE_FACTOR);
			  exit(1);
			}
		    }
			else
			{
			  fprintf(stderr, "ERROR VDW_ATTRACTIVE_FACTOR old = %f\n",VDW_ATTRACTIVE_FACTOR);
			  exit(1);
			}
		    }
			else
			{
			  fprintf(stderr, "ERROR VDW_CUTOFF old = %f\n",  dummydouble);
			  exit(1);
			}
		    }

		      else
			{
			  fprintf(stderr, "ERROR VDW_RADII_SCALE old = %f\n",  dummydouble);
			  exit(1);
			}
		    }
			
			else
			{
			  fprintf(stderr, "ERROR VDW_LINEAR_START_POINT old = %f\n",  dummydouble);
			  exit(1);
			}
		    }

		  else	
		    {
		      fprintf(stderr, "ERROR Ep old is %f\n", dummydouble);
		      exit(1);
		    }
	    }
	  else
	    {
	      fprintf(stderr, "ERROR IONIC_STRENGTH old = %f\n", dummydouble);
	      exit(1);
	    }
	  }
	  else
	  {
		fprintf(stderr, "ERROR CHARGES_PH_INDEPENDENT_FLAG old = %d\n", dummyint);
	        exit(1);
	  }
	}     
      else
	{
	  fprintf(stderr, "ERROR computing platform different from lookup table files\n");
	  exit(1); 
	}	 		    			    		    			     		   
    }

   if(new_restype_flag==1)	/* write the data */
    {
      lookuptable_info_file = fopen_file(dummystring, "wb");
      
      good=1;
      dummydouble = 12345;
      fwrite(&dummydouble, sizeof(double), 1, lookuptable_info_file); 
      fwrite(&CHARGES_PH_INDEPENDENT_FLAG, sizeof(int), 1, lookuptable_info_file);
      if(CHARGES_PH_INDEPENDENT_FLAG==0)
      {
      	fwrite(&PH, sizeof(double), 1, lookuptable_info_file);
      	fwrite(&TEMPERATURE, sizeof(double), 1, lookuptable_info_file);
      }
      fwrite(&IONIC_STRENGTH, sizeof(double), 1, lookuptable_info_file);
      if(IONIC_STRENGTH!=0)
      	fwrite(&TEMPERATURE, sizeof(double), 1, lookuptable_info_file);
      fwrite(&INTERNAL_DIELECTRIC, sizeof(double), 1, lookuptable_info_file);

      fwrite(&VDW_LINEAR_START_POINT, sizeof(double), 1, lookuptable_info_file);


      fwrite(&VDW_RADII_SCALE, sizeof(double), 1, lookuptable_info_file);
      fwrite(&VDW_CUTOFF, sizeof(double), 1, lookuptable_info_file);
      fwrite(&VDW_ATTRACTIVE_FACTOR, sizeof(double), 1, lookuptable_info_file);
      fwrite(&VDW_REPULSIVE_FACTOR, sizeof(double), 1, lookuptable_info_file);
      fwrite(&WEIGHT_VDW, sizeof(double), 1, lookuptable_info_file);  
      fwrite(&WEIGHT_1_4, sizeof(double), 1, lookuptable_info_file); 
      fwrite(&WEIGHT_ELECTROSTATICS, sizeof(double), 1, lookuptable_info_file); 
      fwrite(&GENERAL_ASP, sizeof(double), 1, lookuptable_info_file);
      fwrite(&HYDROPHOBIC_ASP, sizeof(double), 1, lookuptable_info_file);

      dummydouble = protein->fixedatoms_energy.E_vdw;
      fwrite(&dummydouble, sizeof(double),1, lookuptable_info_file);

      fwrite(&SASA_FLAG, sizeof(int), 1, lookuptable_info_file);
      fwrite(&GB_FLAG, sizeof(int), 1, lookuptable_info_file);
      fwrite(&COULOMB_FLAG, sizeof(int), 1, lookuptable_info_file);
      fwrite(&TORSION_FLAG, sizeof(int), 1, lookuptable_info_file);
      fwrite(&LOCAL_MINIMIZATION_FLAG, sizeof(int), 1, lookuptable_info_file);
      fwrite(&INTRA_ROTAMER_FLAG, sizeof(int), 1, lookuptable_info_file);
      
      fwrite(protein->resparam, sizeof(RESPARAM),MAXRESTYPES, lookuptable_info_file);
      fwrite(protein->rotamerlib, sizeof(ROTAMERLIB),MAXRESTYPES, lookuptable_info_file);
    }
  
  fclose(lookuptable_info_file);
  
  i=1;
  while(strcmp(protein->resparam[i].residuetype,"zzz")!=0)
  {
	if(protein->resparam[i].ligand_flag==1)
	{
  		sprintf(dummystring, "%s/ligand.%s.info", protein->parameters.lookup_energy_table_directory,
						protein->resparam[i].residuetype);
 	 	if(does_this_file_exist(dummystring)==0)
  		{
  			lookuptable_info_file = fopen_file(dummystring, "wb"); 
			fwrite(&protein->resparam[i].rotamerlib_ptr->numChi,sizeof(int),1,lookuptable_info_file);

			if(protein->resparam[i].rotamerlib_ptr->numChi!=1) // write base coordinates
			{
				fwrite(&protein->resparam[i].rotamerlib_ptr->ligand_base_coords[1].coord,sizeof(CARTESIAN),1,lookuptable_info_file);
				fwrite(&protein->resparam[i].rotamerlib_ptr->ligand_base_coords[2].coord,sizeof(CARTESIAN),1,lookuptable_info_file);
				fwrite(&protein->resparam[i].rotamerlib_ptr->ligand_base_coords[3].coord,sizeof(CARTESIAN),1,lookuptable_info_file);
				fwrite(&protein->resparam[i].rotamerlib_ptr->ligand_base_coords[4].coord,sizeof(CARTESIAN),1,lookuptable_info_file);
				
			}

  			fclose(lookuptable_info_file);
  		} 
  		else
  		{
			lookuptable_info_file = fopen_file(dummystring, "rb");
			fread(&dummyint,sizeof(int),1,lookuptable_info_file);			

			if(protein->resparam[i].rotamerlib_ptr->numChi!=dummyint)
			{
				if(dummyint==1)
					fprintf(stderr,"ERROR Previously used coordinate ligamers for %s\n",protein->resparam[i].residuetype);
				else
					fprintf(stderr,"ERROR Previously did not use coordinate ligamers for %s\n",protein->resparam[i].residuetype);

				exit(1);
			}
			
			if(dummyint!=1) // read base coordinates and compare	
			{
				dummy_cartesian = (CARTESIAN *)calloc(5,sizeof(CARTESIAN));
				fread(&dummy_cartesian[1],sizeof(CARTESIAN),1,lookuptable_info_file);
				fread(&dummy_cartesian[2],sizeof(CARTESIAN),1,lookuptable_info_file);
				fread(&dummy_cartesian[3],sizeof(CARTESIAN),1,lookuptable_info_file);
				fread(&dummy_cartesian[4],sizeof(CARTESIAN),1,lookuptable_info_file);

				if(Distance_sqrd(dummy_cartesian[1],protein->resparam[i].rotamerlib_ptr->ligand_base_coords[1].coord)>TINY ||
					Distance_sqrd(dummy_cartesian[2],protein->resparam[i].rotamerlib_ptr->ligand_base_coords[2].coord)>TINY ||
					Distance_sqrd(dummy_cartesian[3],protein->resparam[i].rotamerlib_ptr->ligand_base_coords[3].coord)>TINY ||
					Distance_sqrd(dummy_cartesian[4],protein->resparam[i].rotamerlib_ptr->ligand_base_coords[4].coord)>TINY)
					{
						fprintf(stderr,"ERROR Base coordinates for %s do not match previously used ones.\n",protein->resparam[i].residuetype);
						exit(1);
					}
				

				free_memory(dummy_cartesian);
			}

			fclose(lookuptable_info_file);
  		}
	}
	++i;
  }

  sprintf(dummystring, "%s/template_info", protein->parameters.lookup_energy_table_directory);
  if(does_this_file_exist(dummystring)==0)
  {
  	lookuptable_info_file = fopen_file(dummystring, "w"); 
	fprintf(lookuptable_info_file,"TEMPLATE %s\n",protein->Template_filename);
  	fclose(lookuptable_info_file);
  } 


  free_memory(dummystring);
  free_memory(dummyresparam);
  free_memory(dummyrotamerlib);
  
  return(good);
}

/* this function loads sideAtoms coordinates for all LOOKUP_ENERGY_ROTAMER's for 
	all LOOKUP_ENERGY_RESIDUE's at all positions.
	assumes that the lookup table for protein has been created with lookup_table.cpp: generate_lookup_table
*/
void load_all_lookupRes_coordinates(PROTEIN *protein)
{
	int i, i_res;
	char *structure_filename;

	structure_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));
	
	for(i=1;i<=protein->parameters.numVarPositions; ++i)
	{
	    for(i_res=1; i_res<=protein->var_pos[i].number_of_choices; ++i_res)
	    {	
		/* if not already loaded, load */
		if(protein->var_pos[i].choice[i_res].lookup_res_ptr->lookupRot[1].sideAtoms == NULL) 
                    {
				/* position fixed to template rotamer */
                    	if(protein->var_pos[i].choice[i_res].lookup_res_ptr->fixed_flag == 1)	
                        {
                                sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure.fixed", 
                                                        protein->parameters.lookup_energy_table_directory, 
                                                        protein->var_pos[i].seq_position, 
                                                        protein->var_pos[i].choice[i_res].resparam_ptr->residuetype, 
                                                        protein->var_pos[i].seq_position);
                        }
                        else /* allowed to move */
                        {
                                sprintf(structure_filename, "%s/coordinates/%d/%s.%d.structure", 
                                                        protein->parameters.lookup_energy_table_directory, 
                                                        protein->var_pos[i].seq_position, 
                                                        protein->var_pos[i].choice[i_res].resparam_ptr->residuetype, 
                                                        protein->var_pos[i].seq_position);
                        }

                        load_coordinates_lookupRes(protein->var_pos[i].choice[i_res].lookup_res_ptr, 
											protein->var_pos[i].choice[i_res].resparam_ptr, 
											structure_filename);

                    }
	    }
	}

	free_memory(structure_filename);
}




