/* EGAD: GA.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for GA.cpp

*/


#ifndef GA_header_flag
#define GA_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "GA_utilities.h"
#include "CHROMOSOME_to_lookupEnergy.h"
#include "search_and_sort.h"
#include "HQM_rotamers.h"
#include "io.h"
#include "output_stuff.h"
#include "solubility.h"


/* This function controls the GA. It launches the protein->parameters.numSuperGen number of independent GA's, 
	pools the results, and launches an GA seeded with the winners from the independent runs.
	Final soln information stored in protein->final_*; ready for output_PROTEIN */
void GA_rotamers_master_control(PROTEIN *protein);

/* 
	This function seeds parameters->numSuperGen GAs with chrs array of chrs_size.
	The first GA uses all the chrs members as seeds; 
		the nth GA run includes chrs[n] onward.
	If chrs_size<0, then all the seeds for all the runs are random.
	After all the GA's are done, a tournament GA is performed where the top parameters->numberofSolutions
		from each GA are used to seed the initial population.
	The final population is returned in chrs
*/ 
void GA_rotamer_control(PARAMETERS *parameters, CHROMOSOME *chrs, int chrs_size, mini_pdbATOM fixed_atoms[], VARIABLE_POSITION var_pos[]);


/* this is a GA that uses a pre-calculated lookuptable for rotamer optimization 
   input a seeded CHROMOSOME 2*parameters->pop_size array chrs[]. All elements of chrs must be soluble.  
   best soln stored in chr[1]. 
   */
void evolve_sidechains(PARAMETERS *parameters, CHROMOSOME chrs[], VARIABLE_POSITION var_pos[]);


#endif
