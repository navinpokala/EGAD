/* EGAD: batch_jobs.cpp
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file contains the batch_jobs function that sequentially launches the inputfiles listed in the inputed filename 

*/

#include "batch_jobs.h"


/* filename contains a list of egad inputfiles. This function serially launches egad jobs
	to execute those files. A logfile filename.log is written; failures are written to filename.fail.
*/
void launch_batch_jobs(char *filename)
{
	FILE *file_ptr, *logfile_ptr;
	char *line, *command, *egadinputfile, *tempfilename, *dummystring, *output_prefix, *logfilename, *pdb_filename;
	extern char *EXECUTABLE_FILENAME;
	extern int GET_PID;
	int state_of_run,k;
	time_t now;
	long fp;

	
	line = (char *)calloc(MXLINE_INPUT,sizeof(char));
	command = (char *)calloc(MXLINE_INPUT,sizeof(char));
	egadinputfile = (char *)calloc(MXLINE_INPUT,sizeof(char));
	tempfilename = (char *)calloc(20,sizeof(char));
	dummystring = (char *)calloc(100,sizeof(char));
	output_prefix = (char *)calloc(MXLINE_INPUT,sizeof(char));
	logfilename = (char *)calloc(MXLINE_INPUT,sizeof(char));
	pdb_filename = (char *)calloc(MXLINE_INPUT,sizeof(char));

	sprintf(tempfilename,"temp.%d",GET_PID);

	sprintf(logfilename,"%s.log",filename);
	touch_file(logfilename);
	file_ptr = NULL;

	for(k=1;k<=3;++k)
	{
	file_ptr = fopen_file(filename,"r");

	if(file_ptr==NULL)
		exit(0);
 
	while(fgets(line,MXLINE_INPUT,file_ptr)!=NULL)
	{
		sscanf(line,"%s",egadinputfile);
		
		if(does_this_file_exist(egadinputfile)==1)	
		{

			/* get the output_prefix for this inputfile */
			grep_line_from_file("OUTPUT_PREFIX", line, MXLINE_INPUT, egadinputfile);
			sscanf(line,"%s %s",dummystring, output_prefix);
			
			sprintf(pdb_filename,"%s.pdb",output_prefix); sprintf(command,"%s.working",egadinputfile);
			/* output pdb file does not exist and no one else is working on it */
			if(does_this_file_exist(pdb_filename)==0 && does_this_file_exist(command)==0)	
			{
					cp_file(egadinputfile,command); /* create the working flag file */

					/* launch the job */
					now = time(NULL);
					mv_file(logfilename, tempfilename);
					logfile_ptr = fopen_file(tempfilename,"a");
					fprintf(logfile_ptr,"LAUNCHED: %s\t%s",egadinputfile, ctime(&now));
					fclose(logfile_ptr);
					mv_file(tempfilename, logfilename);

					sprintf(command,"%s %s.working",EXECUTABLE_FILENAME, egadinputfile);

					/* save the file pointer and close the inputfile */
					fp = ftell(file_ptr);
					fclose(file_ptr); file_ptr = NULL;

					state_of_run = system(command);

					now = time(NULL);
					if(state_of_run != 0) /* failed */
					{
						if(does_this_file_exist(logfilename)==1)
						{
						mv_file(logfilename, tempfilename);
						logfile_ptr = fopen_file(tempfilename,"a");
						fprintf(logfile_ptr,"FAILURE: %s\t%s",egadinputfile,ctime(&now));
						fclose(logfile_ptr);
						mv_file(tempfilename, logfilename);
						}
					}
					else
					{
						if(does_this_file_exist(logfilename)==1)
						{
						mv_file(logfilename, tempfilename);
						logfile_ptr = fopen_file(tempfilename,"a");
						fprintf(logfile_ptr,"SUCCESS: %s\t%s",egadinputfile,ctime(&now));
						fclose(logfile_ptr);
						mv_file(tempfilename, logfilename);
						}
					} 

					sprintf(command,"%s.working",egadinputfile); /* rm the working flag file */
					rm_file(command);

					/* re-open file and reset file pointer */
					file_ptr = fopen_file(filename,"r");
					fseek(file_ptr, fp, 0);
					
			}
		}
		
		if(does_this_file_exist(tempfilename)==1)
			rm_file(tempfilename);
	}
	
	if(file_ptr != NULL)
	{
		fclose(file_ptr); 
		file_ptr = NULL;
	}
	sleep(10); /* wait for other processes to finish or for a master to remove the file */
	}

	
	free_memory(line); free_memory(command); free_memory(egadinputfile); free_memory(tempfilename);
	free_memory(dummystring); free_memory(output_prefix); free_memory(pdb_filename);
}


