/* EGAD: scanning_mutagenesis.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Aug 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for scanning_mutagenesis.cpp
   
*/

#ifndef scanning_mutagenesis_header_flag
#define scanning_mutagenesis_header_flag


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>


#include "structure_types.h"
#include "GENES_pdb.h" 
#include "energy_functions.h" 
#include "io.h"
#include "GA_utilities.h"
#include "rotamer_calc_master.h"
#include "parallel_egad.h"

/* this function makes all possible single point mutants within protein->var_pos[i].fixed_flag==0;
	inputfiles for rotamer optimization are created, launched, 
	and the data printed to protein->output_prefix.scanning_mutagenesis */ 
void scanning_mutagenesis(char *main_inputfilename, PROTEIN *protein);

/* for each protein->var_pos[i].fixed_flag==0, ALA is placed, and the energy scored
	data printed to protein->output_prefix.ala_shave;
	unlike scanning_mutagenesis, no rotamer optimization is performed */ 
void alanine_shave(PROTEIN *protein);


#endif
