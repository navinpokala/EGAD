/* EGAD: solubility.h
   
Navin Pokala and Tracy Handel
Dept. of Molecular and Cell Biology
University of California, Berkeley
Copyright (C) 2003 Regents of the University of California
GNU Public License
Sept 12 2003

Absolutely no warranties are made or are implied with the use of this program or its parts.

This file is the header for solubility.cpp.
   
*/


#ifndef solubility_header_flag
#define solubility_header_flag

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "structure_types.h"
#include "moremath.h"
#include "GA_utilities.h"
#include "sequence_restraint.h"


/* Calculate the sasa and overall_charge of the dummychr CHROMOSOME for all fixed positions.
	Used by MC_rotamers and downhill_linmin_CHROMOSOME when SOLUBILITY_CUTOFF_FLAG=1 */

void fixed_position_sasa_charge(CHROMOSOME *dummychr, double *fixed_sasa, double *fixed_hphob_sasa, double *fixed_charge, double *fixed_E_transfer);

/* Given a charge of a protein overall_charge_pH_avg, this function returns 1 if the charge is 
	within the inputed specifications
   If SOLUBILITY_CUTOFF_FLAG=0, then 1 is returned immediately.
   Returns 0 if overall_charge_pH_avg is not within the specifications
*/
int charge_within_specifications(double overall_charge_pH_avg);

/* returns 1 if soluble; 0 if not. Solubility based on fraction hydrophobic sasa FRACTION_HYDROPHOBIC_SASA_CUTOFF, 
	charge_within_specifications, and TRANSFER_FREE_ENERGY_DENSITY_CUTOFF. If SOLUBILITY_CUTOFF_FLAG=0,
	returns 1 */
int is_this_chr_soluble(CHROMOSOME *chr);


/* given a CHROMOSOME chr, this function returns a solubility score based on how close it is to
	satsifying the three solubility criteria of 
	OVERALL_CHARGE, FRACTION_HYDROPHOBIC_SASA_CUTOFF, and TRANSFER_FREE_ENERGY_DENSITY_CUTOFF.
   A score of 0 means all three criteria have been satisfied. Otherwise, the returned score is >0.
	score = SIGMA(1.0 - target_value/desired_value <-- inverted dependent on sign and magnitude) 	
   Used by solubilize_CHROMOSOME as an objective function
*/
double score_CHROMOSOME_solubility(CHROMOSOME *chr);

/* This function returns in CHROMOSOME input_chr (which has allocated GENE linked list) a 
	soluble sequence. A genetic algorithm is performed, scoring solubility with score_CHROMOSOME_solubility.
	This function does NOT optimize solubility; it merely tries to identify a sequence which satisfies 
	the solubility criteria; the initial population are mutated input_chr to keep solutions near input_chr.
*/
void solubilize_CHROMOSOME(CHROMOSOME *input_chr);


#endif

