The tarball EGAD.tar.gz contains the source code. If the executable does not work on your system, the Makefile contains the version of g++ I used to compile it. All the development was done on a 32-bit system … I haven't gotten around to compiling for 64-bit architectures, so, right now, I use the -m32 compiler flag.

Documentation is in EGAD_manual.pdf

The examples.tar.gz contains the examples described in the documentation.

Documentation is in EGAD_manual.pdf

For parallelization using ssh on multi-computer clusters:

First of all, make sure that you are able to use ssh without a password from your terminal to your nodes:
https://www.debian.org/devel/passwordlessssh
sh
cd ~/EGAD/examples/scanning_mutagenesis/scan_mut
~/EGAD/bin/EGAD.exe gb1.scan_mut.input

Before you try the scanning mutagenesis, can you try a simpler (non-parallel-requiring) job
cd ~/EGAD/examples/rotamer_optimization
~/EGAD/bin/EGAD.exe gb1.faster.rotamer_optim.input &

Alternatively, if you have multiple CPUs on a single node:
~/EGAD/bin/EGAD.exe gb1.sat_mut.input parallel 2 cpus 
